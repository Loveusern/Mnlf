
export interface AppNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: 'REFERRAL' | 'SYSTEM' | 'EARNING' | 'PENALTY';
}

export interface User {
  id: string;
  phoneNumber: string;
  password?: string;
  referralCode: string;
  referredBy?: string;
  name?: string;
  avatarId: number;
  
  isAdmin?: boolean;
  isBanned?: boolean;

  balance: number;
  spinsAvailable: number;

  vipLevel: number;
  vipExpiryDate: string;
  lastActiveDate?: string;
  
  lastTaskCompletionTime?: number;

  todayEarnings: number;
  yesterdayEarnings: number;
  totalEarnings: number;
  weeklyEarnings: number;
  monthlyEarnings: number;
  lastMonthEarnings: number;
  todayReferralBonus: number;
  totalReferralBonus: number;
  
  totalDeposited?: number; 
  totalWithdrawn?: number;

  tasksCompletedToday: number;
  tasksFailedToday: number;
  
  loginStreak: number;
  lastDailyRewardDate?: string;
  
  referrals: ReferralMember[];
  depositHistory: Transaction[];
  withdrawHistory: Transaction[];
  earningHistory: Transaction[];
  notifications: AppNotification[];
  hiddenBroadcasts?: string[]; // Added field to store deleted broadcast IDs
  joinDate: string;
  
  withdrawalPin: string;
  savedPaymentMethods?: { method: 'bKash' | 'Nagad' | null; number: string }[];

  nameChangeCount: number;
  passwordChangeCount: number;
  lastPasswordChangeDate?: string; 
  
  pinChangeCount: number;
  lastPinChangeDate?: string;
  
  bKashChangeCount: number;
  nagadChangeCount: number;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export interface ReferralMember {
  id: string;
  phoneNumber: string;
  username: string;
  level: 1 | 2 | 3;
  joinDate: string;
  vipLevel: number;
  totalDeposited: number;
  totalWithdrawn: number;
  tasksCompletedToday: number;
  memberTodayEarnings: number;
  tasksFailedToday: number;
  commissionEarned: number;
  lastActiveDate?: string;
}

export interface TeamActivity {
  id: string;
  memberId: string;
  memberPhone: string;
  memberLevel: 1 | 2 | 3;
  type: 'JOIN' | 'VIP_UPGRADE' | 'DEPOSIT' | 'WITHDRAW' | 'TASK_COMMISSION' | 'WORK_COMPLETE' | 'WORK_FAIL';
  amount: number;
  commission: number;
  date: string;
}

export interface Transaction {
  id: string;
  type: 'DEPOSIT' | 'WITHDRAW' | 'EARNING' | 'BONUS' | 'LOTTERY' | 'PENALTY' | 'WORK_FAIL';
  amount: number;
  status: 'PENDING' | 'COMPLETED' | 'FAILED';
  date: string;
  method?: string;
  transactionId?: string;
  senderNumber?: string;
}

export interface VipTier {
  level: number;
  name: string;
  price: number;
  dailyIncome: number;
  dailyTasks: number;
  taskRate: number;
  validityDays: number;
  color: string;
}

export interface LotterySegment {
    value: number;
    label: string;
    color: string;
}

export type TaskPlatform = 'WIKIPEDIA' | 'YOUTUBE' | 'FACEBOOK' | 'GENERIC';

export interface Task {
  id: string;
  title: string;
  description: string;
  platform: TaskPlatform;
  durationSeconds: number;
  reward: number;
  url: string;
  tag: string;
}

export interface SystemSettings {
    appLogo: string;
    paymentNumbers: {
        bKash: string[];
        nagad: string[];
    };
    paymentLogos: {
        bKash: string;
        nagad: string;
    };
    externalLinks: {
        telegram: string;
        whatsapp: string;
        appDownload: string;
    };
    withdrawLimits: {
        [vipLevel: number]: number;
    };
    depositLimits: {
        min: number;
        max: number;
    };
    schedule: {
        startHour: number;
        endHour: number;
        offDays: number[];
    };
    commissions: {
        vip: number[];
        task: number[];
    };
    certificateConfig: {
        signatureName: string;
        missionStatement: string;
    };
    taskPenaltyPercent: number;
    vipTiers: VipTier[];
    lotterySegments: LotterySegment[];
    sliderImages: string[];
    broadcasts: AppNotification[]; // Global Admin Broadcasts
}

export const DEFAULT_SETTINGS: SystemSettings = {
    appLogo: '',
    paymentNumbers: {
        bKash: ['01712345678'],
        nagad: ['01912345678']
    },
    paymentLogos: {
        bKash: 'https://freelogopng.com/images/all_img/1656235623bkash-logo-png.png',
        nagad: 'https://freelogopng.com/images/all_img/1679248787nagad-logo.png'
    },
    externalLinks: {
        telegram: 'https://t.me/mnlife_official',
        whatsapp: 'https://wa.me/8801700000000',
        appDownload: '#'
    },
    withdrawLimits: {
        0: 1000, 1: 500, 2: 1000, 3: 2000, 4: 5000, 5: 10000
    },
    depositLimits: {
        min: 500,
        max: 25000
    },
    schedule: {
        startHour: 10,
        endHour: 16,
        offDays: [5, 6]
    },
    commissions: {
        vip: [10, 5, 3],
        task: [5, 3, 2]
    },
    certificateConfig: {
        signatureName: 'CEO_MNLife',
        missionStatement: '"MNLife is dedicated to financial empowerment through secure digital innovation."'
    },
    taskPenaltyPercent: 30,
    vipTiers: [], 
    lotterySegments: [], 
    sliderImages: [],
    broadcasts: []
};
