
import React, { useState, useEffect, useRef } from 'react';
import { User, VipTier, SystemSettings, DEFAULT_SETTINGS } from '../types';
import { VIP_TIERS } from '../constants';
import { Check, Star, Info, Crown, X, AlertCircle, FileText, Download, Printer, ShieldCheck, Gem } from 'lucide-react';
import DepositModal from '../components/DepositModal';
import { useToast } from '../components/ToastContext';
import { api } from '../services/api';
import { useLocation } from 'react-router-dom';
import PageLoadingOverlay from '../components/PageLoadingOverlay';

interface VipProps {
  user: User;
  onUpgrade: (level: number, cost: number) => void;
  onDeposit: (amount: number, method: string, trxId: string, sender: string) => void;
}

// ... (CertificateModal code stays same - omitted for brevity but file content must be full if not changed structure)
// Re-including CertificateModal for completeness as standard protocol
const CertificateModal = ({ user, tier, onClose }: { user: User, tier: VipTier, onClose: () => void }) => {
    const certSerial = `MN-${tier.level}${user.id.substring(0, 4).toUpperCase()}-${Date.now().toString().substring(8)}`;
    const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);

    useEffect(() => {
        const load = async () => {
            const cached = api.getFromCache<SystemSettings>('mnlife_settings_data');
            if (cached) setSettings(cached);
            
            try {
                const s = await api.getSettings();
                setSettings(s);
            } catch(e) { console.error(e); }
        };
        load();
    }, []);
    
    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/90 backdrop-blur-md p-0 sm:p-4 animate-fade-in overflow-y-auto print:p-0 print:overflow-visible print:absolute print:inset-0 print:bg-white print:z-[9999]">
            <div id="certificate-view" className="relative w-full h-full sm:h-auto sm:max-w-2xl bg-white text-slate-900 shadow-2xl overflow-y-auto sm:overflow-hidden print:w-[100vw] print:h-[100vh] print:max-w-none print:shadow-none print:overflow-visible">
                
                <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-slate-200 hover:bg-slate-300 rounded-full print:hidden z-50 shadow-md">
                    <X size={24} />
                </button>

                <div className="p-1 h-full min-h-screen sm:min-h-0 print:h-full">
                    <div className="h-full border-[10px] border-double border-[#B8860B] p-6 sm:p-10 relative bg-[#fffdf5] print:border-[5px]">
                        
                        <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-[#B8860B]"></div>
                        <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-[#B8860B]"></div>
                        <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-[#B8860B]"></div>
                        <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-[#B8860B]"></div>

                        <div className="absolute inset-0 flex items-center justify-center opacity-[0.04] pointer-events-none">
                            <Gem size={400} />
                        </div>

                        <div className="text-center mb-8 relative z-10 print:mb-4">
                            <div className="flex justify-center mb-3 text-[#B8860B] drop-shadow-sm">
                                <Crown size={56} strokeWidth={1.5} />
                            </div>
                            <h1 className="text-3xl sm:text-4xl font-serif font-extrabold text-slate-900 uppercase tracking-widest mb-2 print:text-2xl">Certificate</h1>
                            <h2 className="text-sm sm:text-base font-serif font-bold text-[#B8860B] uppercase tracking-[0.3em] border-b border-[#B8860B] inline-block pb-1">of VIP Partnership</h2>
                        </div>

                        <div className="text-center space-y-6 font-serif relative z-10 print:space-y-4">
                            <p className="text-lg italic text-slate-600 print:text-sm">This official document certifies that</p>
                            
                            <div className="py-2">
                                <p className="text-2xl sm:text-3xl font-bold text-slate-900 uppercase font-sans tracking-wide border-b-2 border-dashed border-slate-300 w-full sm:w-3/4 mx-auto pb-2 print:text-xl">
                                    {user.name || "Valued Member"}
                                </p>
                                <p className="text-xs text-slate-500 mt-1 font-mono">User ID: {user.phoneNumber}</p>
                            </div>

                            <p className="text-sm sm:text-base text-slate-700 px-2 sm:px-8 leading-relaxed text-justify sm:text-center print:text-xs">
                                Has successfully subscribed to the <strong className="text-[#B8860B] text-lg">{tier.name} Membership</strong> at MNLife. 
                                By securing this position, the holder is recognized as a strategic partner in our digital ecosystem. 
                                This membership grants exclusive access to premium tasks, priority withdrawals, and a daily earning potential of <strong className="text-slate-900">{tier.dailyIncome} BDT</strong>.
                            </p>

                            <div className="grid grid-cols-3 gap-4 border-y border-slate-200 py-4 mt-6 print:py-2 print:mt-4">
                                <div className="text-center">
                                    <p className="text-[10px] uppercase tracking-wider text-slate-500 mb-1">Membership Plan</p>
                                    <p className="font-bold text-slate-900 text-lg print:text-sm">{tier.name}</p>
                                </div>
                                <div className="text-center border-l border-r border-slate-200">
                                    <p className="text-[10px] uppercase tracking-wider text-slate-500 mb-1">Daily Work Limit</p>
                                    <p className="font-bold text-slate-900 text-lg print:text-sm">{tier.dailyTasks} Tasks</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-[10px] uppercase tracking-wider text-slate-500 mb-1">Validity Period</p>
                                    <p className="font-bold text-slate-900 text-lg print:text-sm">{tier.validityDays} Days</p>
                                </div>
                            </div>

                            <div className="bg-[#f8f9fa] p-4 rounded-lg border border-slate-100 mt-4 text-left print:p-2">
                                <h4 className="text-xs font-bold text-[#B8860B] uppercase mb-2 flex items-center">
                                    <ShieldCheck size={14} className="mr-1" /> MNLife Commitment
                                </h4>
                                <p className="text-[10px] sm:text-xs text-slate-600 leading-relaxed italic whitespace-pre-wrap">
                                    {settings.certificateConfig?.missionStatement || "We promise transparency and growth."}
                                </p>
                            </div>
                        </div>

                        <div className="mt-12 flex justify-between items-end px-2 sm:px-4 relative z-10 print:mt-8">
                            <div className="text-center">
                                <div className="w-24 sm:w-32 border-b border-slate-400 mb-2"></div>
                                <p className="text-[10px] font-bold text-slate-900 uppercase">Partner Signature</p>
                            </div>
                            
                            <div className="absolute left-1/2 bottom-2 transform -translate-x-1/2">
                                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-[3px] border-[#B8860B] flex items-center justify-center text-[#B8860B] font-bold text-[10px] text-center p-2 rotate-[-15deg] opacity-90 bg-white/50 backdrop-blur-sm shadow-sm print:w-20 print:h-20">
                                    <div className="border border-[#B8860B] rounded-full w-full h-full flex flex-col items-center justify-center">
                                        <Gem size={16} className="mb-1" />
                                        MNLife <br/> OFFICIAL <br/> SEAL <br/> 
                                        <span className="text-[8px] font-mono mt-1">VERIFIED</span>
                                    </div>
                                </div>
                            </div>

                            <div className="text-center">
                                <div className="font-dancing-script text-xl sm:text-2xl text-blue-900 mb-1" style={{fontFamily: 'cursive'}}>
                                    {settings.certificateConfig?.signatureName || 'CEO_MNLife'}
                                </div>
                                <div className="w-24 sm:w-32 border-b border-slate-400 mb-2"></div>
                                <p className="text-[10px] font-bold text-slate-900 uppercase">Authorized By</p>
                            </div>
                        </div>

                        <div className="mt-8 pt-4 border-t border-slate-100 flex justify-between items-center text-[9px] text-slate-400 font-sans print:mt-4">
                            <p>Serial: <span className="font-mono text-slate-600">{certSerial}</span></p>
                            <p>Issued: {new Date().toLocaleDateString()}</p>
                        </div>
                    </div>
                </div>

                <div className="bg-slate-900 p-4 flex justify-center space-x-4 print:hidden border-t border-slate-800 absolute bottom-0 left-0 right-0 sm:relative">
                    <button 
                        onClick={handlePrint}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:shadow-blue-500/30 flex items-center transition-all active:scale-95"
                    >
                        <Printer size={18} className="mr-2" /> Save as PDF / Print
                    </button>
                </div>
            </div>
            
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap');
                
                .font-serif { font-family: 'Playfair Display', serif; }
                
                @media print {
                    @page { margin: 0; size: auto; }
                    body * { visibility: hidden; }
                    #certificate-view, #certificate-view * { 
                        visibility: visible;
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                    #certificate-view {
                        position: absolute;
                        left: 0;
                        top: 0;
                        width: 100%;
                        height: 100%;
                        margin: 0;
                        padding: 0;
                        background: white;
                    }
                    .print\\:hidden { display: none !important; }
                }
            `}</style>
        </div>
    );
};

const Vip: React.FC<VipProps> = ({ user, onUpgrade, onDeposit }) => {
  const { showToast } = useToast();
  const location = useLocation();
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [requiredDeposit, setRequiredDeposit] = useState<number>(0);
  const [vipLevels, setVipLevels] = useState<VipTier[]>(VIP_TIERS);
  const [loading, setLoading] = useState(true);
  
  const [activeTooltip, setActiveTooltip] = useState<{level: number, field: string} | null>(null);
  
  const [confirmTier, setConfirmTier] = useState<{level: number, price: number, name: string} | null>(null);
  const [successTier, setSuccessTier] = useState<string | null>(null);
  
  const [showCertificate, setShowCertificate] = useState<{user: User, tier: VipTier} | null>(null);

  const isGuest = user.id === 'guest';

  useEffect(() => {
    const fetchVip = async () => {
        setLoading(true);
        // Try Cache First
        const cachedSettings = api.getFromCache<SystemSettings>('mnlife_settings_data');
        if (cachedSettings && cachedSettings.vipTiers && cachedSettings.vipTiers.length > 0) {
            setVipLevels(cachedSettings.vipTiers);
            setLoading(false); // Instant unlock
        }

        try {
            const settings = await api.getSettings();
            if (settings.vipTiers && settings.vipTiers.length > 0) {
                setVipLevels(settings.vipTiers);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };
    fetchVip();
  }, []);

  useEffect(() => {
      if (location.state?.openCertificate && !isGuest && !showCertificate) {
          const currentTier = vipLevels.find(t => t.level === user.vipLevel);
          if (currentTier && currentTier.level > 0) {
              setShowCertificate({ user, tier: currentTier });
          }
      }
  }, [location.state, user, vipLevels, isGuest]);

  const toggleTooltip = (level: number, field: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeTooltip?.level === level && activeTooltip?.field === field) {
        setActiveTooltip(null);
    } else {
        setActiveTooltip({ level, field });
    }
  };

  useEffect(() => {
    const closeTooltips = () => setActiveTooltip(null);
    window.addEventListener('click', closeTooltips);
    return () => window.removeEventListener('click', closeTooltips);
  }, []);

  const handleUpgradeClick = (level: number, price: number, name: string) => {
    if (isGuest) {
        onUpgrade(level, price);
        return;
    }

    if (user.vipLevel >= level) return;
    
    if (user.balance < price) {
      const shortfall = price - user.balance;
      showToast(`Insufficient Balance! You need ৳${shortfall.toFixed(2)} more.`, 'error');
      
      if (window.confirm(`Deposit ৳${Math.ceil(shortfall)} now?`)) {
            setRequiredDeposit(Math.ceil(shortfall));
            setShowDepositModal(true);
      }
      return;
    }

    setConfirmTier({ level, price, name });
  };

  const confirmPurchase = () => {
    if (confirmTier) {
        onUpgrade(confirmTier.level, confirmTier.price);
        const name = confirmTier.name;
        setConfirmTier(null);
        setSuccessTier(name);
    }
  };

  const handleShowCertificate = (tier: VipTier) => {
      setShowCertificate({ user, tier });
  };

  const Tooltip = ({ text }: { text: string }) => (
    <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-40 bg-slate-900 border border-slate-700 text-white text-[10px] p-2 rounded-lg shadow-xl z-20 pointer-events-none animate-fade-in">
        {text}
        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-700"></div>
    </div>
  );

  return (
    <div className="pb-24 pt-4 px-4 bg-slate-950 min-h-screen text-slate-100 relative">
      {loading && <PageLoadingOverlay />}
      
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-white">VIP Membership</h2>
        <p className="text-slate-400 text-sm">Upgrade to earn more daily</p>
      </div>

      <div className="space-y-6">
        {vipLevels.map((tier) => {
          const isCurrent = !isGuest && user.vipLevel === tier.level;
          const isUnlocked = !isGuest && user.vipLevel > tier.level;

          return (
            <div key={tier.level} className={`relative overflow-visible rounded-2xl shadow-lg transition-transform border border-slate-800 ${isCurrent ? 'ring-2 ring-indigo-500 scale-105 z-10' : 'hover:scale-102 z-0'}`}>
              <div className={`${tier.color} p-6 text-white rounded-t-2xl`}>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-2xl font-bold flex items-center">
                      {tier.name}
                      {isCurrent && <span className="ml-2 text-xs bg-slate-900 text-white px-2 py-1 rounded-full font-bold flex items-center shadow-sm"><Star size={10} className="mr-1 fill-current"/> Current</span>}
                    </h3>
                    <p className="opacity-80 text-sm mt-1">Validity: {tier.validityDays} Days</p>
                  </div>
                  <div className="text-right">
                     <p className="text-xs opacity-75">Price</p>
                    <p className="text-2xl font-bold">৳{tier.price}</p>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-3 gap-4 border-t border-white/20 pt-4">
                  <div className="text-center relative group">
                    <p 
                        className="text-xs opacity-75 flex items-center justify-center gap-1 cursor-pointer hover:opacity-100 transition-opacity"
                        onClick={(e) => toggleTooltip(tier.level, 'dailyTasks', e)}
                    >
                        Daily Tasks <Info size={12} />
                    </p>
                    {activeTooltip?.level === tier.level && activeTooltip?.field === 'dailyTasks' && (
                        <Tooltip text="Maximum number of tasks you can complete per day." />
                    )}
                    <p className="font-bold text-lg">{tier.dailyTasks}</p>
                  </div>

                  <div className="text-center border-l border-white/20 relative">
                    <p 
                        className="text-xs opacity-75 flex items-center justify-center gap-1 cursor-pointer hover:opacity-100 transition-opacity"
                        onClick={(e) => toggleTooltip(tier.level, 'perTask', e)}
                    >
                        Per Task <Info size={12} />
                    </p>
                    {activeTooltip?.level === tier.level && activeTooltip?.field === 'perTask' && (
                        <Tooltip text="Amount you earn for every single completed task." />
                    )}
                    <p className="font-bold text-lg">৳{tier.taskRate}</p>
                  </div>

                  <div className="text-center border-l border-white/20 relative">
                    <p 
                        className="text-xs opacity-75 flex items-center justify-center gap-1 cursor-pointer hover:opacity-100 transition-opacity"
                        onClick={(e) => toggleTooltip(tier.level, 'dailyIncome', e)}
                    >
                        Daily Income <Info size={12} />
                    </p>
                    {activeTooltip?.level === tier.level && activeTooltip?.field === 'dailyIncome' && (
                        <Tooltip text="Estimated total earnings if you finish all daily tasks." />
                    )}
                    <p className="font-bold text-lg">৳{tier.dailyIncome}</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 p-4 rounded-b-2xl border-t border-slate-800 space-y-3">
                 <button
                    onClick={() => handleUpgradeClick(tier.level, tier.price, tier.name)}
                    disabled={isCurrent || isUnlocked}
                    className={`w-full py-3 rounded-xl font-bold text-sm flex justify-center items-center ${
                        isCurrent 
                        ? 'bg-slate-800 text-slate-500 cursor-default border border-slate-700' 
                        : isUnlocked 
                            ? 'bg-green-500/10 text-green-500 cursor-default border border-green-500/30'
                            : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-900/40 active:scale-95 transition-all'
                    }`}
                 >
                    {isCurrent ? 'Current Plan' : isUnlocked ? <><Check size={18} className="mr-2"/> Unlocked</> : (isGuest ? 'Login to Join' : 'Join Now')}
                 </button>

                 {isCurrent && tier.level > 0 && (
                     <button 
                        onClick={() => handleShowCertificate(tier)}
                        className="w-full py-2.5 rounded-xl border border-slate-700 bg-slate-900 text-[#B8860B] hover:text-yellow-400 font-bold text-xs flex justify-center items-center hover:bg-slate-800 transition-colors uppercase tracking-wide"
                     >
                         <FileText size={16} className="mr-2" /> Official Contract Paper
                     </button>
                 )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal */}
      {confirmTier && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in px-4">
              <div className="bg-slate-900 w-full max-w-xs rounded-2xl shadow-2xl p-6 text-center animate-zoom-in border border-slate-700">
                  <div className="w-16 h-16 bg-indigo-900/30 rounded-full flex items-center justify-center mx-auto mb-4 text-indigo-400 border border-indigo-500/30">
                      <Crown size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">Unlock {confirmTier.name}?</h3>
                  <p className="text-slate-400 text-sm mb-6">
                      You are about to spend <span className="font-bold text-white">৳{confirmTier.price}</span> to upgrade your membership.
                  </p>
                  <div className="flex space-x-3">
                      <button 
                          onClick={() => setConfirmTier(null)}
                          className="flex-1 py-2.5 rounded-xl border border-slate-700 font-medium text-slate-400 hover:bg-slate-800"
                      >
                          Cancel
                      </button>
                      <button 
                          onClick={confirmPurchase}
                          className="flex-1 py-2.5 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-900/50"
                      >
                          Confirm
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Success Modal */}
      {successTier && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in px-4">
              <div className="bg-slate-900 w-full max-w-xs rounded-2xl shadow-2xl p-6 text-center animate-zoom-in relative overflow-hidden border border-slate-700">
                  <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle,rgba(79,70,229,1)_1px,transparent_1px)] bg-[length:10px_10px]"></div>
                  <div className="w-20 h-20 bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4 text-green-400 relative z-10 border border-green-500/30">
                      <Check size={40} strokeWidth={3} />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2 relative z-10">Congratulations!</h3>
                  <p className="text-slate-400 text-sm mb-6 relative z-10">
                      You have successfully upgraded to <br/>
                      <span className="font-bold text-indigo-400 text-lg">{successTier}</span> Membership.
                  </p>
                  <button 
                      onClick={() => setSuccessTier(null)}
                      className="w-full py-3 rounded-xl bg-green-600 text-white font-bold hover:bg-green-500 shadow-lg shadow-green-900/50 relative z-10"
                  >
                      Awesome!
                  </button>
              </div>
          </div>
      )}

      {showCertificate && (
          <CertificateModal 
            user={showCertificate.user} 
            tier={showCertificate.tier} 
            onClose={() => setShowCertificate(null)} 
          />
      )}

      <DepositModal 
        isOpen={showDepositModal} 
        onClose={() => setShowDepositModal(false)} 
        onDeposit={onDeposit}
        initialAmount={requiredDeposit}
      />
    </div>
  );
};

export default Vip;
