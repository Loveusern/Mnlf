import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import Work from './pages/Work';
import Vip from './pages/Vip';
import Team from './pages/Team';
import Profile from './pages/Profile'; // Explicit import
import Lottery from './pages/Lottery';
import TaskView from './pages/TaskView';
import BottomNav from './components/BottomNav';
import GeminiAssistant from './components/GeminiAssistant';
import AuthModal from './components/AuthModal';
import SplashScreen from './components/SplashScreen';
import { User, Transaction } from './types';
import { api } from './services/api';
import { Loader2, Database, Save, AlertTriangle, Copy, Check, WifiOff, RefreshCw } from 'lucide-react';
import { ToastProvider } from './components/ToastContext';

// Admin Imports
import AdminLayout from './pages/admin/AdminLayout';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminDeposits from './pages/admin/AdminDeposits';
import AdminWithdrawals from './pages/admin/AdminWithdrawals';
import AdminUsers from './pages/admin/AdminUsers';
import AdminTasks from './pages/admin/AdminTasks';
import AdminSettings from './pages/admin/AdminSettings';
import AdminVip from './pages/admin/AdminVip';

const GUEST_USER: User = {
    id: 'guest',
    phoneNumber: '',
    referralCode: '',
    balance: 0,
    vipLevel: 0,
    vipExpiryDate: '',
    todayEarnings: 0,
    yesterdayEarnings: 0,
    totalEarnings: 0,
    weeklyEarnings: 0,
    monthlyEarnings: 0,
    lastMonthEarnings: 0,
    todayReferralBonus: 0,
    totalReferralBonus: 0,
    tasksCompletedToday: 0,
    tasksFailedToday: 0,
    referrals: [],
    depositHistory: [],
    withdrawHistory: [],
    earningHistory: [],
    notifications: [],
    joinDate: new Date().toISOString(),
    withdrawalPin: '',
    nameChangeCount: 0,
    passwordChangeCount: 0,
    pinChangeCount: 0,
    bKashChangeCount: 0,
    nagadChangeCount: 0,
    avatarId: 0,
    loginStreak: 0,
    spinsAvailable: 0
};

// ... (DatabaseSetupModal and NetworkErrorScreen components remain the same as previous turn) ...
const DatabaseSetupModal = () => {
    const [copied, setCopied] = useState(false);
    const sqlScript = `-- 1. Create Tables (If not exist)
create table if not exists public.users (
  id text primary key,
  "phoneNumber" text,
  password text,
  "referralCode" text,
  "referredBy" text,
  name text,
  "avatarId" int4,
  "isAdmin" boolean default false,
  "isBanned" boolean default false,
  balance float8 default 0,
  "spinsAvailable" int4 default 0,
  "vipLevel" int4 default 0,
  "vipExpiryDate" text,
  "lastActiveDate" text,
  "lastTaskCompletionTime" int8,
  "todayEarnings" float8 default 0,
  "yesterdayEarnings" float8 default 0,
  "totalEarnings" float8 default 0,
  "weeklyEarnings" float8 default 0,
  "monthlyEarnings" float8 default 0,
  "lastMonthEarnings" float8 default 0,
  "todayReferralBonus" float8 default 0,
  "totalReferralBonus" float8 default 0,
  "totalDeposited" float8 default 0,
  "totalWithdrawn" float8 default 0,
  "tasksCompletedToday" int4 default 0,
  "tasksFailedToday" int4 default 0,
  "loginStreak" int4 default 0,
  "lastDailyRewardDate" text,
  "joinDate" text,
  "withdrawalPin" text,
  "nameChangeCount" int4 default 0,
  "passwordChangeCount" int4 default 0,
  "lastPasswordChangeDate" text,
  "pinChangeCount" int4 default 0,
  "lastPinChangeDate" text,
  "bKashChangeCount" int4 default 0,
  "nagadChangeCount" int4 default 0,
  "savedPaymentMethods" jsonb default '[]',
  referrals jsonb default '[]',
  "depositHistory" jsonb default '[]',
  "withdrawHistory" jsonb default '[]',
  "earningHistory" jsonb default '[]',
  notifications jsonb default '[]'
);

create table if not exists public.system_settings (
  id text primary key,
  "masterCodeUsage" int4 default 0,
  settings jsonb
);

create table if not exists public.tasks (
  id text primary key,
  title text,
  description text,
  platform text,
  "durationSeconds" int4,
  reward float8,
  url text,
  tag text
);

-- 2. Enable Realtime
alter publication supabase_realtime add table public.users;
alter publication supabase_realtime add table public.tasks;
alter publication supabase_realtime add table public.system_settings;

-- 3. Row Level Security (RLS) Policies
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Enable read for users based on id" ON public.users;
DROP POLICY IF EXISTS "Enable insert for users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on id" ON public.users;
DROP POLICY IF EXISTS "Allow public read system settings" ON public.system_settings;
DROP POLICY IF EXISTS "Allow public read tasks" ON public.tasks;

-- Create New Policies
CREATE POLICY "Enable read for users based on id" ON public.users FOR SELECT USING (true);
CREATE POLICY "Enable insert for users" ON public.users FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update for users based on id" ON public.users FOR UPDATE USING (true);

CREATE POLICY "Allow public read system settings" ON public.system_settings FOR SELECT USING (true);
CREATE POLICY "Allow public read tasks" ON public.tasks FOR SELECT USING (true);
`;

    const copySql = () => {
        navigator.clipboard.writeText(sqlScript);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/95 p-4 overflow-y-auto">
            <div className="bg-slate-900 w-full max-w-lg rounded-2xl border border-slate-700 shadow-2xl overflow-hidden my-8">
                <div className="p-6 border-b border-slate-800 bg-gradient-to-r from-slate-900 to-indigo-950">
                    <h2 className="text-xl font-bold text-white flex items-center"><Database className="mr-2 text-red-500" /> Database Security Setup</h2>
                    <p className="text-slate-400 text-sm mt-1">Missing tables or policies detected.</p>
                </div>
                <div className="p-6 space-y-6">
                    <div className="bg-yellow-900/20 border border-yellow-500/20 p-3 rounded-lg flex items-start space-x-2">
                        <AlertTriangle size={16} className="text-yellow-500 shrink-0 mt-0.5" />
                        <p className="text-xs text-yellow-200">You MUST run this SQL in your Supabase <b>SQL Editor</b> to enable Security Policies.</p>
                    </div>
                    <div className="relative group">
                        <div className="absolute top-2 right-2">
                            <button onClick={copySql} className={`text-xs px-3 py-1.5 rounded-md font-bold flex items-center transition-all ${copied ? 'bg-green-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`}>{copied ? <Check size={14} className="mr-1" /> : <Copy size={14} className="mr-1" />}{copied ? 'Copied' : 'Copy SQL'}</button>
                        </div>
                        <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[10px] text-slate-400 font-mono h-48 overflow-y-auto no-scrollbar">{sqlScript}</pre>
                    </div>
                </div>
                <div className="p-6 border-t border-slate-800 bg-slate-900/50">
                    <button onClick={() => window.location.reload()} className="w-full bg-green-600 hover:bg-green-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-green-900/20 flex items-center justify-center transition-all"><Save size={18} className="mr-2" /> I've Run the SQL, Refresh App</button>
                </div>
            </div>
        </div>
    );
};

const NetworkErrorScreen = ({ onRetry }: { onRetry: () => void }) => {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 p-6 text-center animate-fade-in">
            <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mb-6 border-4 border-slate-800 shadow-xl"><WifiOff size={40} className="text-red-500" /></div>
            <h2 className="text-2xl font-bold text-white mb-2">Connection Lost</h2>
            <p className="text-slate-400 text-sm mb-8 max-w-xs">Unable to connect to the server.</p>
            <button onClick={onRetry} className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-lg shadow-blue-900/30 flex items-center transition-all active:scale-95"><RefreshCw size={20} className="mr-2" /> Retry Connection</button>
        </div>
    );
};

// Admin Route Wrapper
const AdminRoute = ({ user }: { user: User | null }) => {
    if (!user || !user.isAdmin) {
        return <Navigate to="/" replace />;
    }
    return <Outlet />;
};

// Layout Component
const Layout: React.FC<{ children: React.ReactNode; user: User | null; onRequireAuth: () => void }> = ({ children, user, onRequireAuth }) => {
    const location = useLocation();
    const isAdminPath = location.pathname.startsWith('/admin');

    return (
        <div className="bg-slate-950 min-h-screen text-slate-100 font-sans antialiased max-w-md mx-auto shadow-2xl overflow-hidden relative border-x border-slate-800">
            {isAdminPath && <style>{`.max-w-md { max-width: 100% !important; border: none !important; } .pb-24 { padding-bottom: 0 !important; }`}</style>}
            <div className="h-full overflow-y-auto no-scrollbar">{children}</div>
            {!isAdminPath && <BottomNav user={user} onRequireAuth={onRequireAuth} />}
            {!isAdminPath && <GeminiAssistant />}
        </div>
    );
};

const AppContent: React.FC = () => {
  // Initialize state with cache immediately
  const [user, setUser] = useState<User | null>(() => api.getFromCache<User>('mnlife_user_data'));
  
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [showSplash, setShowSplash] = useState(true);
  const [missingTables, setMissingTables] = useState(false);
  const [isNetworkError, setIsNetworkError] = useState(false);

  useEffect(() => {
    const initApp = async () => {
      // Reduced splash time for PWA speed
      const splashTimer = new Promise(resolve => setTimeout(resolve, 1500));
      
      try {
          await api.checkSystem();
      } catch (e: any) {
          if (e.message === "MISSING_TABLES") { setMissingTables(true); setIsInitializing(false); setShowSplash(false); return; }
          if (e.message === "NETWORK_ERROR") { setIsNetworkError(true); setIsInitializing(false); setShowSplash(false); return; }
      }

      // Check for token
      const token = api.getToken();
      let fetchPromise = Promise.resolve();
      
      if (token) {
        fetchPromise = api.getMe(true) // force network update in background
          .then(fetchedUser => setUser(fetchedUser))
          .catch(error => { 
             console.log("Session invalid or offline, keeping cache if exists or logout");
             if(!user) { // Only force logout if we have no cached user
                 api.removeToken(); 
                 setUser(null); 
             }
          });
      }

      await Promise.all([splashTimer, fetchPromise]);
      if (!missingTables && !isNetworkError) { setIsInitializing(false); setShowSplash(false); }
    };
    initApp();
  }, [missingTables, isNetworkError]); // Removed user dependency to avoid loop

  // Real-time updates
  useEffect(() => {
    let unsubscribe: () => void;
    if (user && user.id && user.id !== 'guest') {
        unsubscribe = api.subscribeToUser(user.id, (updatedUser) => {
            setUser(prev => { if (JSON.stringify(prev) !== JSON.stringify(updatedUser)) return updatedUser; return prev; });
        });
    }
    return () => { if (unsubscribe) unsubscribe(); };
  }, [user?.id]); 

  const handleLogin = (newUser: User) => { setUser(newUser); setShowAuthModal(false); if (newUser.isAdmin) window.location.hash = '#/admin/dashboard'; };
  const handleLogout = () => { api.removeToken(); setUser(null); };
  const requireAuth = () => { setShowAuthModal(true); };
  const handleUpdateUser = (updatedUser: User) => { setUser(updatedUser); api.syncUser(updatedUser); };

  const handleRefreshUser = async () => {
      if (!user) return;
      try {
          const refreshedUser = await api.getMe(true);
          setUser(refreshedUser);
      } catch (e) {
          console.error("Failed to refresh user", e);
      }
  };

  const handleTaskComplete = async (amount: number) => {
    if (!user || user.id === 'guest') return;
    const previousState = { ...user };
    const newTx: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'EARNING', amount: amount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Task Reward' };
    const updatedUser = { ...user, balance: (user.balance || 0) + amount, todayEarnings: (user.todayEarnings || 0) + amount, totalEarnings: (user.totalEarnings || 0) + amount, tasksCompletedToday: (user.tasksCompletedToday || 0) + 1, earningHistory: [newTx, ...(user.earningHistory || [])] };
    setUser(updatedUser);
    try { await api.claimTaskReward(user.id, amount); } catch (e: any) { setUser(previousState); alert(`Error: ${e.message}`); }
  };

  const handleTaskFail = async (penaltyAmount: number) => {
    if (!user || user.id === 'guest') return;
    const newTx: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'PENALTY', amount: penaltyAmount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Task Failed Penalty' };
    const updatedUser = { ...user, balance: (user.balance || 0) - penaltyAmount, tasksFailedToday: (user.tasksFailedToday || 0) + 1, earningHistory: [newTx, ...(user.earningHistory || [])] };
    setUser(updatedUser);
    try { await api.recordTaskFail(user.id, penaltyAmount); } catch (e) { console.error("Task Fail Log Error", e); }
  };

  const handleDeposit = (amount: number, method: string, trxId: string, sender: string) => {
    if (!user) return;
    const newTransaction: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'DEPOSIT', amount: amount, status: 'PENDING', date: new Date().toISOString(), method: method, transactionId: trxId, senderNumber: sender };
    const updatedUser = { ...user, depositHistory: [newTransaction, ...(user.depositHistory || [])] };
    setUser(updatedUser);
    api.syncUser(updatedUser);
  };

  const handleWithdraw = async (amount: number, method: string, number: string, pin: string) => {
    if (!user) return;
    const newTransaction: Transaction = { id: 'temp-' + Math.random().toString(36).substr(2, 9), type: 'WITHDRAW', amount: amount, status: 'PENDING', date: new Date().toISOString(), method: method, senderNumber: number };
    const updatedUser = { ...user, balance: user.balance - amount, withdrawHistory: [newTransaction, ...(user.withdrawHistory || [])] };
    setUser(updatedUser);
    try { await api.requestWithdrawal(user.id, amount, method, number, pin); } catch (error: any) { alert(error.message); api.getMe().then(setUser); }
  };

  const handleUpgrade = async (level: number, cost: number) => {
    if (!user) return;
    if (user.balance < cost) { alert("Insufficient Balance"); return; }
    try { await api.purchaseVip(user.id, level, cost); } catch (e: any) { alert(e.message || "Upgrade failed"); }
  };

  const handleSpinResult = (amount: number) => {
      if (!user || user.spinsAvailable <= 0) return;
      let updatedUser = { ...user };
      updatedUser.spinsAvailable -= 1;
      if (amount > 0) {
          updatedUser.balance += amount;
          updatedUser.totalEarnings += amount;
          updatedUser.todayEarnings += amount;
          const newTx: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'LOTTERY', amount: amount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Lucky Wheel' };
          updatedUser.earningHistory = [newTx, ...(updatedUser.earningHistory || [])];
      }
      setUser(updatedUser);
      api.syncUser(updatedUser);
  };

  if (isNetworkError) return <NetworkErrorScreen onRetry={() => window.location.reload()} />;
  if (missingTables) return <DatabaseSetupModal />;
  if (showSplash) return <SplashScreen />;
  if (isInitializing) return <div className="min-h-screen bg-slate-950"></div>; 

  return (
    <HashRouter>
      <Layout user={user} onRequireAuth={requireAuth}>
          <Routes>
            <Route path="/" element={<Home user={user} onRequireAuth={requireAuth} onUpdateUser={handleUpdateUser} onRefresh={handleRefreshUser} />} />
            <Route path="/work" element={<Work user={user} onTaskComplete={handleTaskComplete} onRequireAuth={requireAuth} />} />
            <Route path="/task/view" element={<TaskView onComplete={handleTaskComplete} onFail={handleTaskFail} />} />
            <Route path="/vip" element={<Vip user={user || GUEST_USER} onUpgrade={user ? handleUpgrade : requireAuth} onDeposit={handleDeposit} />} />
            <Route path="/team" element={user ? <Team user={user} /> : <Navigate to="/" replace />} />
            <Route path="/lottery" element={user ? <Lottery user={user} onSpinEnd={handleSpinResult} /> : <Navigate to="/" replace />} />
            <Route path="/profile" element={user ? <Profile user={user} onLogout={handleLogout} onDeposit={handleDeposit} onWithdraw={handleWithdraw} onUpdateUser={handleUpdateUser} /> : <Home user={null} onRequireAuth={requireAuth} />} />
            <Route path="/admin" element={<AdminRoute user={user} />}>
                <Route element={<AdminLayout />}>
                    <Route path="dashboard" element={<AdminDashboard />} />
                    <Route path="deposits" element={<AdminDeposits />} />
                    <Route path="withdrawals" element={<AdminWithdrawals />} />
                    <Route path="users" element={<AdminUsers />} />
                    <Route path="tasks" element={<AdminTasks />} />
                    <Route path="vip" element={<AdminVip />} />
                    <Route path="settings" element={<AdminSettings />} />
                </Route>
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
      </Layout>
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} onLogin={handleLogin} />
    </HashRouter>
  );
};

const App: React.FC = () => {
    return (
        <ToastProvider>
            <AppContent />
        </ToastProvider>
    )
}

export default App;