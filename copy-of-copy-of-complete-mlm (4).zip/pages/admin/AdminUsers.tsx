
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { User } from '../../types';
import { Search, Edit2, Ban, CheckCircle, Save, X, Trash2, Send, MessageSquare, AlertTriangle, RefreshCw } from 'lucide-react';
import { useToast } from '../../components/ToastContext';

const AdminUsers: React.FC = () => {
  const { showToast } = useToast();
  const [users, setUsers] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  
  // EDIT STATE
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{vipLevel: number, name: string, password?: string} | null>(null);

  // MODAL STATES
  const [showNotifModal, setShowNotifModal] = useState(false);
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<string | null>(null);

  // NOTIFICATION FORM
  const [notifTarget, setNotifTarget] = useState<{id: string, name: string} | null>(null); // null = Broadcast
  const [notifData, setNotifData] = useState({ title: '', message: '' });

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await api.getAllUsers();
      setUsers(data);
    } catch (e) { console.error(e); } 
    finally { setLoading(false); }
  };

  useEffect(() => { fetchUsers(); }, []);

  const filteredUsers = users.filter(u => {
    const phone = u.phoneNumber || '';
    const name = u.name || '';
    return phone.includes(search) || name.toLowerCase().includes(search.toLowerCase());
  });

  // --- CRUD ACTIONS ---

  const handleDeleteUser = async () => {
      if (!deleteConfirmUser) return;
      try {
          await api.deleteUser(deleteConfirmUser);
          setUsers(prev => prev.filter(u => u.id !== deleteConfirmUser));
          showToast("User Deleted Permanently", 'success');
      } catch (e) {
          showToast("Delete Failed", 'error');
      } finally {
          setDeleteConfirmUser(null);
      }
  };

  const handleSendNotification = async () => {
      if (!notifData.title || !notifData.message) return showToast("Title and Message required", 'error');
      try {
          await api.sendNotification(notifData.title, notifData.message, notifTarget?.id);
          showToast(notifTarget ? "Message Sent to User" : "Broadcast Sent to All", 'success');
          setShowNotifModal(false);
          setNotifData({ title: '', message: '' });
      } catch (e) {
          showToast("Failed to send", 'error');
      }
  };

  // --- EDIT ACTIONS ---

  const startEdit = (user: User) => {
    setEditingUser(user.id);
    setEditForm({ 
        vipLevel: user.vipLevel,
        name: user.name || '',
        password: user.password || '' 
    });
  };

  const saveEdit = async () => {
    if (!editingUser || !editForm) return;
    try {
        await api.adminUpdateUser(editingUser, { 
            vipLevel: editForm.vipLevel,
            name: editForm.name,
            password: editForm.password
        });
        showToast("User Updated", 'success');
        setUsers(prev => prev.map(u => u.id === editingUser ? { ...u, ...editForm } : u));
        setEditingUser(null);
    } catch (e) {
        showToast("Update Failed", 'error');
    }
  };

  const toggleBan = async (user: User) => {
      const newStatus = !user.isBanned;
      try {
          await api.adminUpdateUser(user.id, { isBanned: newStatus });
          setUsers(prev => prev.map(u => u.id === user.id ? { ...u, isBanned: newStatus } : u));
          showToast(`User ${newStatus ? 'Banned' : 'Unbanned'}`, 'info');
      } catch (e) {
          showToast("Failed", 'error');
      }
  };

  const openNotifModal = (user?: User) => {
      if (user) {
          setNotifTarget({ id: user.id, name: user.name || user.phoneNumber });
      } else {
          setNotifTarget(null); // Broadcast
      }
      setShowNotifModal(true);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <h2 className="text-2xl font-bold text-slate-800">User Management</h2>
          <div className="flex space-x-2">
              <button 
                onClick={fetchUsers} 
                className="p-2.5 bg-white text-blue-600 rounded-xl hover:bg-blue-50 border border-slate-200 shadow-sm transition-colors"
                title="Refresh"
              >
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
              </button>
              <button 
                onClick={() => openNotifModal()}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-bold shadow-sm"
              >
                  <Send size={18} />
                  <span className="hidden sm:inline">Broadcast</span>
              </button>
          </div>
      </div>
      
      <div className="mb-6 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
        <input 
            type="text" 
            placeholder="Search by Phone or Name" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-xl pl-10 pr-4 py-3 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-slate-800 shadow-sm"
        />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-xs border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">User Info</th>
                <th className="px-6 py-4">Balance</th>
                <th className="px-6 py-4">VIP Level</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                 <tr><td colSpan={5} className="text-center py-10 text-slate-500">Loading...</td></tr>
              ) : filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                        {editingUser === user.id ? (
                            <div className="space-y-1">
                                <input 
                                    type="text" 
                                    value={editForm?.name} 
                                    onChange={e => setEditForm(prev => ({ ...prev!, name: e.target.value }))}
                                    className="bg-white border border-slate-300 px-2 py-1 rounded w-full text-slate-900 text-xs"
                                    placeholder="Name"
                                />
                                <div className="text-xs text-slate-500">{user.phoneNumber}</div>
                                <input 
                                    type="text" 
                                    value={editForm?.password} 
                                    onChange={e => setEditForm(prev => ({ ...prev!, password: e.target.value }))}
                                    className="bg-white border border-slate-300 px-2 py-1 rounded w-full text-slate-900 text-xs mt-1"
                                    placeholder="New Password"
                                />
                            </div>
                        ) : (
                            <div>
                                <div className="font-bold text-slate-900">{user.name}</div>
                                <div className="text-xs text-slate-500">{user.phoneNumber}</div>
                                {user.password && <div className="text-[10px] text-slate-400 mt-0.5">Pass: {user.password}</div>}
                                {user.isAdmin && <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-bold border border-blue-200">ADMIN</span>}
                            </div>
                        )}
                    </td>
                    <td className="px-6 py-4">
                        <span className="font-bold text-green-600">৳{(user.balance || 0).toFixed(2)}</span>
                    </td>
                    <td className="px-6 py-4">
                         {editingUser === user.id ? (
                            <select 
                                value={editForm?.vipLevel}
                                onChange={e => setEditForm(prev => ({ ...prev!, vipLevel: parseInt(e.target.value) }))}
                                className="bg-white border border-slate-300 px-2 py-1 rounded text-slate-900 text-xs"
                            >
                                {[0,1,2,3,4,5].map(l => <option key={l} value={l}>Level {l}</option>)}
                            </select>
                        ) : (
                            <span className="bg-slate-100 px-2 py-1 rounded text-xs border border-slate-200 font-medium text-slate-700">Level {user.vipLevel}</span>
                        )}
                    </td>
                    <td className="px-6 py-4">
                        {user.isBanned ? (
                            <span className="bg-red-100 text-red-600 px-2 py-1 rounded text-xs font-bold border border-red-200">BANNED</span>
                        ) : (
                            <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs font-bold border border-green-200">ACTIVE</span>
                        )}
                    </td>
                    <td className="px-6 py-4 text-right">
                        {editingUser === user.id ? (
                            <div className="flex justify-end space-x-2">
                                <button onClick={saveEdit} className="p-2 bg-green-600 text-white rounded hover:bg-green-500"><Save size={16}/></button>
                                <button onClick={() => setEditingUser(null)} className="p-2 bg-slate-200 text-slate-600 rounded hover:bg-slate-300"><X size={16}/></button>
                            </div>
                        ) : (
                            <div className="flex justify-end space-x-2">
                                <button onClick={() => openNotifModal(user)} className="p-2 bg-slate-100 hover:bg-slate-200 text-blue-500 rounded border border-slate-200" title="Message User"><MessageSquare size={16}/></button>
                                <button onClick={() => startEdit(user)} className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded border border-slate-200" title="Edit User"><Edit2 size={16}/></button>
                                <button onClick={() => toggleBan(user)} className={`p-2 rounded border ${user.isBanned ? 'bg-green-100 text-green-600 border-green-200' : 'bg-yellow-100 text-yellow-600 border-yellow-200'}`} title={user.isBanned ? "Unban" : "Ban"}>
                                    {user.isBanned ? <CheckCircle size={16}/> : <Ban size={16}/>}
                                </button>
                                <button onClick={() => setDeleteConfirmUser(user.id)} className="p-2 bg-red-50 hover:bg-red-100 text-red-500 rounded border border-red-100" title="Delete User">
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        )}
                    </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- MODALS --- */}

      {/* Notification Modal */}
      {showNotifModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in p-4">
              <div className="bg-white w-full max-w-sm rounded-2xl p-6 border border-slate-200 shadow-2xl">
                  <h3 className="text-lg font-bold text-slate-800 mb-2">
                      {notifTarget ? `Message to ${notifTarget.name}` : 'Broadcast to ALL Users'}
                  </h3>
                  {!notifTarget && <p className="text-xs text-orange-500 mb-4 font-medium flex items-center"><AlertTriangle size={12} className="mr-1"/> Warning: Sends to everyone.</p>}
                  
                  <div className="space-y-3 mt-4">
                      <input 
                        type="text" placeholder="Title" 
                        className="w-full bg-slate-50 p-3 rounded-lg text-slate-900 border border-slate-300 font-bold outline-none focus:border-blue-500"
                        value={notifData.title} onChange={e => setNotifData({...notifData, title: e.target.value})}
                      />
                      <textarea 
                        placeholder="Message content..." 
                        rows={4}
                        className="w-full bg-slate-50 p-3 rounded-lg text-slate-900 border border-slate-300 resize-none outline-none focus:border-blue-500"
                        value={notifData.message} onChange={e => setNotifData({...notifData, message: e.target.value})}
                      />
                  </div>
                  <div className="flex space-x-3 mt-6">
                      <button onClick={() => setShowNotifModal(false)} className="flex-1 py-2 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 font-medium">Cancel</button>
                      <button onClick={handleSendNotification} className="flex-1 py-2 rounded-lg bg-blue-600 text-white font-bold flex justify-center items-center hover:bg-blue-700 shadow-md">
                          <Send size={16} className="mr-2" /> Send
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in p-4">
           <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-sm shadow-2xl">
               <div className="flex justify-center mb-4 text-red-500 bg-red-50 p-4 rounded-full w-16 h-16 mx-auto">
                   <AlertTriangle size={32} />
               </div>
               <h3 className="text-lg font-bold text-center text-slate-800 mb-2">Delete User?</h3>
               <p className="text-center text-slate-500 mb-6">
                   This action is irreversible. The user will be permanently removed from the database.
               </p>
               <div className="flex space-x-3">
                   <button onClick={() => setDeleteConfirmUser(null)} className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-600 font-medium hover:bg-slate-200">Cancel</button>
                   <button onClick={handleDeleteUser} className="flex-1 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-md">Delete</button>
               </div>
           </div>
        </div>
      )}

    </div>
  );
};

export default AdminUsers;
