
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { User, Transaction } from '../../types';
import { CheckCircle, XCircle, Loader2, Copy, RefreshCw } from 'lucide-react';
import { useToast } from '../../components/ToastContext';

const AdminWithdrawals: React.FC = () => {
  const { showToast } = useToast();
  const [requests, setRequests] = useState<{user: User, tx: Transaction}[]>([]);
  const [loading, setLoading] = useState(true);
  const [processId, setProcessId] = useState<string | null>(null);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const data = await api.getAllPendingWithdrawals();
      setRequests(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleAction = async (userId: string, txId: string, amount: number, action: 'APPROVE' | 'REJECT') => {
    setProcessId(txId);
    try {
      if (action === 'APPROVE') {
        await api.approveWithdrawal(userId, txId);
        showToast("Withdrawal Marked as Sent", 'success');
      } else {
        await api.rejectWithdrawal(userId, txId, amount);
        showToast("Withdrawal Rejected & Refunded", 'info');
      }
      setRequests(prev => prev.filter(item => item.tx.id !== txId));
    } catch (error) {
      showToast("Operation Failed", 'error');
    } finally {
      setProcessId(null);
    }
  };

  const copyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    showToast("Number Copied", 'success');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Pending Withdrawals</h2>
        <button 
            onClick={fetchRequests} 
            className="p-2.5 bg-white text-blue-600 rounded-xl hover:bg-blue-50 border border-slate-200 shadow-sm transition-colors"
            title="Refresh"
        >
          <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-xs border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Req. Amount</th>
                <th className="px-6 py-4">Payable (85%)</th>
                <th className="px-6 py-4">Method</th>
                <th className="px-6 py-4">To Number</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={6} className="text-center py-10"><Loader2 className="animate-spin inline mr-2 text-blue-500" /> Loading...</td></tr>
              ) : requests.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">No pending withdrawals.</td></tr>
              ) : (
                requests.map(({ user, tx }) => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-bold text-slate-900">{user.name}</div>
                      <div className="text-xs text-slate-500">{user.phoneNumber}</div>
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-800">৳{tx.amount}</td>
                    <td className="px-6 py-4 font-bold text-red-500">
                      ৳{(tx.amount * 0.85).toFixed(2)}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${tx.method === 'bKash' ? 'bg-pink-100 text-pink-600 border border-pink-200' : 'bg-orange-100 text-orange-600 border border-orange-200'}`}>
                        {tx.method}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                         <span className="font-mono text-slate-700 font-bold select-all">{tx.senderNumber}</span>
                         <button onClick={() => copyNumber(tx.senderNumber || '')} className="text-slate-400 hover:text-slate-700"><Copy size={14} /></button>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end space-x-2">
                        <button 
                          onClick={() => handleAction(user.id, tx.id, tx.amount, 'APPROVE')}
                          disabled={!!processId}
                          className="p-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50 shadow-sm"
                          title="Confirm Sent"
                        >
                          {processId === tx.id ? <Loader2 size={16} className="animate-spin"/> : <CheckCircle size={16} />}
                        </button>
                        <button 
                          onClick={() => handleAction(user.id, tx.id, tx.amount, 'REJECT')}
                          disabled={!!processId}
                          className="p-2 bg-red-600 text-white rounded hover:bg-red-700 disabled:opacity-50 shadow-sm"
                          title="Reject & Refund"
                        >
                          <XCircle size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminWithdrawals;
