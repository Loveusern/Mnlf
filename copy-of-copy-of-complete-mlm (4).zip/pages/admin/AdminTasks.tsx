
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { Task, TaskPlatform } from '../../types';
import { Trash2, Plus, Link as LinkIcon, Clock, DollarSign, AlertTriangle, Loader2, Check, FileText, RefreshCw } from 'lucide-react';
import { useToast } from '../../components/ToastContext';

const AdminTasks: React.FC = () => {
  const { showToast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [loadingAction, setLoadingAction] = useState(false);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState<string|null>(null);
  
  const [newTask, setNewTask] = useState<Partial<Task>>({
      platform: 'GENERIC',
      durationSeconds: 30,
      reward: 0,
      tag: 'Ad',
      description: '30s'
  });

  const loadTasks = async () => {
      setLoading(true);
      const data = await api.getTasks();
      setTasks(data);
      setLoading(false);
  };

  useEffect(() => { loadTasks(); }, []);

  const handleCreate = async () => {
      if (!newTask.title || !newTask.url) return showToast("Title and URL required", 'error');
      
      setLoadingAction(true);
      try {
          const taskToCreate = {
              ...newTask,
              description: newTask.description || `${newTask.durationSeconds}s`
          };
          
          await api.createTask(taskToCreate as Task);
          showToast("Task Created Successfully", 'success');
          setIsCreating(false);
          loadTasks();
          setNewTask({ platform: 'GENERIC', durationSeconds: 30, reward: 0, tag: 'Ad', description: '30s' });
      } catch (e: any) {
          console.error(e);
          if (e.message.includes('Update Required')) {
              showToast("SQL Update Required! Go to Settings > Security", 'error');
          } else {
              showToast(e.message || "Error creating task", 'error');
          }
      } finally {
          setLoadingAction(false);
      }
  };

  const confirmDelete = async () => {
      if (!deleteId) return;
      try {
          await api.deleteTask(deleteId);
          showToast("Task Deleted", 'info');
          loadTasks();
      } catch (e: any) {
          if (e.message.includes('Update Required')) {
              showToast("SQL Update Required! Go to Settings > Security", 'error');
          } else {
              showToast("Error deleting task", 'error');
          }
      } finally {
          setDeleteId(null);
      }
  };

  return (
    <div className="max-w-4xl mx-auto relative">
      <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Task Management</h2>
          <div className="flex space-x-2">
              <button 
                onClick={loadTasks} 
                className="p-2.5 bg-white text-blue-600 rounded-xl hover:bg-blue-50 border border-slate-200 shadow-sm transition-colors"
                title="Refresh"
              >
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
              </button>
              <button 
                onClick={() => setIsCreating(!isCreating)}
                className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-blue-700 shadow-md"
              >
                  <Plus size={20} />
                  <span>{isCreating ? 'Cancel' : 'Add Task'}</span>
              </button>
          </div>
      </div>

      {isCreating && (
          <div className="bg-white p-6 rounded-2xl mb-8 border border-slate-200 animate-slide-down shadow-md">
              <h3 className="font-bold mb-4 text-lg text-slate-800">New Task Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <input 
                    className="bg-slate-50 border border-slate-300 p-3 rounded-xl text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all" 
                    placeholder="Task Title"
                    value={newTask.title || ''}
                    onChange={e => setNewTask({...newTask, title: e.target.value})}
                  />
                  <input 
                    className="bg-slate-50 border border-slate-300 p-3 rounded-xl text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all" 
                    placeholder="Tag (e.g. VIP 1, Ad)"
                    value={newTask.tag || ''}
                    onChange={e => setNewTask({...newTask, tag: e.target.value})}
                  />
                  <input 
                    className="bg-slate-50 border border-slate-300 p-3 rounded-xl text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all" 
                    placeholder="Target URL (https://...)"
                    value={newTask.url || ''}
                    onChange={e => setNewTask({...newTask, url: e.target.value})}
                  />
                  <select 
                     className="bg-slate-50 border border-slate-300 p-3 rounded-xl text-slate-900 outline-none focus:border-blue-500 transition-all"
                     value={newTask.platform}
                     onChange={e => setNewTask({...newTask, platform: e.target.value as TaskPlatform})}
                  >
                      <option value="GENERIC">Generic Website</option>
                      <option value="YOUTUBE">YouTube</option>
                      <option value="FACEBOOK">Facebook</option>
                      <option value="WIKIPEDIA">Wikipedia</option>
                  </select>
                  <div className="flex items-center space-x-2 bg-slate-50 border border-slate-300 p-3 rounded-xl focus-within:border-blue-500 transition-all">
                      <Clock size={16} className="text-slate-400" />
                      <input 
                        type="number"
                        className="bg-transparent outline-none text-slate-900 w-full"
                        placeholder="Duration (sec)"
                        value={newTask.durationSeconds}
                        onChange={e => setNewTask({...newTask, durationSeconds: parseInt(e.target.value), description: `${e.target.value}s`})}
                      />
                  </div>
                  <div className="flex items-center space-x-2 bg-slate-50 border border-slate-300 p-3 rounded-xl focus-within:border-blue-500 transition-all">
                      <FileText size={16} className="text-slate-400" />
                      <input 
                        type="text"
                        className="bg-transparent outline-none text-slate-900 w-full"
                        placeholder="Description (e.g. 30s)"
                        value={newTask.description || ''}
                        onChange={e => setNewTask({...newTask, description: e.target.value})}
                      />
                  </div>
              </div>
              
              <div className="flex items-center text-xs text-orange-600 mb-4 bg-orange-50 p-3 rounded-lg border border-orange-200">
                  <AlertTriangle size={14} className="mr-2 flex-shrink-0" />
                  Note: The reward amount shown to users is determined automatically by their VIP Level settings.
              </div>

              <div className="flex justify-end">
                  <button 
                    onClick={handleCreate} 
                    disabled={loadingAction}
                    className="bg-green-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-green-700 flex items-center shadow-lg disabled:opacity-50 transition-colors"
                  >
                      {loadingAction ? <Loader2 className="animate-spin mr-2" size={18}/> : <Check size={18} className="mr-2"/>}
                      Save Task
                  </button>
              </div>
          </div>
      )}

      <div className="space-y-3">
          {tasks.map(task => (
              <div key={task.id} className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center group hover:shadow-md transition-all">
                  <div>
                      <h4 className="font-bold text-slate-900 text-sm sm:text-base">{task.title}</h4>
                      <div className="flex space-x-3 text-xs text-slate-500 mt-1">
                          <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">{task.platform}</span>
                          <span className="flex items-center"><Clock size={10} className="mr-1"/> {task.durationSeconds}s</span>
                          <span className="flex items-center"><FileText size={10} className="mr-1"/> {task.description}</span>
                          <span className="flex items-center font-bold"><DollarSign size={10} className="mr-1 text-green-600"/> VIP Rate</span>
                      </div>
                      <a href={task.url} target="_blank" rel="noreferrer" className="text-[10px] text-blue-500 hover:underline flex items-center mt-2 opacity-80 hover:opacity-100 transition-opacity">
                          <LinkIcon size={10} className="mr-1" /> {task.url}
                      </a>
                  </div>
                  <button 
                    onClick={() => setDeleteId(task.id)} 
                    className="p-2 bg-slate-50 text-slate-400 rounded-lg hover:bg-red-50 hover:text-red-600 transition-all border border-slate-200"
                  >
                      <Trash2 size={18} />
                  </button>
              </div>
          ))}
          {tasks.length === 0 && <div className="text-center text-slate-400 py-10 border-2 border-dashed border-slate-200 rounded-xl">No tasks created yet.</div>}
      </div>

      {/* Confirmation Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in p-4">
           <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-sm shadow-2xl">
               <div className="flex justify-center mb-4 text-red-500 bg-red-50 p-4 rounded-full w-16 h-16 mx-auto">
                   <Trash2 size={32} />
               </div>
               <h3 className="text-lg font-bold text-center text-slate-800 mb-2">Delete Task?</h3>
               <p className="text-center text-slate-500 mb-6">This action cannot be undone.</p>
               <div className="flex space-x-3">
                   <button onClick={() => setDeleteId(null)} className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-600 font-medium hover:bg-slate-200">Cancel</button>
                   <button onClick={confirmDelete} className="flex-1 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-md">Delete</button>
               </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminTasks;
