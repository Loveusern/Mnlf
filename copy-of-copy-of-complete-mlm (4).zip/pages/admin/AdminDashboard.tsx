
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { User, AppNotification } from '../../types';
import { Users, Wallet, ArrowDownCircle, ArrowUpCircle, RefreshCw, Send, Trash2 } from 'lucide-react';
import { useToast } from '../../components/ToastContext';

const AdminDashboard: React.FC = () => {
  const { showToast } = useToast();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalBalance: 0,
    pendingDeposits: 0,
    pendingWithdrawals: 0
  });
  const [broadcasts, setBroadcasts] = useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // New Broadcast Form
  const [newTitle, setNewTitle] = useState('');
  const [newMsg, setNewMsg] = useState('');

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [users, settings] = await Promise.all([api.getAllUsers(), api.getSettings()]);
      
      let balance = 0;
      let pDep = 0;
      let pWit = 0;

      users.forEach(u => {
        balance += u.balance || 0;
        if (u.depositHistory) {
            pDep += u.depositHistory.filter(t => t.status === 'PENDING').length;
        }
        if (u.withdrawHistory) {
            pWit += u.withdrawHistory.filter(t => t.status === 'PENDING').length;
        }
      });

      setStats({
        totalUsers: users.length,
        totalBalance: balance,
        pendingDeposits: pDep,
        pendingWithdrawals: pWit
      });

      setBroadcasts(settings.broadcasts || []);

    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSendBroadcast = async () => {
      if (!newTitle || !newMsg) return showToast("Title and Message required", 'error');
      try {
          await api.sendNotification(newTitle, newMsg);
          showToast("Broadcast Sent!", 'success');
          setNewTitle('');
          setNewMsg('');
          fetchData(); // Reload list
      } catch (e) {
          showToast("Failed to send", 'error');
      }
  };

  const handleDeleteBroadcast = async (id: string) => {
      if (!window.confirm("Delete this broadcast? It will be removed for all users.")) return;
      try {
          await api.deleteBroadcast(id);
          showToast("Broadcast Deleted", 'info');
          fetchData();
      } catch (e) {
          showToast("Delete Failed", 'error');
      }
  };

  const StatCard = ({ icon: Icon, label, value, color, bg }: any) => (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-slate-500 text-sm mb-1 font-medium">{label}</p>
          <h3 className="text-2xl font-bold text-slate-800">{isLoading ? '...' : value}</h3>
        </div>
        <div className={`p-3 rounded-xl ${bg}`}>
          <Icon size={24} className={color} />
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Dashboard</h2>
        <button 
            onClick={fetchData} 
            className="p-2.5 bg-white text-blue-600 rounded-xl hover:bg-blue-50 border border-slate-200 shadow-sm transition-colors"
            title="Refresh Data"
        >
          <RefreshCw size={20} className={isLoading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          icon={Users} 
          label="Total Users" 
          value={stats.totalUsers} 
          color="text-blue-600"
          bg="bg-blue-50"
        />
        <StatCard 
          icon={Wallet} 
          label="User Holdings" 
          value={`৳${stats.totalBalance.toLocaleString()}`} 
          color="text-green-600"
          bg="bg-green-50"
        />
        <StatCard 
          icon={ArrowDownCircle} 
          label="Pending Deposits" 
          value={stats.pendingDeposits} 
          color="text-orange-600"
          bg="bg-orange-50"
        />
        <StatCard 
          icon={ArrowUpCircle} 
          label="Pending Withdrawals" 
          value={stats.pendingWithdrawals} 
          color="text-red-600"
          bg="bg-red-50"
        />
      </div>

      {/* Broadcast Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Send Form */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
                  <Send size={20} className="mr-2 text-blue-600"/> Send Global Broadcast
              </h3>
              <div className="space-y-4">
                  <div>
                      <label className="text-xs text-slate-500 font-bold uppercase block mb-1">Title</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                        placeholder="Announcement Title"
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold uppercase block mb-1">Message</label>
                      <textarea 
                        rows={4}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all resize-none"
                        placeholder="Write message for all users..."
                        value={newMsg}
                        onChange={(e) => setNewMsg(e.target.value)}
                      />
                  </div>
                  <button 
                    onClick={handleSendBroadcast}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-200 transition-colors flex justify-center items-center"
                  >
                      <Send size={18} className="mr-2"/> Send to Everyone
                  </button>
              </div>
          </div>

          {/* History List */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col h-[450px] shadow-sm">
              <h3 className="text-lg font-bold text-slate-800 mb-4">Broadcast History</h3>
              <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                  {broadcasts.length === 0 ? (
                      <div className="text-center text-slate-400 py-10">No active broadcasts.</div>
                  ) : (
                      broadcasts.map(b => (
                          <div key={b.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200 relative group hover:shadow-md transition-all">
                              <div className="pr-8">
                                  <h4 className="font-bold text-sm text-slate-800">{b.title}</h4>
                                  <p className="text-xs text-slate-600 mt-1 line-clamp-2">{b.message}</p>
                                  <p className="text-[10px] text-slate-400 mt-2 font-mono">{new Date(b.date).toLocaleString()}</p>
                              </div>
                              <button 
                                onClick={() => handleDeleteBroadcast(b.id)}
                                className="absolute top-3 right-3 text-slate-400 hover:text-red-500 p-1 rounded hover:bg-red-50 transition-colors"
                                title="Delete Broadcast"
                              >
                                  <Trash2 size={16} />
                              </button>
                          </div>
                      ))
                  )}
              </div>
          </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
