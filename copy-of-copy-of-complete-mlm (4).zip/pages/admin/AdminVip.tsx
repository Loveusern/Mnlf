
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { SystemSettings, VipTier, DEFAULT_SETTINGS } from '../../types';
import { VIP_TIERS } from '../../constants';
import { Save, Plus, Trash2, Edit2, Crown, Loader2, AlertTriangle, Check, X, RefreshCw } from 'lucide-react';
import { useToast } from '../../components/ToastContext';

const AdminVip: React.FC = () => {
  const { showToast } = useToast();
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null); // Index to delete
  
  // Edit State
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editTier, setEditTier] = useState<VipTier | null>(null);

  const load = async () => {
      setLoading(true);
      try {
          const data = await api.getSettings();
          setSettings(data);
      } catch (e) {
          console.error(e);
      } finally {
          setLoading(false);
      }
  };

  useEffect(() => { load(); }, []);

  const handleSaveSettings = async (newSettings: SystemSettings) => {
    setSaving(true);
    try {
        await api.updateSettings(newSettings);
        setSettings(newSettings);
        showToast('VIP levels updated successfully!', 'success');
    } catch (e) {
        showToast('Failed to save settings', 'error');
    } finally {
        setSaving(false);
    }
  };

  const deleteTier = (index: number) => {
    const updatedTiers = settings.vipTiers.filter((_, i) => i !== index);
    const newSettings = { ...settings, vipTiers: updatedTiers };
    handleSaveSettings(newSettings);
    setDeleteConfirm(null);
  };

  const startEdit = (tier: VipTier, index: number) => {
      setEditingIndex(index);
      setEditTier({ ...tier });
  };

  const addNewTier = () => {
      const newLevel = settings.vipTiers.length > 0 
        ? Math.max(...settings.vipTiers.map(t => t.level)) + 1 
        : 0;

      const newTier: VipTier = {
          level: newLevel,
          name: `VIP ${newLevel}`,
          price: 5000,
          dailyIncome: 100,
          dailyTasks: 5,
          taskRate: 20,
          validityDays: 365,
          color: 'bg-gradient-to-br from-slate-700 to-slate-800'
      };
      setEditingIndex(settings.vipTiers.length);
      setEditTier(newTier);
  };

  const saveEdit = () => {
      if (editingIndex === null || !editTier) return;
      
      const newTiers = [...settings.vipTiers];
      if (editingIndex >= newTiers.length) {
          newTiers.push(editTier);
      } else {
          newTiers[editingIndex] = editTier;
      }
      
      newTiers.sort((a, b) => a.level - b.level);

      const newSettings = { ...settings, vipTiers: newTiers };
      handleSaveSettings(newSettings);
      setEditingIndex(null);
      setEditTier(null);
  };

  if (loading) return <div className="p-10 text-center"><Loader2 className="animate-spin mx-auto text-blue-500" /></div>;

  return (
    <div className="max-w-4xl mx-auto relative">
      <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-800">VIP Management</h2>
          <div className="flex space-x-2">
              <button 
                onClick={load} 
                className="p-2.5 bg-white text-blue-600 rounded-xl hover:bg-blue-50 border border-slate-200 shadow-sm transition-colors"
                title="Refresh"
              >
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
              </button>
              <button 
                onClick={addNewTier}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-bold shadow-md"
              >
                  <Plus size={20} />
                  <span>Add New Level</span>
              </button>
          </div>
      </div>
      
      {/* EDIT MODAL / FORM */}
      {(editingIndex !== null && editTier) && (
          <div className="bg-white border border-blue-200 p-6 rounded-2xl mb-8 animate-slide-down shadow-lg">
              <h3 className="font-bold text-lg text-blue-600 mb-4 flex items-center">
                  <Edit2 size={18} className="mr-2"/> 
                  {editingIndex >= settings.vipTiers.length ? 'Create New Level' : `Edit ${editTier.name}`}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Level ID</label>
                      <input 
                        type="number"
                        value={editTier.level}
                        onChange={e => setEditTier({...editTier, level: parseInt(e.target.value)})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-mono focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Plan Name</label>
                      <input 
                        type="text"
                        value={editTier.name}
                        onChange={e => setEditTier({...editTier, name: e.target.value})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Price (BDT)</label>
                      <input 
                        type="number"
                        value={editTier.price}
                        onChange={e => setEditTier({...editTier, price: parseInt(e.target.value)})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Daily Income (Display)</label>
                      <input 
                        type="number"
                        value={editTier.dailyIncome}
                        onChange={e => setEditTier({...editTier, dailyIncome: parseInt(e.target.value)})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Daily Task Count</label>
                      <input 
                        type="number"
                        value={editTier.dailyTasks}
                        onChange={e => setEditTier({...editTier, dailyTasks: parseInt(e.target.value)})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Rate Per Task (BDT)</label>
                      <input 
                        type="number"
                        value={editTier.taskRate}
                        onChange={e => setEditTier({...editTier, taskRate: parseFloat(e.target.value)})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Validity (Days)</label>
                      <input 
                        type="number"
                        value={editTier.validityDays}
                        onChange={e => setEditTier({...editTier, validityDays: parseInt(e.target.value)})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 focus:border-blue-500 outline-none"
                      />
                  </div>
                  <div>
                      <label className="text-xs text-slate-500 font-bold block mb-1">Color Theme (Tailwind)</label>
                      <input 
                        type="text"
                        value={editTier.color}
                        onChange={e => setEditTier({...editTier, color: e.target.value})}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 text-xs focus:border-blue-500 outline-none"
                      />
                  </div>
              </div>
              
              <div className="flex justify-end space-x-3">
                  <button onClick={() => setEditingIndex(null)} className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 font-bold">Cancel</button>
                  <button onClick={saveEdit} className="px-6 py-2 rounded-xl bg-green-600 hover:bg-green-700 font-bold text-white flex items-center shadow-md">
                     {saving ? <Loader2 className="animate-spin" /> : <><Check size={18} className="mr-1"/> Save Level</>}
                  </button>
              </div>
          </div>
      )}

      {/* LIST */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {settings.vipTiers.map((tier, idx) => (
              <div key={idx} className={`relative p-5 rounded-2xl shadow-lg overflow-hidden ${tier.color} text-white`}>
                  <div className="relative z-10 flex justify-between items-start">
                      <div>
                          <div className="flex items-center space-x-2">
                             <Crown size={20} className="text-yellow-400" />
                             <h3 className="font-bold text-xl">{tier.name}</h3>
                          </div>
                          <p className="opacity-80 text-sm mt-1">Level {tier.level}</p>
                      </div>
                      <div className="text-right">
                          <p className="text-2xl font-bold">৳{tier.price}</p>
                          <p className="text-xs opacity-70">{tier.validityDays} Days</p>
                      </div>
                  </div>

                  <div className="relative z-10 mt-4 grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-black/20 p-2 rounded backdrop-blur-sm">
                          <span className="block text-[10px] opacity-70">Tasks</span>
                          <span className="font-bold">{tier.dailyTasks}/day</span>
                      </div>
                      <div className="bg-black/20 p-2 rounded backdrop-blur-sm">
                          <span className="block text-[10px] opacity-70">Rate</span>
                          <span className="font-bold">৳{tier.taskRate}</span>
                      </div>
                  </div>

                  <div className="relative z-10 mt-4 flex justify-end space-x-2 border-t border-white/20 pt-3">
                      <button onClick={() => startEdit(tier, idx)} className="p-2 bg-white/20 hover:bg-white/30 rounded-lg backdrop-blur-sm transition-colors">
                          <Edit2 size={16} />
                      </button>
                      <button onClick={() => setDeleteConfirm(idx)} className="p-2 bg-red-600/80 hover:bg-red-600 rounded-lg text-white backdrop-blur-sm transition-colors">
                          <Trash2 size={16} />
                      </button>
                  </div>
              </div>
          ))}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirm !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in p-4">
           <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-sm shadow-2xl">
               <div className="flex justify-center mb-4 text-red-500 bg-red-50 p-4 rounded-full w-16 h-16 mx-auto">
                   <AlertTriangle size={32} />
               </div>
               <h3 className="text-lg font-bold text-center text-slate-800 mb-2">Delete VIP Level?</h3>
               <p className="text-center text-slate-500 mb-6">
                   Are you sure? Users currently on this plan might experience issues if it's removed.
               </p>
               <div className="flex space-x-3">
                   <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-600 font-bold hover:bg-slate-200">Cancel</button>
                   <button onClick={() => deleteTier(deleteConfirm)} className="flex-1 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-lg">Delete</button>
               </div>
           </div>
        </div>
      )}

    </div>
  );
};

export default AdminVip;
