
import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { SystemSettings, DEFAULT_SETTINGS, LotterySegment } from '../../types';
import { VIP_TIERS, LOTTERY_SEGMENTS } from '../../constants';
import { Save, Smartphone, DollarSign, Calendar, Percent, Loader2, CreditCard, Ticket, Image as ImageIcon, Link as LinkIcon, MessageCircle, Send, Download, FileText, Shield, Copy, Check, RefreshCw, Trash2 } from 'lucide-react';
import { useToast } from '../../components/ToastContext';

const AdminSettings: React.FC = () => {
  const { showToast } = useToast();
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'PAYMENT' | 'LIMITS' | 'COMMISSION' | 'LOTTERY' | 'UI' | 'EXTERNAL' | 'CERTIFICATE' | 'SECURITY'>('PAYMENT');
  
  const [newBkash, setNewBkash] = useState('');
  const [newNagad, setNewNagad] = useState('');
  const [newSliderImage, setNewSliderImage] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<{type: 'bKash'|'nagad', index: number} | null>(null);
  const [sqlCopied, setSqlCopied] = useState(false);

  const load = async () => {
      setLoading(true);
      try {
          const data = await api.getSettings();
          setSettings(data);
      } catch (e) {
          console.error(e);
      } finally {
          setLoading(false);
      }
  };

  useEffect(() => { load(); }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
        await api.updateSettings(settings);
        showToast('System settings updated successfully!', 'success');
    } catch (e) {
        showToast('Failed to save settings', 'error');
    } finally {
        setSaving(false);
    }
  };

  // --- Handlers ---
  const addNumber = (type: 'bKash' | 'Nagad') => {
      const list = type === 'bKash' ? (settings.paymentNumbers.bKash || []) : (settings.paymentNumbers.nagad || []);
      const newVal = type === 'bKash' ? newBkash : newNagad;
      if (list.length >= 5) return showToast(`Maximum 5 ${type} numbers allowed`, 'error');
      if (newVal.length < 11) return showToast("Invalid Number", 'error');
      const updatedList = [...list, newVal];
      setSettings(prev => ({...prev, paymentNumbers: {...prev.paymentNumbers, [type]: updatedList}}));
      if (type === 'bKash') setNewBkash(''); else setNewNagad('');
  };

  const confirmDelete = () => {
      if (!deleteConfirm) return;
      const { type, index } = deleteConfirm;
      const list = type === 'bKash' ? (settings.paymentNumbers.bKash || []) : (settings.paymentNumbers.nagad || []);
      const newList = list.filter((_, i) => i !== index);
      setSettings(prev => ({...prev, paymentNumbers: {...prev.paymentNumbers, [type]: newList}}));
      setDeleteConfirm(null);
      showToast(`${type} number removed. Click Save to persist.`, 'info');
  };

  const addSliderImage = () => {
      if (!newSliderImage) return showToast("Please enter an image URL", 'error');
      setSettings(prev => ({...prev, sliderImages: [...(prev.sliderImages || []), newSliderImage]}));
      setNewSliderImage('');
  };

  const removeSliderImage = (index: number) => {
      setSettings(prev => ({...prev, sliderImages: (prev.sliderImages || []).filter((_, i) => i !== index)}));
  };

  const updateLotterySegment = (index: number, field: keyof LotterySegment, value: string | number) => {
      const updatedSegments = [...(settings.lotterySegments || LOTTERY_SEGMENTS)];
      updatedSegments[index] = { ...updatedSegments[index], [field]: value };
      setSettings({ ...settings, lotterySegments: updatedSegments });
  };

  const securitySql = `-- SECURE AUTH & DATABASE SETUP
-- RUN THIS IN SQL EDITOR TO SECURE YOUR APP

-- 1. ENABLE RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- 2. SECURE LOGIN FUNCTION (RPC)
-- This moves password checking to the server side
CREATE OR REPLACE FUNCTION public.login_user_secure(p_phone text, p_password text)
RETURNS jsonb AS $$
DECLARE
  v_user public.users;
BEGIN
  SELECT * INTO v_user FROM public.users WHERE "phoneNumber" = p_phone;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  IF v_user.password <> p_password THEN
    RAISE EXCEPTION 'Incorrect password';
  END IF;

  IF v_user."isBanned" IS TRUE THEN
    RAISE EXCEPTION 'Account is banned';
  END IF;

  -- Update last login logic if needed here
  
  RETURN to_jsonb(v_user);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. SECURE REGISTER FUNCTION (RPC)
-- Handles duplicate checks and referral logic securely
CREATE OR REPLACE FUNCTION public.register_user_secure(
    p_id text,
    p_phone text,
    p_password text,
    p_name text,
    p_ref_code_input text,
    p_my_code text,
    p_join_date text,
    p_vip_expiry text,
    p_is_first_user boolean,
    p_master_code text
)
RETURNS void AS $$
DECLARE
  v_upline_id text;
  v_master_usage int;
BEGIN
  -- Check duplicate phone
  PERFORM 1 FROM public.users WHERE "phoneNumber" = p_phone;
  IF FOUND THEN
    RAISE EXCEPTION 'Phone number already registered';
  END IF;

  -- Handle Referral / First User Logic
  IF p_is_first_user = TRUE THEN
     -- First user is Admin, no upline needed
     v_upline_id := NULL;
  ELSE
     IF p_ref_code_input = p_master_code THEN
        -- Master Code Logic
        SELECT "masterCodeUsage" INTO v_master_usage FROM public.system_settings WHERE id = 'global';
        IF v_master_usage >= 1 THEN
            RAISE EXCEPTION 'Master code expired';
        END IF;
        
        UPDATE public.system_settings SET "masterCodeUsage" = "masterCodeUsage" + 1 WHERE id = 'global';
        -- Assign to first admin found as upline
        SELECT id INTO v_upline_id FROM public.users WHERE "isAdmin" = true LIMIT 1;
     ELSE
        -- Normal Referral
        SELECT id INTO v_upline_id FROM public.users WHERE "referralCode" = p_ref_code_input;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Invalid Referral Code';
        END IF;
     END IF;
  END IF;

  -- Insert User
  INSERT INTO public.users (
    id, "phoneNumber", password, name, "referralCode", "referredBy",
    "isAdmin", "isBanned", balance, "vipLevel", "vipExpiryDate",
    "todayEarnings", "totalEarnings", "joinDate", "withdrawalPin", "spinsAvailable"
  ) VALUES (
    p_id, p_phone, p_password, p_name, p_my_code, v_upline_id,
    p_is_first_user, false, 
    CASE WHEN p_is_first_user THEN 1000 ELSE 20 END, -- Initial Balance
    CASE WHEN p_is_first_user THEN 5 ELSE 0 END,     -- Initial VIP
    p_vip_expiry,
    0, 0, p_join_date, '1234',
    CASE WHEN p_is_first_user THEN 100 ELSE 1 END
  );

END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. BALANCE PROTECTION TRIGGER
CREATE OR REPLACE FUNCTION public.prevent_balance_hacking()
RETURNS TRIGGER AS $$
DECLARE
  current_role text;
BEGIN
  SELECT current_setting('role') INTO current_role;
  IF current_role = 'service_role' THEN RETURN NEW; END IF;

  -- Revert critical fields if changed by client directly
  IF (NEW.balance IS DISTINCT FROM OLD.balance) THEN NEW.balance := OLD.balance; END IF;
  IF (NEW."vipLevel" IS DISTINCT FROM OLD."vipLevel") THEN NEW."vipLevel" := OLD."vipLevel"; END IF;
  IF (NEW."totalEarnings" IS DISTINCT FROM OLD."totalEarnings") THEN NEW."totalEarnings" := OLD."totalEarnings"; END IF;
  IF (NEW."isAdmin" IS DISTINCT FROM OLD."isAdmin") THEN NEW."isAdmin" := OLD."isAdmin"; END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS secure_user_update ON public.users;
CREATE TRIGGER secure_user_update BEFORE UPDATE ON public.users
FOR EACH ROW EXECUTE FUNCTION public.prevent_balance_hacking();

-- 5. POLICIES
DROP POLICY IF EXISTS "Enable read for users based on id" ON public.users;
CREATE POLICY "Enable read for users based on id" ON public.users FOR SELECT USING (true);

DROP POLICY IF EXISTS "Enable insert for users" ON public.users;
CREATE POLICY "Enable insert for users" ON public.users FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Enable update for users" ON public.users;
CREATE POLICY "Enable update for users" ON public.users FOR UPDATE USING (true);

-- 6. ADMIN RPCs
CREATE OR REPLACE FUNCTION public.admin_update_settings(p_settings jsonb, p_admin_id text) RETURNS void AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT "isAdmin" INTO v_is_admin FROM public.users WHERE id = p_admin_id;
  IF v_is_admin IS TRUE THEN
    UPDATE public.system_settings SET settings = p_settings WHERE id = 'global';
    IF NOT FOUND THEN INSERT INTO public.system_settings (id, settings) VALUES ('global', p_settings); END IF;
  END IF;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_update_user(p_target_user_id text, p_updates jsonb, p_admin_id text) RETURNS void AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT "isAdmin" INTO v_is_admin FROM public.users WHERE id = p_admin_id;
  IF v_is_admin IS TRUE THEN
    UPDATE public.users SET
      name = COALESCE((p_updates->>'name'), name),
      "vipLevel" = COALESCE((p_updates->>'vipLevel')::int, "vipLevel"),
      "isBanned" = COALESCE((p_updates->>'isBanned')::boolean, "isBanned"),
      password = COALESCE((p_updates->>'password'), password)
    WHERE id = p_target_user_id;
  END IF;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;
`;

  const copySql = () => {
      navigator.clipboard.writeText(securitySql);
      setSqlCopied(true);
      showToast("SQL Copied! Run in Supabase SQL Editor.", 'success');
      setTimeout(() => setSqlCopied(false), 3000);
  };

  if (loading) return <div className="p-10 text-center"><Loader2 className="animate-spin mx-auto text-blue-500" /></div>;

  return (
    <div className="max-w-4xl mx-auto relative">
      <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-800">System Settings</h2>
          <div className="flex space-x-2">
              <button 
                onClick={load} 
                className="p-2.5 bg-white text-blue-600 rounded-xl hover:bg-blue-50 border border-slate-200 shadow-sm transition-colors"
                title="Refresh"
              >
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
              </button>
              <button 
                onClick={handleSave}
                disabled={saving}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-xl font-bold shadow-md transition-colors"
              >
                  {saving ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
                  <span>Save Changes</span>
              </button>
          </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 mb-6 border-b border-slate-200 pb-1 overflow-x-auto no-scrollbar">
          {['PAYMENT', 'LIMITS', 'COMMISSION', 'LOTTERY', 'UI', 'EXTERNAL', 'CERTIFICATE', 'SECURITY'].map(tab => (
               <button 
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`px-4 py-2 rounded-t-lg font-bold whitespace-nowrap transition-colors ${activeTab === tab ? 'bg-white text-blue-600 border-b-2 border-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
              >
                  {tab === 'PAYMENT' ? 'Payment' : tab === 'LIMITS' ? 'Limits' : tab === 'COMMISSION' ? 'Commission' : tab === 'LOTTERY' ? 'Lottery' : tab === 'UI' ? 'UI' : tab === 'EXTERNAL' ? 'Links' : tab === 'CERTIFICATE' ? 'Certificate' : 'Security'}
              </button>
          ))}
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          
          {/* PAYMENT NUMBERS */}
          {activeTab === 'PAYMENT' && (
              <div className="space-y-8 animate-fade-in">
                  {/* bKash */}
                  <div>
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="font-bold text-slate-800 flex items-center text-lg"><Smartphone className="mr-2 text-pink-600"/> bKash Numbers</h3>
                      </div>
                      <div className="flex space-x-2 mb-4">
                          <input 
                            type="text" 
                            placeholder="Add bKash Number" 
                            className="bg-slate-50 border border-slate-300 p-2 rounded-lg text-slate-900 flex-1 outline-none focus:border-pink-500"
                            value={newBkash}
                            onChange={(e) => setNewBkash(e.target.value)}
                          />
                          <button onClick={() => addNumber('bKash')} className="bg-pink-600 px-4 rounded-lg text-white font-bold hover:bg-pink-700 transition-colors">Add</button>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                          {(settings.paymentNumbers.bKash || []).map((num, idx) => (
                              <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex justify-between items-center">
                                  <span className="font-mono text-lg text-slate-800">{num}</span>
                                  <button onClick={() => setDeleteConfirm({ type: 'bKash', index: idx })} className="text-red-500 hover:bg-red-50 p-2 rounded"><Trash2 size={16} /></button>
                              </div>
                          ))}
                      </div>
                  </div>

                  <div className="h-[1px] bg-slate-100"></div>

                  {/* Nagad */}
                  <div>
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="font-bold text-slate-800 flex items-center text-lg"><Smartphone className="mr-2 text-orange-600"/> Nagad Numbers</h3>
                      </div>
                      <div className="flex space-x-2 mb-4">
                          <input 
                            type="text" 
                            placeholder="Add Nagad Number" 
                            className="bg-slate-50 border border-slate-300 p-2 rounded-lg text-slate-900 flex-1 outline-none focus:border-orange-500"
                            value={newNagad}
                            onChange={(e) => setNewNagad(e.target.value)}
                          />
                          <button onClick={() => addNumber('Nagad')} className="bg-orange-600 px-4 rounded-lg text-white font-bold hover:bg-orange-700 transition-colors">Add</button>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                          {(settings.paymentNumbers.nagad || []).map((num, idx) => (
                              <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex justify-between items-center">
                                  <span className="font-mono text-lg text-slate-800">{num}</span>
                                  <button onClick={() => setDeleteConfirm({ type: 'nagad', index: idx })} className="text-red-500 hover:bg-red-50 p-2 rounded"><Trash2 size={16} /></button>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>
          )}

          {/* LIMITS & SCHEDULE */}
          {activeTab === 'LIMITS' && (
              <div className="space-y-6 animate-fade-in">
                  {/* Withdraw Limits Per VIP */}
                  <div>
                      <h3 className="font-bold text-slate-800 mb-4 flex items-center"><CreditCard className="mr-2 text-green-600"/> Min Withdraw Limit per VIP Level</h3>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          {(settings.vipTiers.length > 0 ? settings.vipTiers : VIP_TIERS).map(tier => (
                              <div key={tier.level} className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                                  <label className="text-xs text-slate-500 block mb-1 font-bold">{tier.name} (Lvl {tier.level})</label>
                                  <div className="relative">
                                      <span className="absolute left-3 top-2 text-slate-400">৳</span>
                                      <input 
                                        type="number"
                                        value={settings.withdrawLimits[tier.level] || 0}
                                        onChange={(e) => setSettings({
                                            ...settings,
                                            withdrawLimits: { ...settings.withdrawLimits, [tier.level]: parseInt(e.target.value) }
                                        })}
                                        className="w-full bg-white border border-slate-300 rounded px-2 py-1 pl-6 text-slate-900 text-sm outline-none focus:border-blue-500"
                                      />
                                  </div>
                              </div>
                          ))}
                      </div>
                  </div>
                  {/* Deposit and Schedule UI remains same... */}
                  <div className="h-[1px] bg-slate-100"></div>
                  <div>
                      <h3 className="font-bold text-slate-800 mb-4 flex items-center"><DollarSign className="mr-2 text-blue-600"/> Global Deposit Limits</h3>
                      <div className="flex space-x-4">
                          <div className="flex-1">
                              <label className="text-xs text-slate-500 block mb-1 font-bold">Minimum Deposit</label>
                              <input type="number" value={settings.depositLimits.min} onChange={(e) => setSettings({...settings, depositLimits: {...settings.depositLimits, min: parseInt(e.target.value)}})} className="w-full bg-slate-50 border border-slate-300 rounded p-3 text-slate-900 outline-none focus:border-blue-500"/>
                          </div>
                          <div className="flex-1">
                              <label className="text-xs text-slate-500 block mb-1 font-bold">Maximum Deposit</label>
                              <input type="number" value={settings.depositLimits.max} onChange={(e) => setSettings({...settings, depositLimits: {...settings.depositLimits, max: parseInt(e.target.value)}})} className="w-full bg-slate-50 border border-slate-300 rounded p-3 text-slate-900 outline-none focus:border-blue-500"/>
                          </div>
                      </div>
                  </div>
                  <div>
                      <h3 className="font-bold text-slate-800 mb-4 flex items-center"><Calendar className="mr-2 text-purple-600"/> Withdrawal Schedule</h3>
                      <div className="flex space-x-4 mb-4">
                          <div><label className="text-xs text-slate-500 block mb-1 font-bold">Start Hour</label><input type="number" min="0" max="23" value={settings.schedule.startHour} onChange={(e) => setSettings({...settings, schedule: {...settings.schedule, startHour: parseInt(e.target.value)}})} className="bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 w-24 outline-none focus:border-blue-500"/></div>
                          <div><label className="text-xs text-slate-500 block mb-1 font-bold">End Hour</label><input type="number" min="0" max="23" value={settings.schedule.endHour} onChange={(e) => setSettings({...settings, schedule: {...settings.schedule, endHour: parseInt(e.target.value)}})} className="bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 w-24 outline-none focus:border-blue-500"/></div>
                      </div>
                      <div>
                          <label className="text-xs text-slate-500 block mb-2 font-bold">Off Days</label>
                          <div className="flex flex-wrap gap-2">
                              {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((day, idx) => (
                                  <button key={day} onClick={() => { const currentOff = settings.schedule.offDays || []; const newOff = currentOff.includes(idx) ? currentOff.filter(d => d !== idx) : [...currentOff, idx]; setSettings({...settings, schedule: {...settings.schedule, offDays: newOff}}); }} className={`px-3 py-1 rounded border text-sm transition-colors ${(settings.schedule.offDays || []).includes(idx) ? 'bg-red-100 border-red-300 text-red-600 font-bold' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'}`}>{day}</button>
                              ))}
                          </div>
                      </div>
                  </div>
                   <div>
                      <h3 className="font-bold text-slate-800 mb-4 flex items-center"><Percent className="mr-2 text-red-600"/> Task Failure Penalty</h3>
                      <div className="flex items-center space-x-2">
                          <input type="number" value={settings.taskPenaltyPercent} onChange={(e) => setSettings({...settings, taskPenaltyPercent: parseInt(e.target.value)})} className="bg-slate-50 border border-slate-300 rounded p-3 text-slate-900 w-24 text-center font-bold outline-none focus:border-red-500"/>
                          <span className="text-slate-500 text-sm">% deducted from task reward</span>
                      </div>
                   </div>
              </div>
          )}

          {/* OTHER TABS (Commission, Lottery, UI, etc.) remain largely the same, mostly UI code */}
          {/* COMMISSION */}
          {activeTab === 'COMMISSION' && (
              <div className="space-y-6 animate-fade-in">
                  <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                      <h3 className="font-bold text-yellow-700 mb-2">VIP Purchase Commission</h3>
                      <div className="flex space-x-4">
                          {[0, 1, 2].map(lvl => (
                              <div key={lvl} className="flex-1"><label className="text-xs text-yellow-700 block mb-1 font-bold">Level {lvl + 1} (%)</label><input type="number" value={settings.commissions.vip[lvl] || 0} onChange={(e) => { const newArr = [...settings.commissions.vip]; newArr[lvl] = parseFloat(e.target.value); setSettings({...settings, commissions: {...settings.commissions, vip: newArr}}); }} className="w-full bg-white border border-yellow-300 rounded p-2 text-slate-900 font-bold"/></div>
                          ))}
                      </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                      <h3 className="font-bold text-blue-700 mb-2">Task Earning Commission</h3>
                      <div className="flex space-x-4">
                          {[0, 1, 2].map(lvl => (
                              <div key={lvl} className="flex-1"><label className="text-xs text-blue-700 block mb-1 font-bold">Level {lvl + 1} (%)</label><input type="number" value={settings.commissions.task[lvl] || 0} onChange={(e) => { const newArr = [...settings.commissions.task]; newArr[lvl] = parseFloat(e.target.value); setSettings({...settings, commissions: {...settings.commissions, task: newArr}}); }} className="w-full bg-white border border-blue-300 rounded p-2 text-slate-900 font-bold"/></div>
                          ))}
                      </div>
                  </div>
              </div>
          )}

          {/* LOTTERY SETTINGS */}
          {activeTab === 'LOTTERY' && (
              <div className="space-y-6 animate-fade-in">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center"><Ticket className="mr-2 text-purple-600"/> Wheel Prizes</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {(settings.lotterySegments || LOTTERY_SEGMENTS).map((seg, idx) => (
                          <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                              <label className="text-xs text-slate-500 font-bold mb-1 block">Segment {idx + 1}</label>
                              <div className="space-y-2">
                                  <input type="number" placeholder="Value (BDT)" value={seg.value} onChange={(e) => updateLotterySegment(idx, 'value', parseInt(e.target.value))} className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900"/>
                                  <input type="text" placeholder="Label" value={seg.label} onChange={(e) => updateLotterySegment(idx, 'label', e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900"/>
                                  <input type="text" placeholder="Color Hex" value={seg.color} onChange={(e) => updateLotterySegment(idx, 'color', e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2 text-xs text-slate-900 font-mono"/>
                                  <div className="h-2 w-full rounded" style={{backgroundColor: seg.color}}></div>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          )}

          {/* UI SETTINGS */}
          {activeTab === 'UI' && (
              <div className="space-y-6 animate-fade-in">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center"><ImageIcon className="mr-2 text-blue-500"/> Slider Images</h3>
                  <div className="flex space-x-2 mb-4"><input type="text" placeholder="Image URL" className="bg-slate-50 border border-slate-300 p-2 rounded-lg text-slate-900 flex-1 outline-none focus:border-blue-500" value={newSliderImage} onChange={(e) => setNewSliderImage(e.target.value)}/><button onClick={addSliderImage} className="bg-blue-600 px-4 rounded-lg text-white font-bold hover:bg-blue-700 transition-colors">Add</button></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {(settings.sliderImages || []).map((img, idx) => (
                          <div key={idx} className="relative group rounded-xl overflow-hidden shadow-sm border border-slate-200"><img src={img} alt="Slider" className="w-full h-32 object-cover" /><button onClick={() => removeSliderImage(idx)} className="absolute top-2 right-2 bg-red-600/90 text-white p-2 rounded-lg hover:bg-red-700 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={16} /></button></div>
                      ))}
                  </div>
                  <div className="h-[1px] bg-slate-100 my-6"></div>
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center"><Smartphone className="mr-2 text-purple-600"/> Payment Logos</h3>
                  <div className="space-y-4">
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">bKash Logo URL</label><input type="text" value={settings.paymentLogos?.bKash || ''} onChange={(e) => setSettings({ ...settings, paymentLogos: { ...settings.paymentLogos, bKash: e.target.value }})} className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 outline-none focus:border-pink-500" placeholder="Enter image URL"/></div>
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">Nagad Logo URL</label><input type="text" value={settings.paymentLogos?.nagad || ''} onChange={(e) => setSettings({ ...settings, paymentLogos: { ...settings.paymentLogos, nagad: e.target.value }})} className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 outline-none focus:border-orange-500" placeholder="Enter image URL"/></div>
                  </div>
              </div>
          )}

          {/* EXTERNAL LINKS */}
          {activeTab === 'EXTERNAL' && (
              <div className="space-y-6 animate-fade-in">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center"><LinkIcon className="mr-2 text-indigo-500"/> Contact & App Links</h3>
                  <div className="space-y-4">
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">Telegram Link</label><div className="flex items-center space-x-2 bg-slate-50 border border-slate-300 rounded-lg p-2"><Send size={18} className="text-blue-400" /><input type="text" value={settings.externalLinks.telegram} onChange={(e) => setSettings({...settings, externalLinks: {...settings.externalLinks, telegram: e.target.value}})} className="bg-transparent w-full outline-none text-slate-900"/></div></div>
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">WhatsApp Link</label><div className="flex items-center space-x-2 bg-slate-50 border border-slate-300 rounded-lg p-2"><MessageCircle size={18} className="text-green-500" /><input type="text" value={settings.externalLinks.whatsapp} onChange={(e) => setSettings({...settings, externalLinks: {...settings.externalLinks, whatsapp: e.target.value}})} className="bg-transparent w-full outline-none text-slate-900"/></div></div>
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">App Download Link</label><div className="flex items-center space-x-2 bg-slate-50 border border-slate-300 rounded-lg p-2"><Download size={18} className="text-orange-500" /><input type="text" value={settings.externalLinks.appDownload} onChange={(e) => setSettings({...settings, externalLinks: {...settings.externalLinks, appDownload: e.target.value}})} className="bg-transparent w-full outline-none text-slate-900"/></div></div>
                  </div>
              </div>
          )}

          {/* CERTIFICATE SETTINGS */}
          {activeTab === 'CERTIFICATE' && (
              <div className="space-y-6 animate-fade-in">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center"><FileText className="mr-2 text-yellow-600"/> Certificate Config</h3>
                  <div className="space-y-4">
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">Authorized Signature Name</label><input type="text" value={settings.certificateConfig.signatureName} onChange={(e) => setSettings({...settings, certificateConfig: {...settings.certificateConfig, signatureName: e.target.value}})} className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 outline-none focus:border-yellow-500" placeholder="e.g. CEO_MNLife"/></div>
                      <div><label className="text-xs text-slate-500 font-bold block mb-1">Mission Statement (Footer)</label><textarea rows={3} value={settings.certificateConfig.missionStatement} onChange={(e) => setSettings({...settings, certificateConfig: {...settings.certificateConfig, missionStatement: e.target.value}})} className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 outline-none focus:border-yellow-500 resize-none" placeholder="Enter company tagline..."/></div>
                  </div>
              </div>
          )}

          {/* SECURITY TAB */}
          {activeTab === 'SECURITY' && (
              <div className="space-y-6 animate-fade-in">
                  <div className="bg-red-50 p-6 rounded-xl border border-red-200">
                      <h3 className="font-bold text-red-700 mb-4 flex items-center">
                          <Shield className="mr-2"/> Database Security Lock
                      </h3>
                      
                      <p className="text-sm text-red-800 mb-4 leading-relaxed">
                          This SQL prevents standard users from hacking their balance or VIP level. It also secures the <b>Login and Registration</b> process by moving it to the database server.
                      </p>

                      <div className="relative group">
                          <button 
                            onClick={copySql} 
                            className="absolute top-2 right-2 bg-slate-200 hover:bg-slate-300 text-slate-800 px-3 py-1.5 rounded text-xs font-bold flex items-center transition-all"
                          >
                              {sqlCopied ? <Check size={14} className="mr-1"/> : <Copy size={14} className="mr-1"/>}
                              {sqlCopied ? 'Copied' : 'Copy SQL'}
                          </button>
                          <pre className="bg-slate-100 p-4 rounded-xl border border-slate-300 text-[10px] text-slate-600 font-mono h-64 overflow-y-auto">
                              {securitySql}
                          </pre>
                      </div>
                  </div>
              </div>
          )}
      </div>

      {/* Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in p-4">
           <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-sm shadow-2xl">
               <h3 className="text-lg font-bold text-center text-slate-800 mb-2">Confirm Deletion</h3>
               <p className="text-center text-slate-500 mb-6">Are you sure you want to remove this number?</p>
               <div className="flex space-x-3">
                   <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-600 font-bold hover:bg-slate-200">Cancel</button>
                   <button onClick={confirmDelete} className="flex-1 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-lg">Delete</button>
               </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminSettings;
