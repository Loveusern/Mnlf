
import React, { useState, useEffect, useMemo } from 'react';
import { User, TeamActivity, ReferralMember, SystemSettings, DEFAULT_SETTINGS } from '../types';
import { Copy, Share2, Wallet, ArrowDownCircle, ArrowUpCircle, UserPlus, Crown, List as ListIcon, Activity as ActivityIcon, QrCode, Lock, XCircle, CheckCircle, Clock, ChevronDown, Loader2, Users, PieChart, RefreshCcw, TrendingUp, DollarSign, Percent, ArrowRightLeft, Calendar, Filter, X, Zap } from 'lucide-react';
import { VIP_TIERS } from '../constants';
import { Link } from 'react-router-dom';
import { useToast } from '../components/ToastContext';
import { api } from '../services/api';
import PageLoadingOverlay from '../components/PageLoadingOverlay';

interface TeamProps {
  user: User;
}

const Team: React.FC<TeamProps> = ({ user }) => {
  const { showToast } = useToast();
  const [activeLevel, setActiveLevel] = useState<1 | 2 | 3>(1);
  const [viewMode, setViewMode] = useState<'MEMBERS' | 'ACTIVITY'>('MEMBERS');
  const [showQr, setShowQr] = useState(false);
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const [teamMembers, setTeamMembers] = useState<ReferralMember[]>([]);
  const [isLoadingTeam, setIsLoadingTeam] = useState(true);
  const [activities, setActivities] = useState<TeamActivity[]>([]);
  
  const [visibleActivitiesCount, setVisibleActivitiesCount] = useState(10);
  
  const [teamStats, setTeamStats] = useState({
    totalTeamDeposit: 0,
    todayTeamEarn: 0,
    totalMembers: 0,
    vipMembers: 0,
    nonVipMembers: 0,
    totalTeamWithdraw: 0,
    myTotalIncome: 0
  });

  useEffect(() => {
    const init = async () => {
        setIsLoadingTeam(true);
        
        // Try load from cache first
        const cacheKey = `mnlife_team_${user.id}`;
        const cachedMembers = api.getFromCache<ReferralMember[]>(cacheKey);
        const cachedSettings = api.getFromCache<SystemSettings>('mnlife_settings_data');
        
        if (cachedMembers) {
            setTeamMembers(cachedMembers);
            if (cachedSettings) setSettings(cachedSettings);
            setIsLoadingTeam(false); // Immediate unlock
        }

        try {
            const joinDate = user.joinDate ? new Date(user.joinDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
            const today = new Date().toISOString().split('T')[0];
            setDateFrom(joinDate);
            setDateTo(today);

            const [s, members] = await Promise.all([
                api.getSettings(),
                api.getTeam(user.id)
            ]);
            
            setSettings(s);
            setTeamMembers(members);
        } catch(e) { 
            console.error("Failed to load team", e); 
        } finally {
            setIsLoadingTeam(false);
        }
    };
    init();
  }, [user.id]);

  const derivedActivities: TeamActivity[] = useMemo(() => {
    const acts: TeamActivity[] = [];
    
    if (teamMembers.length > 0) {
        teamMembers.forEach(m => {
            const isToday = new Date(m.lastActiveDate || 0).toDateString() === new Date().toDateString();
            
            acts.push({
                id: `join_${m.id}`,
                memberId: m.id,
                memberPhone: m.phoneNumber,
                memberLevel: m.level,
                type: 'JOIN',
                amount: 0,
                commission: 0,
                date: m.joinDate
            });

            if (isToday) {
                for (let i = 0; i < m.tasksCompletedToday; i++) {
                    acts.push({
                        id: `work_${m.id}_${i}`,
                        memberId: m.id,
                        memberPhone: m.phoneNumber,
                        memberLevel: m.level,
                        type: 'WORK_COMPLETE',
                        amount: 0, 
                        commission: 0, 
                        date: m.lastActiveDate || new Date().toISOString()
                    });
                }
            }
        });
    }

    if (user.earningHistory) {
        user.earningHistory.filter(tx => tx.type === 'BONUS').forEach(tx => {
             const relatedMember = teamMembers.find(r => r.phoneNumber === tx.senderNumber);
             const isVipBonus = tx.method?.includes('VIP');
             
             acts.push({
                id: tx.id,
                memberId: relatedMember ? relatedMember.id : 'unknown', 
                memberPhone: tx.senderNumber || 'Team Member',
                memberLevel: relatedMember ? relatedMember.level : 1, 
                type: isVipBonus ? 'VIP_UPGRADE' : 'TASK_COMMISSION',
                amount: 0,
                commission: tx.amount,
                date: tx.date
            });
        });
    }

    return acts;
  }, [teamMembers, user.earningHistory]);


  useEffect(() => {
    const totalDeposit = teamMembers.reduce((sum, m) => sum + (m.totalDeposited || 0), 0);
    const totalWithdraw = teamMembers.reduce((sum, m) => sum + (m.totalWithdrawn || 0), 0);
    const todayEarn = teamMembers.reduce((sum, m) => sum + (m.memberTodayEarnings || 0), 0);
    
    const vips = teamMembers.filter(m => (m.vipLevel || 0) > 0).length;
    const nonVips = teamMembers.length - vips;

    const myIncome = derivedActivities
        .filter(a => a.type === 'TASK_COMMISSION' || a.type === 'VIP_UPGRADE')
        .reduce((sum, act) => sum + act.commission, 0);

    setTeamStats({
        totalTeamDeposit: totalDeposit,
        todayTeamEarn: todayEarn,
        totalMembers: teamMembers.length,
        vipMembers: vips,
        nonVipMembers: nonVips,
        totalTeamWithdraw: totalWithdraw,
        myTotalIncome: myIncome
    });

    let filtered = derivedActivities.filter(act => {
        const actDate = new Date(act.date).setHours(0,0,0,0);
        const start = dateFrom ? new Date(dateFrom).setHours(0,0,0,0) : 0;
        const end = dateTo ? new Date(dateTo).setHours(23,59,59,999) : Infinity;
        
        return act.memberLevel === activeLevel && actDate >= start && actDate <= end;
    });

    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setActivities(filtered);
    setVisibleActivitiesCount(10);

  }, [activeLevel, derivedActivities, teamMembers, dateFrom, dateTo]);

  const displayedActivities = activities.slice(0, visibleActivitiesCount);
  const currentLevelMembers = teamMembers.filter(m => m.level === activeLevel);

  const inviteLink = `${window.location.origin}?ref=${user.referralCode}`;

  const getCommissionFromMember = (memberPhone: string) => {
      return (user.earningHistory || [])
        .filter(tx => tx.type === 'BONUS' && tx.senderNumber === memberPhone)
        .reduce((sum, tx) => sum + tx.amount, 0);
  };

  const getActionIcon = (type: TeamActivity['type']) => {
    switch (type) {
        case 'JOIN': return <UserPlus size={16} className="text-blue-500" />;
        case 'VIP_UPGRADE': return <Crown size={16} className="text-yellow-500" />;
        case 'TASK_COMMISSION': return <Wallet size={16} className="text-purple-500" />;
        case 'WORK_COMPLETE': return <CheckCircle size={16} className="text-green-500" />;
        default: return <ListIcon size={16} className="text-gray-500" />;
    }
  };

  const copyLink = () => {
      navigator.clipboard.writeText(inviteLink);
      showToast("Invite Link Copied!", 'success');
  };

  const activeTiers = settings.vipTiers && settings.vipTiers.length > 0 ? settings.vipTiers : VIP_TIERS;
  const taskRatePercent = settings.commissions.task[activeLevel - 1] || 0;
  const vipRatePercent = settings.commissions.vip[activeLevel - 1] || 0;

  const refreshData = async () => {
      setIsLoadingTeam(true);
      try {
          const members = await api.getTeam(user.id);
          setTeamMembers(members);
          showToast("Team data refreshed", 'success');
      } catch(e) {
          showToast("Failed to refresh", 'error');
      } finally {
          setIsLoadingTeam(false);
      }
  };

  return (
    <div className="pb-24 pt-4 px-4 bg-slate-950 min-h-screen text-slate-100 relative">
      {isLoadingTeam && <PageLoadingOverlay />}
      
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold flex items-center">
              <Users className="mr-2 text-blue-500" size={20}/> My Team
          </h2>
          <button onClick={refreshData} className="p-2 rounded-full bg-slate-800 border border-slate-700 hover:bg-slate-700"><RefreshCcw size={16} className={isLoadingTeam ? 'animate-spin' : ''} /></button>
      </div>

      {/* REFERRAL CODE CARD (TOP) */}
      <div className="bg-gradient-to-r from-indigo-900 to-purple-900 p-4 rounded-2xl mb-6 shadow-xl border border-indigo-500/30 relative overflow-hidden">
          <div className="absolute right-0 top-0 opacity-10 p-2"><Share2 size={60} /></div>
          <div className="relative z-10 flex justify-between items-center">
              <div>
                  <p className="text-xs text-indigo-300 font-bold uppercase mb-1">My Referral Code</p>
                  <p className="text-2xl font-mono font-bold text-white tracking-widest">{user.referralCode}</p>
              </div>
              <div className="flex space-x-2">
                  <button onClick={() => {navigator.clipboard.writeText(user.referralCode); showToast("Code Copied", "success")}} className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white backdrop-blur-sm">
                      <Copy size={20} />
                  </button>
                  <button onClick={() => setShowQr(true)} className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white backdrop-blur-sm">
                      <QrCode size={20} />
                  </button>
              </div>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex justify-between items-center">
              <p className="text-xs text-indigo-200">Share your link to earn commission</p>
              <button onClick={copyLink} className="text-xs font-bold bg-white text-indigo-900 px-3 py-1 rounded-full shadow-sm active:scale-95">Copy Link</button>
          </div>
      </div>

      {/* DASHBOARD STATISTICS GRID */}
      <div className="space-y-3 mb-6">
          <div className="grid grid-cols-2 gap-3">
              <div className="bg-gradient-to-br from-green-900/40 to-slate-900 border border-green-500/20 p-4 rounded-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-2 opacity-10"><Wallet size={40}/></div>
                  <p className="text-[10px] text-green-400 font-bold uppercase tracking-wide mb-1">Total Team Deposit</p>
                  <h3 className="text-xl font-bold text-white">৳{teamStats.totalTeamDeposit.toLocaleString()}</h3>
              </div>
              <div className="bg-gradient-to-br from-blue-900/40 to-slate-900 border border-blue-500/20 p-4 rounded-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-2 opacity-10"><TrendingUp size={40}/></div>
                  <p className="text-[10px] text-blue-400 font-bold uppercase tracking-wide mb-1">Today Team Earn</p>
                  <h3 className="text-xl font-bold text-white">৳{teamStats.todayTeamEarn.toFixed(2)}</h3>
              </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
              <div className="bg-slate-800 p-3 rounded-xl border border-slate-700 text-center">
                  <p className="text-[9px] text-slate-400 uppercase font-bold mb-1">Total Member</p>
                  <p className="text-lg font-bold text-white">{teamStats.totalMembers}</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-xl border border-yellow-500/20 text-center relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-8 h-8 bg-yellow-500/10 rounded-bl-xl"></div>
                  <p className="text-[9px] text-yellow-500 uppercase font-bold mb-1">VIP Member</p>
                  <p className="text-lg font-bold text-white">{teamStats.vipMembers}</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-xl border border-slate-700 text-center">
                  <p className="text-[9px] text-slate-400 uppercase font-bold mb-1">Non VIP</p>
                  <p className="text-lg font-bold text-slate-300">{teamStats.nonVipMembers}</p>
              </div>
          </div>

          <div className="bg-slate-800 p-4 rounded-2xl border border-red-500/20 flex justify-between items-center">
              <div className="flex items-center space-x-3">
                  <div className="p-2 bg-red-900/20 rounded-lg text-red-500"><ArrowUpCircle size={20}/></div>
                  <div>
                      <p className="text-xs text-slate-400 font-bold uppercase">Total Team Withdraw</p>
                      <p className="text-[10px] text-slate-500">Successful cashouts</p>
                  </div>
              </div>
              <h3 className="text-xl font-bold text-red-400">৳{teamStats.totalTeamWithdraw.toLocaleString()}</h3>
          </div>
      </div>

      {/* Level Tabs */}
      <div className="bg-slate-900 p-1 rounded-xl mb-4 border border-slate-800">
        <div className="flex">
            {[1, 2, 3].map((lvl) => {
                const count = teamMembers.filter(m => m.level === lvl).length;
                return (
                    <button 
                        key={lvl}
                        onClick={() => setActiveLevel(lvl as 1|2|3)}
                        className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all flex justify-center items-center ${
                            activeLevel === lvl ? 'bg-slate-800 text-white shadow-md border border-slate-700' : 'text-slate-500 hover:text-slate-300'
                        }`}
                    >
                        Level {lvl} <span className="ml-1 text-[10px] opacity-60 bg-slate-950 px-1.5 py-0.5 rounded-full">{count}</span>
                    </button>
                );
            })}
        </div>
        <div className="mt-1 px-2 py-1.5 flex justify-center items-center text-[10px] text-slate-400 bg-slate-950/50 rounded-lg border border-slate-800/50">
            <span className="flex items-center mr-3"><Crown size={10} className="mr-1 text-yellow-500"/> Refer Comm: <span className="text-white ml-1 font-bold">{vipRatePercent}%</span></span>
            <span className="w-[1px] h-3 bg-slate-700 mr-3"></span>
            <span className="flex items-center"><Zap size={10} className="mr-1 text-blue-500"/> Task Comm: <span className="text-white ml-1 font-bold">{taskRatePercent}%</span></span>
        </div>
      </div>

      <div className="bg-slate-900 rounded-t-2xl border-t border-x border-slate-800 min-h-[400px]">
        <div className="sticky top-0 bg-slate-900 z-20 rounded-t-2xl shadow-sm border-b border-slate-800">
            <div className="flex border-b border-slate-800">
                 <button onClick={() => setViewMode('MEMBERS')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center space-x-2 ${viewMode === 'MEMBERS' ? 'text-indigo-400 border-b-2 border-indigo-400 bg-slate-800/50' : 'text-slate-500'}`}>
                    <ListIcon size={16} /> <span>Members List</span>
                 </button>
                 <button onClick={() => setViewMode('ACTIVITY')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center space-x-2 ${viewMode === 'ACTIVITY' ? 'text-indigo-400 border-b-2 border-indigo-400 bg-slate-800/50' : 'text-slate-500'}`}>
                    <ActivityIcon size={16} /> <span>Activity Log</span>
                 </button>
            </div>
            
            <div className="p-3 flex items-center space-x-2 bg-slate-950/30">
                <div className="flex items-center flex-1 bg-slate-800 rounded-lg px-2 border border-slate-700">
                    <Calendar size={14} className="text-slate-400 mr-2"/>
                    <input 
                        type="date" 
                        className="bg-transparent text-xs text-white py-2 w-full outline-none"
                        value={dateFrom}
                        onChange={(e) => setDateFrom(e.target.value)}
                    />
                </div>
                <span className="text-slate-500">-</span>
                <div className="flex items-center flex-1 bg-slate-800 rounded-lg px-2 border border-slate-700">
                    <Calendar size={14} className="text-slate-400 mr-2"/>
                    <input 
                        type="date" 
                        className="bg-transparent text-xs text-white py-2 w-full outline-none"
                        value={dateTo}
                        onChange={(e) => setDateTo(e.target.value)}
                    />
                </div>
            </div>
        </div>

        <div className="p-3">
            {isLoadingTeam && teamMembers.length === 0 ? (
                <div className="text-center py-10 text-slate-500">
                    {/* Skeleton or Empty space, loader is handled by Overlay */}
                    <div className="animate-pulse space-y-3">
                        <div className="h-16 bg-slate-800 rounded-xl"></div>
                        <div className="h-16 bg-slate-800 rounded-xl"></div>
                    </div>
                </div>
            ) : viewMode === 'MEMBERS' ? (
                currentLevelMembers.length === 0 ? (
                    <div className="text-center text-slate-500 py-10 flex flex-col items-center">
                        <Users size={32} className="mb-2 opacity-20"/>
                        <p>No members in Level {activeLevel}</p>
                    </div>
                ) : (
                    currentLevelMembers.map((member) => {
                        const vipTier = activeTiers.find(t => t.level === member.vipLevel) || activeTiers[0];
                        const vipName = vipTier?.name || 'Intern';
                        const dailyLimit = vipTier?.dailyTasks || 0;
                        const isToday = new Date(member.lastActiveDate || 0).toDateString() === new Date().toDateString();
                        const displayTasks = isToday ? member.tasksCompletedToday : 0;
                        const commFromMember = getCommissionFromMember(member.phoneNumber);

                        return (
                            <div key={member.id} className="bg-slate-800 rounded-xl p-3 mb-2 border border-slate-700 shadow-sm relative overflow-hidden">
                                <div className="flex justify-between items-center mb-2 relative z-10">
                                    <div className="flex items-center space-x-3">
                                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center font-bold text-white border border-slate-500 shadow-inner text-xs">
                                            {member.username.charAt(0).toUpperCase()}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-white text-xs">{member.username}</h4>
                                            <p className="text-[10px] text-slate-400 font-mono">{member.phoneNumber}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                         <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${member.vipLevel > 0 ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/30' : 'bg-slate-700 text-slate-400 border border-slate-600'}`}>
                                            {vipName}
                                         </span>
                                         <p className="text-[9px] text-slate-500 mt-0.5 flex items-center justify-end">
                                            <Clock size={8} className="mr-1" /> {new Date(member.joinDate).toLocaleDateString()}
                                         </p>
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-1 bg-slate-900/50 p-1.5 rounded-lg border border-slate-700/50 relative z-10">
                                    <div className="text-center p-0.5">
                                        <p className="text-[8px] text-slate-500 mb-0.5 uppercase font-bold">Today Task</p>
                                        <p className={`font-bold text-xs ${displayTasks > 0 ? 'text-white' : 'text-slate-600'}`}>
                                            {displayTasks}/{dailyLimit}
                                        </p>
                                    </div>
                                    <div className="text-center p-0.5 border-l border-slate-800">
                                        <p className="text-[8px] text-slate-500 mb-0.5 uppercase font-bold">Earn</p>
                                        <p className="font-bold text-xs text-green-400">৳{member.memberTodayEarnings}</p>
                                    </div>
                                    <div className="col-span-2 h-[1px] bg-slate-800 my-0.5"></div>
                                    <div className="text-center p-0.5">
                                        <p className="text-[8px] text-slate-500 mb-0.5 uppercase font-bold">My Income</p>
                                        <p className="font-bold text-xs text-purple-400">৳{commFromMember.toFixed(2)}</p>
                                    </div>
                                    <div className="text-center p-0.5 border-l border-slate-800">
                                        <p className="text-[8px] text-slate-500 mb-0.5 uppercase font-bold">Comm. %</p>
                                        <span className="text-[9px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded font-bold">
                                            {taskRatePercent}%
                                        </span>
                                    </div>
                                </div>
                            </div>
                        );
                    })
                )
            ) : (
                <div className="space-y-3">
                    {displayedActivities.length === 0 ? (
                        <div className="text-center text-slate-500 py-10 flex flex-col items-center">
                            <Filter size={24} className="mb-2 opacity-50"/>
                            <p>No activity found for selected date.</p>
                        </div>
                    ) : (
                        displayedActivities.map((act) => (
                            <div key={act.id} className="flex justify-between items-center p-3 bg-slate-800 rounded-xl border border-slate-700 hover:border-slate-600 transition-colors">
                                <div className="flex items-center space-x-3">
                                    <div className="p-2 bg-slate-900 rounded-lg border border-slate-700">
                                        {getActionIcon(act.type)}
                                    </div>
                                    <div>
                                        <p className="text-xs text-white font-bold capitalize">{act.type.replace('_', ' ').toLowerCase()}</p>
                                        <p className="text-[10px] text-slate-500 font-mono">{act.memberPhone}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    {act.commission > 0 ? (
                                        <p className="text-xs font-bold text-green-400">+৳{act.commission.toFixed(2)}</p>
                                    ) : (
                                        <span className="text-[10px] text-slate-600">No Comm.</span>
                                    )}
                                    <p className="text-[10px] text-slate-500 mt-0.5">{new Date(act.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} • {new Date(act.date).toLocaleDateString()}</p>
                                </div>
                            </div>
                        ))
                    )}
                    
                    {visibleActivitiesCount < activities.length && (
                        <div className="pt-2 pb-4">
                            <button 
                                onClick={() => setVisibleActivitiesCount(prev => prev + 10)}
                                className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl border border-slate-700 transition-colors flex justify-center items-center text-xs uppercase tracking-wide"
                            >
                                <ChevronDown size={14} className="mr-1" /> Load More (10)
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
      </div>

      {showQr && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
             <div className="bg-slate-900 border border-indigo-500/30 p-6 rounded-2xl w-full max-w-xs text-center relative shadow-2xl">
                <button onClick={() => setShowQr(false)} className="absolute top-3 right-3 text-slate-400 hover:text-white bg-slate-800 rounded-full p-1"><X size={20}/></button>
                <h3 className="text-white font-bold text-lg mb-1 flex items-center justify-center">
                    <UserPlus size={20} className="mr-2 text-indigo-500"/> Invite Friends
                </h3>
                <p className="text-xs text-slate-400 mb-4">Share your QR or Link to earn commission</p>
                <div className="bg-white p-3 rounded-xl inline-block mb-4 shadow-inner">
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(inviteLink)}`} alt="QR Code" className="w-40 h-40" />
                </div>
                <button onClick={copyLink} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl flex items-center justify-center transition-colors shadow-lg shadow-indigo-900/40">
                    <Share2 size={18} className="mr-2" /> Copy Invite Link
                </button>
             </div>
          </div>
      )}
    </div>
  );
};

export default Team;
