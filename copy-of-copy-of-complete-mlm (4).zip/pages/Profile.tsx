
import React, { useState, useEffect } from 'react';
import { User, SystemSettings, DEFAULT_SETTINGS } from '../types';
import { VIP_TIERS, AVATAR_LIST } from '../constants';
import { UserCircle, Wallet as WalletIcon, ArrowDownCircle, ArrowUpCircle, Settings as SettingsIcon, LogOut, HelpCircle, ChevronRight, X, Edit2, Pencil, Download, MessageCircle, Clock, AlertTriangle, Crown as CrownIcon, Send, Phone as PhoneIcon, CheckCircle2, XCircle, History as HistoryIcon, Hash, ShieldCheck, AlertOctagon, Users, Ticket, ArrowLeft, Gem, Lock, FileText, KeyRound, Repeat } from 'lucide-react';
import DepositModal from '../components/DepositModal';
import CommissionInfoModal from '../components/CommissionInfoModal';
import { useToast } from '../components/ToastContext';
import { api } from '../services/api';
import { useNavigate } from 'react-router-dom';

interface ProfileProps {
  user: User;
  onLogout: () => void;
  onDeposit: (amount: number, method: string, trxId: string, sender: string) => void;
  onWithdraw: (amount: number, method: string, number: string, pin: string) => void;
  onUpdateUser: (user: User) => void;
}

// --- HELPER COMPONENTS ---

const MenuItem = ({ icon: Icon, label, onClick, color, isLast }: any) => (
  <button 
    onClick={onClick}
    className={`w-full p-4 flex items-center justify-between hover:bg-slate-800/50 transition-colors ${!isLast ? 'border-b border-slate-800' : ''}`}
  >
    <div className="flex items-center space-x-4">
      <div className={`p-2.5 rounded-xl bg-slate-950/50 ${color}`}>
        <Icon size={22} />
      </div>
      <span className="font-bold text-base text-slate-200">{label}</span>
    </div>
    <ChevronRight size={18} className="text-slate-600" />
  </button>
);

const StatusBadgeWithCountdown = ({ date, status }: { date: string, status: string }) => {
    const [timeLeft, setTimeLeft] = useState<string | null>(null);

    useEffect(() => {
        if (status !== 'PENDING') {
            setTimeLeft(null);
            return;
        }

        const calculateTime = () => {
            const startTime = new Date(date).getTime();
            const waitTime = 30 * 60 * 1000; // 30 Minutes
            const targetTime = startTime + waitTime;
            const now = Date.now();
            const diff = targetTime - now;

            if (diff > 0) {
                const m = Math.floor(diff / 60000);
                const s = Math.floor((diff % 60000) / 1000);
                return `${m}m ${s}s`;
            }
            return null;
        };

        // Initial check
        setTimeLeft(calculateTime());

        const timer = setInterval(() => {
            const remaining = calculateTime();
            setTimeLeft(remaining);
            if (!remaining) clearInterval(timer);
        }, 1000);

        return () => clearInterval(timer);
    }, [date, status]);

    if (status === 'PENDING' && timeLeft) {
        return (
            <span className="text-[10px] font-bold px-2 py-1 rounded uppercase flex items-center bg-orange-500/10 text-orange-400 border border-orange-500/20 animate-pulse">
                <Clock size={12} className="mr-1.5"/> Wait: {timeLeft}
            </span>
        );
    }

    const isPending = status === 'PENDING';
    const isFailed = status === 'FAILED';

    return (
        <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase flex items-center ${
            isPending ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20' : 
            isFailed ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 
            'bg-green-500/10 text-green-500 border border-green-500/20'
        }`}>
            {isPending && <Clock size={12} className="mr-1.5"/>}
            {isFailed && <XCircle size={12} className="mr-1.5"/>}
            {!isPending && !isFailed && <CheckCircle2 size={12} className="mr-1.5"/>}
            {status}
        </span>
    );
};

// --- MAIN PROFILE COMPONENT ---

const Profile: React.FC<ProfileProps> = ({ user, onLogout, onDeposit, onWithdraw, onUpdateUser }) => {
  const { showToast } = useToast();
  const navigate = useNavigate();
  const userAvatar = AVATAR_LIST[user.avatarId || 0];
  
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  
  // Dynamic VIP Tier Calculation
  const activeTiers = settings.vipTiers && settings.vipTiers.length > 0 ? settings.vipTiers : VIP_TIERS;
  const currentVip = activeTiers.find(t => t.level === user.vipLevel) || activeTiers[0] || VIP_TIERS[0];

  const minWithdrawLimit = settings.withdrawLimits[user.vipLevel] || 1000;

  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showCommissionModal, setShowCommissionModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [historyTypeGroup, setHistoryTypeGroup] = useState<'EARNING' | 'PAYMENT'>('EARNING');
  const [visibleHistoryCount, setVisibleHistoryCount] = useState(20);
  
  const [showAccountManager, setShowAccountManager] = useState(false);
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  const [withdrawMethod, setWithdrawMethod] = useState<'bKash' | 'Nagad' | null>(null);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawPin, setWithdrawPin] = useState('');

  const [editSection, setEditSection] = useState<'NONE' | 'NAME' | 'PASS' | 'PIN' | 'WALLET' | 'AVATAR'>('NONE');
  const [tempValue, setTempValue] = useState('');
  const [oldValue, setOldValue] = useState(''); 
  const [confirmValue, setConfirmValue] = useState('');
  const [tempWalletType, setTempWalletType] = useState<'bKash' | 'Nagad'>('bKash');
  
  const savedMethods = user.savedPaymentMethods || [];
  const activeWallet = savedMethods.length > 0 ? savedMethods[0] : null;

  useEffect(() => {
    const loadSettings = async () => {
        try {
            const s = await api.getSettings();
            setSettings(s);
        } catch(e) { console.error(e) }
    };
    loadSettings();
  }, []);

  const formatTime = (hour: number) => {
      const h = hour % 12 || 12;
      const ampm = hour < 12 && hour !== 24 ? 'AM' : 'PM';
      return `${h}:00 ${ampm}`;
  };

  const getOffDaysString = (offDays: number[]) => {
      if (!offDays || offDays.length === 0) return 'None';
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      return offDays.map(d => dayNames[d]).join(' & ');
  };

  const handleAction = (action: string) => {
    switch (action) {
        case 'Deposit': setShowDepositModal(true); break;
        case 'Withdraw': setShowWithdrawModal(true); break;
        case 'History': 
            setHistoryTypeGroup('EARNING');
            setVisibleHistoryCount(20); 
            setShowHistoryModal(true); 
            break;
        case 'Account': 
            setEditSection('NONE');
            setOldValue('');
            setTempValue('');
            setConfirmValue('');
            setShowAccountManager(true); 
            break;
        case 'Contract': 
            navigate('/vip', { state: { openCertificate: true } }); 
            break;
        case 'Telegram': 
            if (settings.externalLinks?.telegram) window.open(settings.externalLinks.telegram, "_blank"); 
            else showToast("Link not configured", 'error');
            break;
        case 'WhatsApp': 
            if (settings.externalLinks?.whatsapp) window.open(settings.externalLinks.whatsapp, "_blank");
            else showToast("Link not configured", 'error'); 
            break;
        case 'Commission': setShowCommissionModal(true); break;
        case 'App': 
            if (settings.externalLinks?.appDownload && settings.externalLinks.appDownload !== '#') window.open(settings.externalLinks.appDownload, "_blank");
            else showToast('Download link coming soon!', 'info'); 
            break;
        case 'Logout': onLogout(); break;
        default: break;
    }
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    
    if (isNaN(amount) || amount < minWithdrawLimit) return showToast(`Minimum withdrawal is ৳${minWithdrawLimit}`, 'error');
    if (amount > user.balance) return showToast('Insufficient balance', 'error');
    if (!withdrawMethod) return showToast('Select a method', 'error');
    
    // Strict Linked Wallet Check
    if (!activeWallet || activeWallet.method !== withdrawMethod) {
        return showToast(`Please link your ${withdrawMethod} number first in Account Manager.`, 'error');
    }
    
    const finalNumber = activeWallet.number;

    if (withdrawPin !== user.withdrawalPin) return showToast('Incorrect PIN', 'error');

    const now = new Date();
    const currentHour = now.getHours();
    const currentDay = now.getDay(); 

    if (settings.schedule.offDays.includes(currentDay)) {
        return showToast("Withdrawals are closed today (Weekend/Off-day).", 'error');
    }
    
    if (currentHour < settings.schedule.startHour || currentHour >= settings.schedule.endHour) {
        return showToast(`Withdrawals only available between ${formatTime(settings.schedule.startHour)} and ${formatTime(settings.schedule.endHour)}`, 'error');
    }

    onWithdraw(amount, withdrawMethod, finalNumber, withdrawPin);
    setShowWithdrawModal(false);
    showToast('Withdrawal request submitted', 'success');
  };

  const getFilteredHistory = () => {
      const list = historyTypeGroup === 'EARNING' 
        ? (user.earningHistory || []) 
        : [...(user.depositHistory || []), ...(user.withdrawHistory || [])];
      
      return list.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const fullHistoryList = getFilteredHistory();
  const displayedHistory = fullHistoryList.slice(0, visibleHistoryCount);

  // --- Account Manager Logic ---

  const saveProfileUpdate = () => {
    let updates: Partial<User> = {};
    const now = new Date().toISOString();

    // Verification for PASS and PIN re-entry
    if (editSection === 'PASS' || editSection === 'PIN') {
        if (tempValue !== confirmValue) {
            return showToast("New values do not match!", 'error');
        }
    }

    if (editSection === 'NAME') {
        // Name Limit: 1 Time
        if (user.nameChangeCount >= 1) return showToast("Limit reached: Name change allowed only 1 time.", 'error');
        if (tempValue.length < 3) return showToast("Name too short", 'error');
        updates = { name: tempValue, nameChangeCount: (user.nameChangeCount || 0) + 1 };
    }
    else if (editSection === 'PASS') {
        // Password Limit: 3 Times
        if ((user.passwordChangeCount || 0) >= 3) return showToast("Limit reached: Max 3 password changes allowed.", 'error');
        if (oldValue !== user.password) return showToast("Incorrect Old Password!", 'error');
        if (tempValue.length < 6) return showToast("New Password must be 6+ chars", 'error');
        updates = { password: tempValue, passwordChangeCount: (user.passwordChangeCount || 0) + 1, lastPasswordChangeDate: now };
    }
    else if (editSection === 'PIN') {
        // PIN Limit: 2 Times
        if ((user.pinChangeCount || 0) >= 2) return showToast("Limit reached: Max 2 PIN changes allowed.", 'error');
        if (oldValue !== user.withdrawalPin) return showToast("Incorrect Old PIN!", 'error');
        if (tempValue.length !== 4 || isNaN(Number(tempValue))) return showToast("New PIN must be 4 digits", 'error');
        updates = { withdrawalPin: tempValue, pinChangeCount: (user.pinChangeCount || 0) + 1, lastPinChangeDate: now };
    }
    else if (editSection === 'WALLET') {
        const totalChanges = (user.bKashChangeCount || 0) + (user.nagadChangeCount || 0);
        // STRICT LIMIT: 1 TIME ONLY
        if (totalChanges >= 1) return showToast("Limit reached: Wallet number can be set/changed only once.", 'error');
        
        if (tempValue.length < 11) return showToast("Invalid Number", 'error');

        const newMethods = [{ method: tempWalletType, number: tempValue }];
        
        updates = { 
            savedPaymentMethods: newMethods as any, 
            bKashChangeCount: tempWalletType === 'bKash' ? (user.bKashChangeCount || 0) + 1 : user.bKashChangeCount,
            nagadChangeCount: tempWalletType === 'Nagad' ? (user.nagadChangeCount || 0) + 1 : user.nagadChangeCount,
        };
    }
    else if (editSection === 'AVATAR') {
        const avatarIdx = parseInt(tempValue);
        updates = { avatarId: avatarIdx };
    }

    onUpdateUser({ ...user, ...updates });
    showToast("Updated Successfully", 'success');
    setEditSection('NONE');
    setTempValue('');
    setOldValue('');
    setConfirmValue('');
  };

  const openAvatarSelector = () => {
      setEditSection('AVATAR');
      setShowAvatarModal(true);
      setShowAccountManager(true);
  };

  const getWalletLogo = (method: 'bKash' | 'Nagad') => {
      const key = method === 'bKash' ? 'bKash' : 'nagad';
      return settings.paymentLogos ? settings.paymentLogos[key] : null;
  };

  return (
    <div className="pb-24 pt-6 px-5 bg-slate-950 min-h-screen text-slate-100">
      
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-6 flex items-center shadow-xl border border-slate-700 relative overflow-hidden mb-6">
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <UserCircle size={110} />
        </div>
        
        <div className="relative z-10 mr-5">
            <div className="w-20 h-20 rounded-full bg-slate-700 border-4 border-slate-500 overflow-hidden shadow-lg relative group">
                <img src={userAvatar} alt="Avatar" className="w-full h-full object-cover" />
                <button onClick={openAvatarSelector} className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><Edit2 size={24} className="text-white" /></button>
            </div>
            {user.isAdmin && <span className="absolute -bottom-2 -right-2 bg-blue-600 text-[10px] px-2 py-0.5 rounded-full border border-slate-900 font-bold">ADMIN</span>}
        </div>
        
        <div className="relative z-10 flex-1">
          <div className="flex items-center space-x-2">
            <h2 className="text-xl font-bold text-white">{user.name || 'User'}</h2>
            <div className={`text-[10px] px-2 py-0.5 rounded-full border font-bold flex items-center ${currentVip.level > 0 ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' : 'bg-slate-700/50 text-slate-400 border-slate-600'}`}>
                {currentVip.level > 0 && <CrownIcon size={12} className="mr-1" />}
                {currentVip.name}
            </div>
          </div>
          <p className="text-slate-400 text-sm font-mono mt-1">{user.phoneNumber}</p>
          <div className="mt-2 text-xs text-slate-500 flex items-center">
             <span className="px-2 py-1 bg-slate-800 rounded text-slate-300 font-mono tracking-wide border border-slate-700">Ref: {user.referralCode}</span>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 gap-4 mb-6">
         <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col items-center justify-center shadow-md">
             <span className="text-xs text-slate-400 mb-1 uppercase tracking-wider font-bold">Available Balance</span>
             <span className="text-3xl font-extrabold text-white tracking-tight">৳{(user.balance || 0).toFixed(2)}</span>
         </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4 mb-6">
        <button onClick={() => handleAction('Deposit')} className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 py-4 rounded-2xl font-bold text-base text-white shadow-lg shadow-blue-900/30 active:scale-95 transition-transform flex items-center justify-center space-x-2">
            <ArrowDownCircle size={22} /> <span>Deposit</span>
        </button>
        <button onClick={() => handleAction('Withdraw')} className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 py-4 rounded-2xl font-bold text-base text-white shadow-lg shadow-orange-900/30 active:scale-95 transition-transform flex items-center justify-center space-x-2">
            <ArrowUpCircle size={22} /> <span>Withdraw</span>
        </button>
      </div>

      {/* Menu List */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 shadow-xl overflow-hidden">
        <MenuItem icon={HistoryIcon} label="Transactions History" onClick={() => handleAction('History')} color="text-cyan-400" />
        <div className="h-[1px] bg-slate-800 mx-4"></div>
        {user.vipLevel > 0 && (
            <>
                <MenuItem icon={FileText} label="Membership Contract" onClick={() => handleAction('Contract')} color="text-yellow-400" />
                <div className="h-[1px] bg-slate-800 mx-4"></div>
            </>
        )}
        <MenuItem icon={Users} label="Commission Info" onClick={() => handleAction('Commission')} color="text-purple-400" />
        <MenuItem icon={SettingsIcon} label="Account Manager" onClick={() => handleAction('Account')} color="text-slate-400" />
        <MenuItem icon={MessageCircle} label="Customer Care" onClick={() => handleAction('WhatsApp')} color="text-green-400" />
        <MenuItem icon={Download} label="Download App" onClick={() => handleAction('App')} color="text-orange-400" />
        <div className="h-[1px] bg-slate-800 mx-4"></div>
        <MenuItem icon={LogOut} label="Logout" onClick={() => handleAction('Logout')} color="text-red-400" isLast />
      </div>

      {/* MODALS */}
      <DepositModal isOpen={showDepositModal} onClose={() => setShowDepositModal(false)} onDeposit={onDeposit} />
      <CommissionInfoModal isOpen={showCommissionModal} onClose={() => setShowCommissionModal(false)} />

      {/* WITHDRAW MODAL - STRICT LINKED WALLET */}
      {showWithdrawModal && (
          <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/90 backdrop-blur-md animate-fade-in p-0 sm:p-4">
             <div className="bg-gradient-to-b from-slate-900 to-slate-950 w-full max-w-sm sm:max-w-md rounded-t-3xl sm:rounded-3xl border-t sm:border border-slate-700/50 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-slide-up">
                
                <div className="px-6 pt-6 pb-2 flex justify-between items-center bg-transparent">
                    <div>
                        <h3 className="text-xl font-bold text-white tracking-tight">Withdraw</h3>
                        <p className="text-xs text-slate-400">Transfer to Mobile Wallet</p>
                    </div>
                    <button onClick={() => setShowWithdrawModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors backdrop-blur-sm bg-slate-800/50 border border-slate-700">
                        <X size={20} className="text-slate-300" />
                    </button>
                </div>
                
                <div className="flex-1 overflow-y-auto px-6 pb-6 space-y-6">
                    <div className="bg-gradient-to-r from-blue-900/40 to-purple-900/40 p-[1px] rounded-2xl">
                        <div className="bg-slate-900/90 backdrop-blur-sm p-5 rounded-2xl flex justify-between items-center relative overflow-hidden">
                            <div className="absolute -right-4 -top-4 bg-blue-500/10 w-24 h-24 rounded-full blur-xl"></div>
                            <div className="relative z-10">
                                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Available Balance</p>
                                <p className="text-3xl font-bold text-white tracking-tight">৳{(user.balance || 0).toFixed(2)}</p>
                            </div>
                            <div className="text-right relative z-10">
                                <p className="text-[10px] text-slate-400 mb-1">Min Withdraw</p>
                                <span className="bg-slate-800 border border-slate-700 text-yellow-400 text-xs font-bold px-3 py-1 rounded-lg">
                                    ৳{minWithdrawLimit}
                                </span>
                            </div>
                        </div>
                    </div>

                    <form onSubmit={handleWithdrawSubmit} className="space-y-6">
                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 mb-3 block">1. Method</label>
                            <div className="grid grid-cols-2 gap-4">
                                {['bKash', 'Nagad'].map((m) => {
                                    const isLinked = activeWallet?.method === m;
                                    const isDisabled = activeWallet && activeWallet.method !== m;
                                    const isSelected = withdrawMethod === m;
                                    const logoUrl = m === 'bKash' ? settings.paymentLogos?.bKash : settings.paymentLogos?.nagad;
                                    
                                    return (
                                        <button
                                            key={m}
                                            type="button"
                                            onClick={() => setWithdrawMethod(m as any)}
                                            className={`relative overflow-hidden p-4 rounded-2xl border-2 transition-all group min-h-[80px] flex flex-col items-center justify-center space-y-2 ${
                                                isDisabled 
                                                    ? 'bg-slate-800/50 border-slate-800 text-slate-600 grayscale opacity-50'
                                                    : isSelected 
                                                        ? (m === 'bKash' ? 'bg-pink-600/10 border-pink-500' : 'bg-orange-600/10 border-orange-500')
                                                        : 'bg-slate-800 border-slate-700 hover:border-slate-500'
                                            }`}
                                        >
                                            {logoUrl ? (
                                                <img src={logoUrl} alt={m} className="h-8 object-contain bg-white rounded p-0.5" />
                                            ) : (
                                                <span className={`font-bold text-lg ${m === 'bKash' ? 'text-pink-500' : 'text-orange-500'}`}>{m}</span>
                                            )}
                                            {isSelected && (
                                                <div className={`absolute top-2 right-2 rounded-full p-0.5 ${m === 'bKash' ? 'bg-pink-500 text-white' : 'bg-orange-500 text-white'}`}>
                                                    <CheckCircle2 size={12} />
                                                </div>
                                            )}
                                            {isLinked && (
                                                <div className="absolute top-2 left-2 bg-green-500/20 text-green-500 text-[9px] px-1.5 rounded font-bold border border-green-500/30">Linked</div>
                                            )}
                                        </button>
                                    );
                                })}
                            </div>
                        </div>

                        <div className={`transition-all duration-500 ${withdrawMethod ? 'opacity-100 translate-y-0' : 'opacity-50 translate-y-4'}`}>
                            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 mb-3 block">2. Amount</label>
                            
                            <div className="bg-slate-800 px-4 py-3 rounded-2xl border border-slate-700 focus-within:border-blue-500 transition-colors">
                                <div className="flex items-center">
                                    <span className="text-xl font-bold text-slate-500 mr-2">৳</span>
                                    <input 
                                        type="number" 
                                        value={withdrawAmount}
                                        onChange={(e) => setWithdrawAmount(e.target.value)}
                                        className="w-full bg-transparent text-white text-3xl font-bold outline-none placeholder-slate-600"
                                        placeholder="0"
                                    />
                                </div>
                            </div>
                            
                            {withdrawAmount && (
                                <div className="mt-3 bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between items-center text-sm animate-fade-in">
                                    <span className="text-slate-400">VAT (15%)</span>
                                    <span className="text-red-400 font-mono">-৳{((parseFloat(withdrawAmount)||0) * 0.15).toFixed(2)}</span>
                                    <div className="h-4 w-[1px] bg-slate-700 mx-2"></div>
                                    <span className="text-slate-400">Receive</span>
                                    <span className="text-green-400 font-bold font-mono">৳{((parseFloat(withdrawAmount)||0) * 0.85).toFixed(2)}</span>
                                </div>
                            )}
                        </div>

                        <div className={`space-y-4 transition-all duration-500 delay-75 ${withdrawMethod ? 'opacity-100 translate-y-0' : 'opacity-50 translate-y-4'}`}>
                            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 block">3. Wallet Details</label>
                            
                            {withdrawMethod && (!activeWallet || activeWallet.method !== withdrawMethod) ? (
                                <div className="bg-red-900/10 border border-red-500/30 p-4 rounded-xl flex flex-col items-center text-center">
                                    <AlertTriangle size={24} className="text-red-500 mb-2" />
                                    <p className="text-sm font-bold text-white">No Wallet Linked</p>
                                    <p className="text-xs text-slate-400 mb-3">Link your {withdrawMethod} number in Account Manager.</p>
                                    <button 
                                        type="button"
                                        onClick={() => {
                                            setShowWithdrawModal(false);
                                            setShowAccountManager(true);
                                            setEditSection('WALLET');
                                            setTempWalletType(withdrawMethod as 'bKash' | 'Nagad');
                                        }}
                                        className="bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-bold shadow-lg active:scale-95 transition-all"
                                    >
                                        Link Now
                                    </button>
                                </div>
                            ) : (
                                <>
                                    <div className="bg-slate-800 px-4 py-3.5 rounded-2xl border border-slate-700 flex items-center space-x-3 transition-colors opacity-80 cursor-not-allowed">
                                        <PhoneIcon size={20} className="text-slate-500" />
                                        <div className="flex-1">
                                            <label className="text-[10px] text-slate-400 block">Wallet Number</label>
                                            <input 
                                                type="tel" 
                                                value={activeWallet?.number || ''}
                                                readOnly
                                                className="w-full bg-transparent text-white font-medium text-base outline-none cursor-not-allowed"
                                            />
                                        </div>
                                        <span className="text-[10px] bg-green-500/20 text-green-500 px-2 py-1 rounded border border-green-500/30 flex items-center">
                                            <ShieldCheck size={12} className="mr-1" /> Linked
                                        </span>
                                    </div>

                                    <div className="bg-slate-800 px-4 py-3.5 rounded-2xl border border-slate-700 flex items-center space-x-3 focus-within:border-blue-500 transition-colors">
                                        <Hash size={20} className="text-slate-500" />
                                        <div className="flex-1">
                                            <label className="text-[10px] text-slate-400 block">Withdrawal PIN</label>
                                            <input 
                                                type="password" 
                                                value={withdrawPin}
                                                onChange={(e) => setWithdrawPin(e.target.value)}
                                                className="w-full bg-transparent text-white font-bold text-lg outline-none placeholder-slate-600 tracking-widest"
                                                placeholder="****"
                                                maxLength={4}
                                            />
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>

                        <div className="pt-2 pb-6">
                            <button 
                                type="submit" 
                                disabled={!withdrawMethod || !activeWallet || activeWallet.method !== withdrawMethod}
                                className={`w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center space-x-2 shadow-lg transition-all active:scale-95 ${
                                    (!withdrawMethod || !activeWallet || activeWallet.method !== withdrawMethod)
                                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/40' 
                                }`}
                            >
                                <ArrowUpCircle size={22} />
                                <span>Confirm Withdrawal</span>
                            </button>
                        </div>

                    </form>
                </div>
             </div>
          </div>
      )}

      {/* HISTORY MODAL */}
      {showHistoryModal && (
          <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in p-0 sm:p-4">
             <div className="bg-slate-900 w-full max-w-sm sm:max-w-md rounded-t-3xl sm:rounded-3xl border-t sm:border border-slate-700 shadow-2xl flex flex-col max-h-[90vh] animate-slide-up">
                <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-800/50 rounded-t-3xl">
                    <h3 className="font-bold text-white">History</h3>
                    <button onClick={() => setShowHistoryModal(false)} className="p-1 text-slate-400 hover:text-white"><X size={20}/></button>
                </div>
                <div className="flex p-2 border-b border-slate-800">
                    <button onClick={() => setHistoryTypeGroup('EARNING')} className={`flex-1 py-2 text-xs font-bold rounded-lg ${historyTypeGroup === 'EARNING' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-800'}`}>Earnings</button>
                    <button onClick={() => setHistoryTypeGroup('PAYMENT')} className={`flex-1 py-2 text-xs font-bold rounded-lg ${historyTypeGroup === 'PAYMENT' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-800'}`}>Deposits & Withdraws</button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {displayedHistory.length === 0 ? <div className="text-center text-slate-500 py-10">No history found.</div> : displayedHistory.map((tx) => (
                        <div key={tx.id} className="bg-slate-800 p-3 rounded-xl border border-slate-700 flex justify-between items-center">
                            <div>
                                <p className="text-xs font-bold text-white uppercase">{tx.type}</p>
                                <p className="text-[10px] text-slate-500">{new Date(tx.date).toLocaleString()}</p>
                                <p className="text-[10px] text-slate-400">{tx.method} {tx.senderNumber ? `(${tx.senderNumber})` : ''}</p>
                            </div>
                            <div className="text-right">
                                <p className={`font-bold ${['DEPOSIT','EARNING','BONUS','LOTTERY'].includes(tx.type) ? 'text-green-400' : 'text-red-400'}`}>
                                    {['DEPOSIT','EARNING','BONUS','LOTTERY'].includes(tx.type) ? '+' : '-'}৳{tx.amount}
                                </p>
                                <StatusBadgeWithCountdown date={tx.date} status={tx.status} />
                            </div>
                        </div>
                    ))}
                    {visibleHistoryCount < fullHistoryList.length && (
                        <button onClick={() => setVisibleHistoryCount(prev => prev + 20)} className="w-full py-2 text-xs text-slate-400 border border-slate-700 rounded-lg">Load More</button>
                    )}
                </div>
             </div>
          </div>
      )}

      {/* ACCOUNT MANAGER MODAL */}
      {showAccountManager && (
          <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in p-0 sm:p-4">
             <div className="bg-gradient-to-b from-slate-900 to-slate-950 w-full max-w-sm sm:max-w-md rounded-t-3xl sm:rounded-3xl border-t sm:border border-slate-700 animate-slide-up max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center p-6 border-b border-slate-800/50">
                    <div><h3 className="text-xl font-bold text-white">Account Manager</h3><p className="text-xs text-slate-400">Update security & profile details</p></div>
                    <button onClick={() => {setShowAccountManager(false); setEditSection('NONE');}} className="p-2 hover:bg-slate-800 rounded-full bg-slate-800/50 text-slate-400"><X size={20} /></button>
                </div>
                <div className="p-6">
                    {editSection === 'NONE' ? (
                        <div className="space-y-6">
                            <div>
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 ml-1 flex items-center"><WalletIcon size={12} className="mr-1"/> Withdrawal Wallet</h4>
                                <div onClick={() => {
                                        const totalChanges = (user.bKashChangeCount || 0) + (user.nagadChangeCount || 0);
                                        // STRICT LIMIT: 1 TIME ONLY
                                        if (totalChanges >= 1) return showToast("Limit reached: Wallet number can be set/changed only once.", 'error');
                                        setEditSection('WALLET'); 
                                        setTempValue(activeWallet?.number || '');
                                        setTempWalletType(activeWallet?.method === 'Nagad' ? 'Nagad' : 'bKash');
                                    }}
                                    className="relative group cursor-pointer"
                                >
                                    <div className={`bg-gradient-to-br border p-4 rounded-2xl relative overflow-hidden transition-all active:scale-95 ${activeWallet ? (activeWallet.method === 'bKash' ? 'from-pink-900/40 to-slate-900 border-pink-500/30' : 'from-orange-900/40 to-slate-900 border-orange-500/30') : 'from-slate-800 to-slate-900 border-slate-700'}`}>
                                        <div className="flex justify-between items-start mb-3 relative z-10">
                                            {activeWallet ? (
                                                getWalletLogo(activeWallet.method === 'bKash' ? 'bKash' : 'Nagad') ? <img src={getWalletLogo(activeWallet.method === 'bKash' ? 'bKash' : 'Nagad')} className="h-6 w-auto bg-white rounded p-0.5 object-contain" /> : <span className="font-bold">{activeWallet.method}</span>
                                            ) : <span className="text-slate-400 text-sm font-bold flex items-center"><WalletIcon size={18} className="mr-2"/> No Wallet Linked</span>}
                                            {activeWallet ? <Edit2 size={16} className="text-slate-500 group-hover:text-white transition-colors" /> : <Edit2 size={16} className="text-slate-500 group-hover:text-white transition-colors" />}
                                        </div>
                                        <div className="relative z-10">
                                            <p className="text-[10px] text-slate-500 font-medium mb-1">{activeWallet ? 'Personal Number' : 'Tap to set number'}</p>
                                            <p className={`text-base font-mono font-bold tracking-wide truncate ${activeWallet ? 'text-white' : 'text-slate-600'}`}>{activeWallet ? activeWallet.number : 'Link Now'}</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-2 ml-1 flex items-center justify-between">
                                    <p className="text-[10px] text-slate-500 flex items-center"><AlertOctagon size={12} className="mr-1" /> Limit: 1 Time Only</p>
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${(user.bKashChangeCount || 0) + (user.nagadChangeCount || 0) >= 1 ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>{(user.bKashChangeCount || 0) + (user.nagadChangeCount || 0)}/1 Used</span>
                                </div>
                            </div>
                            <div className="h-[1px] bg-slate-800"></div>
                            <div className="space-y-3">
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 ml-1 flex items-center"><ShieldCheck size={12} className="mr-1"/> Security & Profile</h4>
                                <div onClick={() => {setEditSection('NAME'); setTempValue(user.name || '');}} className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-2xl cursor-pointer hover:bg-slate-800 transition-colors">
                                    <div className="flex items-center space-x-3"><div className="p-2 bg-slate-800 rounded-lg text-blue-400"><Pencil size={20}/></div><div><span className="text-sm font-bold text-white block">Display Name</span><span className="text-[10px] text-slate-500">Visible to team</span></div></div>
                                    <ChevronRight size={16} className="text-slate-600" />
                                </div>
                                <div onClick={() => {setEditSection('PASS'); setTempValue(''); setOldValue(''); setConfirmValue('');}} className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-2xl cursor-pointer hover:bg-slate-800 transition-colors">
                                    <div className="flex items-center space-x-3"><div className="p-2 bg-slate-800 rounded-lg text-red-400"><Lock size={20}/></div><div><span className="text-sm font-bold text-white block">Login Password</span><span className="text-[10px] text-slate-500">Secure your account</span></div></div>
                                    <ChevronRight size={16} className="text-slate-600" />
                                </div>
                                <div onClick={() => {setEditSection('PIN'); setTempValue(''); setOldValue(''); setConfirmValue('');}} className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-2xl cursor-pointer hover:bg-slate-800 transition-colors">
                                    <div className="flex items-center space-x-3"><div className="p-2 bg-slate-800 rounded-lg text-yellow-400"><Hash size={20}/></div><div><span className="text-sm font-bold text-white block">Withdrawal PIN</span><span className="text-[10px] text-slate-500">Required for cashout</span></div></div>
                                    <ChevronRight size={16} className="text-slate-600" />
                                </div>
                                <div onClick={openAvatarSelector} className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-2xl cursor-pointer hover:bg-slate-800 transition-colors">
                                    <div className="flex items-center space-x-3"><div className="p-2 bg-slate-800 rounded-lg text-purple-400"><UserCircle size={20}/></div><div><span className="text-sm font-bold text-white block">Change Avatar</span><span className="text-[10px] text-slate-500">Unlimited changes</span></div></div>
                                    <ChevronRight size={16} className="text-slate-600" />
                                </div>
                            </div>
                        </div>
                    ) : editSection === 'AVATAR' ? (
                         <div className="grid grid-cols-4 gap-3">
                            {AVATAR_LIST.map((avatar, idx) => (
                                <button key={idx} onClick={() => setTempValue(idx.toString())} className={`aspect-square rounded-full overflow-hidden border-2 transition-all ${tempValue === idx.toString() ? 'border-green-500 scale-110 shadow-lg shadow-green-500/20' : 'border-slate-700 opacity-60 hover:opacity-100 hover:border-slate-500'}`}>
                                    <img src={avatar} alt={`Avatar ${idx}`} className="w-full h-full object-cover" />
                                </button>
                            ))}
                         </div>
                    ) : (
                         <div className="space-y-4">
                             <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-4">
                                 {/* Wallet Selection */}
                                 {editSection === 'WALLET' && (
                                    <div className="mb-4">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Select Wallet Type</label>
                                        <div className="grid grid-cols-2 gap-3">
                                            <button onClick={() => setTempWalletType('bKash')} className={`p-3 rounded-xl border flex items-center justify-center space-x-2 transition-all ${tempWalletType === 'bKash' ? 'bg-pink-500/20 border-pink-500 text-pink-500' : 'bg-slate-950 border-slate-700 text-slate-400'}`}>
                                                <span className="font-bold">bKash</span>
                                            </button>
                                            <button onClick={() => setTempWalletType('Nagad')} className={`p-3 rounded-xl border flex items-center justify-center space-x-2 transition-all ${tempWalletType === 'Nagad' ? 'bg-orange-500/20 border-orange-500 text-orange-500' : 'bg-slate-950 border-slate-700 text-slate-400'}`}>
                                                <span className="font-bold">Nagad</span>
                                            </button>
                                        </div>
                                    </div>
                                 )}

                                 {/* Limit Messages */}
                                 {editSection === 'NAME' && <p className="text-xs text-red-400 font-bold mb-2">Limit: You can change name only 1 time.</p>}
                                 {editSection === 'PIN' && <p className="text-xs text-red-400 font-bold mb-2">Limit: You can change PIN only 2 times lifetime.</p>}
                                 {editSection === 'PASS' && <p className="text-xs text-red-400 font-bold mb-2">Limit: You can change Password only 3 times lifetime.</p>}

                                 {/* Old Value Input */}
                                 {(editSection === 'PASS' || editSection === 'PIN') && (
                                     <div>
                                         <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Current {editSection === 'PASS' ? 'Password' : 'PIN'}</label>
                                         <div className="relative"><KeyRound size={16} className="absolute left-3 top-3.5 text-slate-500" /><input type="password" value={oldValue} onChange={(e) => setOldValue(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-white outline-none focus:border-blue-500 transition-colors" placeholder={editSection === 'PIN' ? 'Default: 1234' : 'Enter current password'} maxLength={editSection === 'PIN' ? 4 : undefined}/></div>
                                     </div>
                                 )}

                                 {/* New Value Input */}
                                 <div>
                                     <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">{editSection === 'WALLET' ? `New ${tempWalletType} Number` : `New ${editSection === 'PASS' ? 'Password' : editSection === 'PIN' ? 'PIN' : 'Name'}`}</label>
                                     <div className="relative">
                                         {editSection === 'PASS' || editSection === 'PIN' ? <Lock size={16} className="absolute left-3 top-3.5 text-slate-500" /> : editSection === 'WALLET' ? <PhoneIcon size={16} className="absolute left-3 top-3.5 text-slate-500" /> : <Pencil size={16} className="absolute left-3 top-3.5 text-slate-500" />}
                                         <input type={editSection === 'PASS' || editSection === 'PIN' ? 'password' : 'text'} value={tempValue} onChange={(e) => setTempValue(e.target.value)} className={`w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-white outline-none focus:border-blue-500 transition-colors ${editSection === 'WALLET' ? 'font-mono' : ''}`} placeholder={editSection === 'WALLET' ? '01XXXXXXXXX' : 'Enter new value...'} maxLength={editSection === 'PIN' ? 4 : undefined} />
                                     </div>
                                 </div>

                                 {/* Confirm Value Input */}
                                 {(editSection === 'PASS' || editSection === 'PIN') && (
                                     <div>
                                         <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Re-enter New {editSection === 'PASS' ? 'Password' : 'PIN'}</label>
                                         <div className="relative"><Repeat size={16} className="absolute left-3 top-3.5 text-slate-500" /><input type="password" value={confirmValue} onChange={(e) => setConfirmValue(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-white outline-none focus:border-blue-500 transition-colors" placeholder="Confirm new value" maxLength={editSection === 'PIN' ? 4 : undefined}/></div>
                                     </div>
                                 )}
                             </div>
                         </div>
                    )}
                    {editSection !== 'NONE' && (
                        <div className="mt-6 flex space-x-3">
                            <button onClick={() => {setEditSection('NONE'); setTempValue(''); setOldValue(''); setConfirmValue('');}} className="flex-1 py-3 rounded-xl bg-slate-800 text-slate-400 font-bold hover:bg-slate-700 transition-colors">Back</button>
                            <button onClick={saveProfileUpdate} className="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-500 transition-colors shadow-lg shadow-blue-900/40">Save Changes</button>
                        </div>
                    )}
                </div>
             </div>
          </div>
      )}

      {/* Separate Avatar Modal (Fallback if accessed outside manager flow) */}
      {showAvatarModal && !showAccountManager && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
               <div className="bg-slate-900 w-full max-w-sm rounded-2xl p-6 border border-slate-700">
                    <h3 className="font-bold text-white mb-4">Choose Avatar</h3>
                    <div className="grid grid-cols-4 gap-3">
                        {AVATAR_LIST.map((avatar, index) => (
                            <button 
                                key={index}
                                onClick={() => {
                                    onUpdateUser({ ...user, avatarId: index });
                                    setShowAvatarModal(false);
                                    showToast("Avatar Updated", 'success');
                                }}
                                className={`rounded-full overflow-hidden border-2 ${user.avatarId === index ? 'border-green-500' : 'border-transparent hover:border-blue-500'}`}
                            >
                                <img src={avatar} alt={`Avatar ${index}`} className="w-full h-full object-cover" />
                            </button>
                        ))}
                    </div>
                    <button onClick={() => setShowAvatarModal(false)} className="mt-4 w-full py-2 bg-slate-800 rounded-lg text-slate-400">Cancel</button>
               </div>
          </div>
      )}

    </div>
  );
};

export default Profile;
