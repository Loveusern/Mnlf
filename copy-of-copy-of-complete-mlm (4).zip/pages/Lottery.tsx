
import React, { useState, useEffect } from 'react';
import { User, LotterySegment, SystemSettings } from '../types';
import { LOTTERY_SEGMENTS } from '../constants';
import { ChevronLeft, Gift, AlertCircle, Sparkles, History as HistoryIcon, Ticket, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { useToast } from '../components/ToastContext';
import PageLoadingOverlay from '../components/PageLoadingOverlay';

interface LotteryProps {
  user: User;
  onSpinEnd: (amount: number) => void;
}

const Lottery: React.FC<LotteryProps> = ({ user, onSpinEnd }) => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [segments, setSegments] = useState<LotterySegment[]>(LOTTERY_SEGMENTS);

  // Fetch dynamic segments on mount
  useEffect(() => {
    const loadSettings = async () => {
        setLoading(true);
        // Try Cache First
        const cachedSettings = api.getFromCache<SystemSettings>('mnlife_settings_data');
        if (cachedSettings && cachedSettings.lotterySegments && cachedSettings.lotterySegments.length > 0) {
            setSegments(cachedSettings.lotterySegments);
            setLoading(false); // Instant unlock
        }

        try {
            const s = await api.getSettings();
            if (s.lotterySegments && s.lotterySegments.length > 0) {
                setSegments(s.lotterySegments);
            }
        } catch(e) { 
            console.error(e) 
        } finally {
            setLoading(false);
        }
    };
    loadSettings();
  }, []);

  const lotteryHistory = (user.earningHistory || []).filter(tx => tx.type === 'LOTTERY');

  const spinWheel = async () => {
    if (isSpinning || user.spinsAvailable <= 0) return;

    setIsSpinning(true);
    setResult(null);

    try {
        const { prize } = await api.spinWheel(user.id);
        
        const matchingIndices = segments.map((s, i) => s.value === prize ? i : -1).filter(i => i !== -1);
        const selectedIndex = matchingIndices[Math.floor(Math.random() * matchingIndices.length)];

        const segmentAngle = 360 / segments.length;
        const winnerCenterAngle = selectedIndex * segmentAngle + segmentAngle / 2;
        
        const targetBase = (360 - winnerCenterAngle) % 360;
        const minSpin = 1800; // 5 * 360
        const currentMod = rotation % 360;
        let dist = targetBase - currentMod;
        if (dist < 0) dist += 360; 
        
        const safeZone = (segmentAngle / 2) - 5;
        const randomOffset = (Math.random() * safeZone * 2) - safeZone;

        const finalRotation = rotation + minSpin + dist + randomOffset;

        setRotation(finalRotation);

        setTimeout(() => {
            setIsSpinning(false);
            setResult(prize);
            onSpinEnd(prize);
            showToast(`You won ${prize} BDT!`, prize > 0 ? 'success' : 'info');
        }, 4000);

    } catch (error: any) {
        setIsSpinning(false);
        showToast(error.message, 'error');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
        day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
    });
  };

  const gradientString = `conic-gradient(from 0deg, ${segments.map((s, i) => {
      const start = i * (360 / segments.length);
      const end = (i + 1) * (360 / segments.length);
      return `${s.color} ${start}deg ${end}deg`;
  }).join(', ')})`;

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-24 overflow-x-hidden relative">
      {loading && <PageLoadingOverlay />}
      
      {/* Header */}
      <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center relative shadow-md z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-400 hover:text-white">
            <ChevronLeft size={24} />
        </button>
        <h1 className="font-bold text-lg ml-2">Lucky Wheel</h1>
        <div className="ml-auto bg-slate-800 px-3 py-1 rounded-full border border-slate-700 text-xs font-bold text-yellow-500 flex items-center">
            <Gift size={12} className="mr-1" />
            <span>{user.spinsAvailable} Spins</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col items-center justify-center pt-8 px-4">
        
        {/* Wheel Container */}
        <div className="relative w-72 h-72 sm:w-80 sm:h-80 mb-8">
            {/* Pointer (Points Down to 12 o'clock) */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-3 z-20">
                <div className="w-8 h-8 bg-white rotate-45 transform origin-center border-4 border-slate-900 shadow-xl rounded-sm"></div>
            </div>

            {/* The Wheel */}
            <div 
                className="w-full h-full rounded-full border-8 border-slate-800 shadow-[0_0_20px_rgba(59,130,246,0.3)] relative overflow-hidden"
                style={{ 
                    transform: `rotate(${rotation}deg)`,
                    transition: isSpinning ? 'transform 4000ms cubic-bezier(0.25, 0.1, 0.25, 1)' : 'none',
                    background: gradientString
                }}
            >
                {/* Labels Layer */}
                {segments.map((seg, idx) => {
                    const angle = 360 / segments.length;
                    const rotate = idx * angle + angle / 2;

                    return (
                        <div
                            key={`label-${idx}`}
                            className="absolute top-0 left-1/2 w-0 h-[50%] origin-bottom flex flex-col justify-start items-center pt-3 z-10 pointer-events-none"
                            style={{
                                transform: `rotate(${rotate}deg)`,
                            }}
                        >
                            <span 
                                className="text-white font-bold text-sm drop-shadow-md whitespace-nowrap" 
                                style={{ 
                                    textShadow: '0px 1px 4px rgba(0,0,0,0.9)',
                                    transform: 'translateX(-50%)' 
                                }}
                            >
                                {seg.label}
                            </span>
                        </div>
                    );
                })}
            </div>
            
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 bg-gradient-to-br from-slate-700 to-slate-900 rounded-full border-4 border-slate-600 shadow-lg flex items-center justify-center z-10">
                <span className="text-[10px] font-bold text-slate-400">MNLife</span>
            </div>
        </div>

        {/* Spin Button */}
        <button
            onClick={spinWheel}
            disabled={isSpinning || user.spinsAvailable <= 0}
            className={`w-full max-w-xs py-4 rounded-2xl font-bold text-lg shadow-lg mb-6 transition-all active:scale-95 flex items-center justify-center space-x-2 ${
                user.spinsAvailable > 0 
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white shadow-pink-900/30' 
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
        >
            {isSpinning ? <Loader2 className="animate-spin" /> : null}
            <span>{isSpinning ? 'Spinning...' : user.spinsAvailable > 0 ? 'SPIN NOW' : 'No Spins Left'}</span>
        </button>
        
        {result !== null && !isSpinning && (
            <div className="animate-zoom-in mb-6 p-4 bg-slate-800 border border-slate-700 rounded-xl text-center w-full max-w-xs shadow-xl">
                {result > 0 ? (
                    <>
                        <Sparkles className="inline-block text-yellow-400 mb-2" size={24} />
                        <h3 className="text-xl font-bold text-white mb-1">Congratulations!</h3>
                        <p className="text-slate-300">You won <span className="font-bold text-green-400">{result} BDT</span></p>
                    </>
                ) : (
                    <>
                        <div className="inline-block text-slate-500 mb-2 font-bold text-2xl">😢</div>
                        <h3 className="text-lg font-bold text-white mb-1">Better Luck Next Time</h3>
                        <p className="text-slate-400 text-xs">Don't give up! Try again later.</p>
                    </>
                )}
            </div>
        )}

        <div className="w-full max-w-md mt-4">
             <div className="flex items-center space-x-2 mb-3 px-2">
                <HistoryIcon size={16} className="text-slate-400" />
                <h3 className="text-sm font-bold text-slate-200">Recent Wins</h3>
             </div>
             
             <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden divide-y divide-slate-800">
                {lotteryHistory.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-500">
                        No win history yet. Spin the wheel!
                    </div>
                ) : (
                    lotteryHistory.slice(0, 5).map((tx) => (
                        <div key={tx.id} className="p-3 flex justify-between items-center">
                            <div className="flex items-center space-x-3">
                                <div className="p-2 bg-pink-900/20 text-pink-500 rounded-lg">
                                    <Ticket size={14} />
                                </div>
                                <div>
                                    <p className="text-xs font-bold text-white">Lucky Wheel Win</p>
                                    <p className="text-[10px] text-slate-500">{formatDate(tx.date)}</p>
                                </div>
                            </div>
                            <span className="text-sm font-bold text-green-400">+{tx.amount} BDT</span>
                        </div>
                    ))
                )}
             </div>
        </div>

        <div className="w-full max-w-md mt-6 bg-slate-900/50 rounded-xl p-4 border border-slate-800">
            <h3 className="text-sm font-bold text-slate-300 mb-3 flex items-center">
                <AlertCircle size={14} className="mr-2" />
                How to get spins?
            </h3>
            <ul className="space-y-3 text-xs text-slate-400">
                <li className="flex items-center justify-between p-2 bg-slate-800 rounded-lg">
                    <span>Account Creation</span>
                    <span className="text-green-400 font-bold">+1 Spin (Free)</span>
                </li>
                <li className="flex items-center justify-between p-2 bg-slate-800 rounded-lg">
                    <span>Buy VIP Plan</span>
                    <span className="text-green-400 font-bold">+1 Spin</span>
                </li>
                <li className="flex items-center justify-between p-2 bg-slate-800 rounded-lg">
                    <span>Invite Friend</span>
                    <span className="text-green-400 font-bold">+1 Spin</span>
                </li>
            </ul>
        </div>

      </div>
    </div>
  );
};

export default Lottery;
