
import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { X, Globe, Clock, CheckCircle, AlertTriangle, ArrowLeft, ExternalLink, ShieldAlert } from 'lucide-react';
import { Task } from '../types';
import { api } from '../services/api';
import PageLoadingOverlay from '../components/PageLoadingOverlay';

interface TaskViewProps {
  onComplete: (amount: number) => void;
  onFail: (penaltyAmount: number) => void;
}

const TaskView: React.FC<TaskViewProps> = ({ onComplete, onFail }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const task = location.state?.task as Task; 
  const isInternalNavigation = useRef(false);

  const [timer, setTimer] = useState(task ? task.durationSeconds : 0);
  const [isFinished, setIsFinished] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [penaltyPercent, setPenaltyPercent] = useState(30);

  // Prevent browser back button with strict trap
  useEffect(() => {
    // Push state twice to create a buffer
    window.history.pushState(null, document.title, window.location.href);
    window.history.pushState(null, document.title, window.location.href);

    const handlePopState = (event: PopStateEvent) => {
      if (isInternalNavigation.current) return;

      // If task is not finished, block back and show warning
      if (!isFinished && timer > 0) {
          // Push state again immediately to keep user on page
          window.history.pushState(null, document.title, window.location.href);
          setShowExitConfirm(true);
      }
    };

    window.addEventListener('popstate', handlePopState);

    // Prompt on tab close/refresh
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
        if (!isFinished && timer > 0) {
            e.preventDefault();
            e.returnValue = '';
        }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isFinished, timer]);

  useEffect(() => {
    if (!task) {
        isInternalNavigation.current = true;
        navigate('/work');
        return;
    }
    const loadSettings = async () => {
        setLoading(true);
        try {
            const s = await api.getSettings();
            setPenaltyPercent(s.taskPenaltyPercent);
        } catch(e) { console.error(e) }
        finally {
            setTimeout(() => setLoading(false), 800);
        }
    };
    loadSettings();
  }, [task, navigate]);

  useEffect(() => {
    if (!loading && timer > 0) {
      const interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    } else if (timer <= 0) {
      setIsFinished(true);
    }
  }, [timer, loading]);

  if (!task) return null;

  const handleClose = () => {
    if (isFinished) {
        handleClaimAndExit();
    } else {
        setShowExitConfirm(true);
    }
  };

  const confirmExit = () => {
    isInternalNavigation.current = true;
    const penalty = task.reward * (penaltyPercent / 100);
    onFail(penalty);
    navigate('/work');
  };

  const handleClaimAndExit = () => {
    if (!isFinished) return;
    isInternalNavigation.current = true;
    onComplete(task.reward); 
    navigate('/work');
  };

  const openExternal = () => {
    window.open(task.url, '_blank');
  };

  // Determine if we should show iframe or just a button (for sites that block iframes)
  const isEmbeddable = !['YOUTUBE', 'FACEBOOK'].includes(task.platform);

  return (
    <div className="flex flex-col h-screen bg-slate-950 relative">
      {loading && <PageLoadingOverlay />}
      
      {/* Header Bar */}
      <div className="bg-slate-900 border-b border-slate-700 p-3 shadow-md flex items-center justify-between h-16 shrink-0 z-50">
        
        {/* Left: Close / Back */}
        <button 
            onClick={handleClose}
            className={`p-2 rounded-full border transition-colors ${isFinished ? 'bg-green-600 border-green-500 text-white animate-pulse' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
        >
            {isFinished ? <ArrowLeft size={20} /> : <X size={20} />}
        </button>

        {/* Center: Timer / Status */}
        <div className="flex flex-col items-center">
            {isFinished ? (
                <div className="flex items-center space-x-2 text-green-400 font-bold bg-green-500/10 px-4 py-1 rounded-full border border-green-500/30">
                    <CheckCircle size={16} />
                    <span>Task Completed</span>
                </div>
            ) : (
                <div className="flex items-center space-x-2 text-white font-mono text-xl font-bold bg-slate-800 px-4 py-1 rounded-full border border-slate-700">
                    <Clock size={18} className="text-blue-500" />
                    <span>{timer}s</span>
                </div>
            )}
        </div>

        {/* Right: External Link */}
        <button 
            onClick={openExternal}
            className="p-2 bg-slate-800 border border-slate-700 rounded-full text-blue-400 hover:text-white hover:bg-slate-700 transition-colors"
            title="Open in Browser"
        >
            <Globe size={20} />
        </button>
      </div>

      {/* Progress Bar */}
      {!isFinished && (
        <div className="h-1 w-full bg-slate-900">
            <div 
                className="h-full bg-blue-500 transition-all duration-1000 ease-linear"
                style={{ width: `${((task.durationSeconds - timer) / task.durationSeconds) * 100}%` }}
            ></div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 bg-slate-900 relative overflow-hidden flex flex-col">
        {!loading && isEmbeddable ? (
            <div className="w-full h-full relative">
                <iframe 
                    src={task.url} 
                    title="Task Content"
                    className="w-full h-full border-0 bg-white"
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                    referrerPolicy="no-referrer"
                />
                
                {/* Overlay Button for problematic sites */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 opacity-70 hover:opacity-100 transition-opacity">
                    <button 
                        onClick={openExternal}
                        className="bg-slate-800/80 backdrop-blur text-white px-4 py-2 rounded-full text-xs font-bold border border-white/20 shadow-lg flex items-center"
                    >
                        <ExternalLink size={12} className="mr-1" /> Not loading? Open External
                    </button>
                </div>
            </div>
        ) : (
            // Fallback View for non-embeddable sites
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-slate-900 to-slate-800">
                <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mb-6 animate-pulse">
                    <Globe size={40} className="text-blue-400" />
                </div>
                <h2 className="text-xl font-bold text-white mb-2">{task.title}</h2>
                <p className="text-slate-400 text-sm mb-8 max-w-xs">
                    This task requires you to visit an external website. Click the button below to start.
                </p>
                <button 
                    onClick={openExternal}
                    className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold shadow-lg shadow-blue-900/40 flex items-center text-lg active:scale-95 transition-transform"
                >
                    <ExternalLink size={20} className="mr-2" /> Open Task Link
                </button>
                <p className="mt-6 text-xs text-yellow-500 flex items-center bg-yellow-500/10 px-3 py-2 rounded-lg border border-yellow-500/20">
                    <AlertTriangle size={12} className="mr-1" /> Do not close this app while browsing
                </p>
            </div>
        )}
      </div>

      {/* Completion Floating Action Button (FAB) */}
      {isFinished && (
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-[60] animate-bounce w-full px-6 max-w-sm">
              <button 
                onClick={handleClaimAndExit}
                className="w-full bg-green-600 hover:bg-green-500 text-white py-4 rounded-2xl font-bold shadow-2xl shadow-green-900/50 flex items-center justify-center space-x-2 border-2 border-white/20 text-lg"
              >
                  <CheckCircle size={24} />
                  <span>CLAIM REWARD</span>
              </button>
          </div>
      )}

      {/* Exit Confirmation Modal (Penalty Warning) */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md animate-fade-in p-6">
            <div className="bg-slate-900 w-full max-w-xs rounded-2xl p-6 border border-red-500/50 shadow-2xl text-center relative overflow-hidden">
                {/* Warning Glow */}
                <div className="absolute top-0 left-0 w-full h-1 bg-red-500 shadow-[0_0_20px_rgba(239,68,68,1)]"></div>
                
                <div className="w-16 h-16 bg-red-900/20 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-red-500/30 animate-pulse">
                    <ShieldAlert size={32} />
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">Warning!</h3>
                <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                    Leaving the task early is prohibited. If you exit now, you will receive a penalty.
                </p>
                
                <div className="bg-red-500/10 p-3 rounded-xl border border-red-500/20 mb-6">
                    <p className="text-xs text-red-400 font-bold uppercase tracking-wider mb-1">Penalty Amount</p>
                    <p className="text-2xl font-bold text-red-500">
                        -৳{(task.reward * (penaltyPercent / 100)).toFixed(2)}
                    </p>
                </div>

                <div className="flex flex-col gap-3">
                    <button 
                        onClick={() => setShowExitConfirm(false)}
                        className="w-full py-3 rounded-xl bg-green-600 text-white font-bold hover:bg-green-500 shadow-lg"
                    >
                        Continue Task
                    </button>
                    <button 
                        onClick={confirmExit}
                        className="w-full py-3 rounded-xl bg-slate-800 text-slate-400 font-bold hover:bg-slate-700 hover:text-red-400 transition-colors"
                    >
                        Quit & Pay Penalty
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default TaskView;
