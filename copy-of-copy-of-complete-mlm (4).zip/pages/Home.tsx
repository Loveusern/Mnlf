
import React, { useState, useEffect } from 'react';
import { User, VipTier, AppNotification, SystemSettings } from '../types';
import { VIP_TIERS, EARNING_NOTIFICATIONS, SLIDER_IMAGES } from '../constants';
import { Wallet, Users, Bell, User as UserIcon, Crown, X, MessageSquare, Ticket, Trash2, RefreshCw, Calendar, CheckSquare, TrendingUp, History, UserPlus, DollarSign } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { useToast } from '../components/ToastContext';
import PageLoadingOverlay from '../components/PageLoadingOverlay';

interface HomeProps {
  user: User | null;
  onRequireAuth: () => void;
  onUpdateUser?: (user: User) => void;
  onRefresh?: () => void;
}

const Home: React.FC<HomeProps> = ({ user, onRequireAuth, onUpdateUser, onRefresh }) => {
  const { showToast } = useToast();
  const [vipLevels, setVipLevels] = useState<VipTier[]>(VIP_TIERS);
  const [sliderImages, setSliderImages] = useState<string[]>(SLIDER_IMAGES);
  const [broadcasts, setBroadcasts] = useState<AppNotification[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // Logic: Combine Private + Broadcasts, filtering out hidden broadcasts
  const hiddenIds = user?.hiddenBroadcasts || [];
  
  const allNotifications = [
      ...(user?.notifications || []),
      ...broadcasts
        .filter(b => !hiddenIds.includes(b.id)) // Filter hidden ones
        .map(b => ({ ...b, isBroadcast: true })) 
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const unreadCount = allNotifications.length;

  useEffect(() => {
    const fetchData = async () => {
        const cachedSettings = api.getFromCache<SystemSettings>('mnlife_settings_data');
        if (cachedSettings) {
             if (cachedSettings.vipTiers) setVipLevels(cachedSettings.vipTiers);
             if (cachedSettings.sliderImages) setSliderImages(cachedSettings.sliderImages);
             if (cachedSettings.broadcasts) setBroadcasts(cachedSettings.broadcasts);
             setIsLoading(false);
        }

        try {
            const settings = await api.getSettings();
            if (settings.vipTiers && settings.vipTiers.length > 0) setVipLevels(settings.vipTiers);
            if (settings.sliderImages && settings.sliderImages.length > 0) setSliderImages(settings.sliderImages);
            if (settings.broadcasts) {
                setBroadcasts(settings.broadcasts);
                
                // Auto-Open Notification Modal logic
                if (user && settings.broadcasts.length > 0) {
                    const activeBroadcasts = settings.broadcasts.filter(b => !(user.hiddenBroadcasts || []).includes(b.id));
                    
                    if (activeBroadcasts.length > 0) {
                        const latestBroadcastId = activeBroadcasts[0].id;
                        const lastSeen = sessionStorage.getItem('last_seen_broadcast');
                        
                        if (lastSeen !== latestBroadcastId) {
                            setShowNotifications(true);
                            sessionStorage.setItem('last_seen_broadcast', latestBroadcastId);
                        }
                    }
                }
            }
        } catch (e) {
            console.error("Failed to load config", e);
        } finally {
            setIsLoading(false);
        }
    };
    fetchData();
  }, [user]);

  const currentVip = user ? (vipLevels.find(v => v.level === user.vipLevel) || vipLevels[0]) : vipLevels[0];
  const navigate = useNavigate();
  
  // Calculate Today Referrals (Mock logic based on available data structure, ideally backend handles this)
  // Assuming user.referrals contains basic info or is populated. If empty, 0.
  const todayRef = user?.referrals?.filter(r => new Date(r.joinDate).toDateString() === new Date().toDateString()).length || 0;

  const handleLottery = () => {
      if (user) {
          navigate('/lottery');
      } else {
          onRequireAuth();
      }
  };
  
  const handleNotification = () => {
      if (user) {
          setShowNotifications(true);
      } else {
          onRequireAuth();
      }
  };

  const handleManualRefresh = async () => {
      if (!user) return;
      setIsRefreshing(true);
      if (onRefresh) {
          await onRefresh();
          showToast('Updated', 'success');
      }
      setTimeout(() => setIsRefreshing(false), 1000);
  };

  const handleDeleteNotification = (notifId: string, isBroadcast?: boolean) => {
      if (!user || !onUpdateUser) return;
      
      if (isBroadcast) {
          const newHidden = [...(user.hiddenBroadcasts || []), notifId];
          onUpdateUser({ ...user, hiddenBroadcasts: newHidden });
          showToast("Broadcast removed", 'success');
      } else {
          const updatedNotifs = (user.notifications || []).filter(n => n.id !== notifId);
          onUpdateUser({ ...user, notifications: updatedNotifs });
          showToast("Message deleted", 'success');
      }
  };

  return (
    <div className="pb-24 bg-slate-950 min-h-screen text-white relative">
      {isLoading && <PageLoadingOverlay />}
      
      {/* Header */}
      <div className="bg-slate-900 p-4 sticky top-0 z-20 shadow-md border-b border-slate-800 flex justify-between items-center">
        <div className="flex items-center space-x-2">
            <h1 className="font-bold text-xl text-white tracking-wider">MNLife</h1>
        </div>
        
        <div className="flex items-center space-x-3">
            {user && (
                <button 
                    onClick={handleManualRefresh} 
                    className="p-2 bg-slate-800 rounded-full text-green-400 border border-slate-700 shadow-sm active:scale-95 transition-transform"
                    title="Refresh Balance"
                >
                    <RefreshCw size={18} className={isRefreshing ? 'animate-spin' : ''} />
                </button>
            )}

            <button 
                onClick={handleLottery} 
                className="p-2 bg-slate-800 rounded-full text-pink-500 border border-slate-700 shadow-sm active:scale-95 transition-transform"
            >
                <Ticket size={18} />
            </button>

            <div className="relative">
                <button 
                    onClick={handleNotification} 
                    className="p-2 bg-slate-800 rounded-full text-blue-400 border border-slate-700 shadow-sm active:scale-95 transition-transform"
                >
                    <Bell size={18} />
                </button>
                {unreadCount > 0 && (
                    <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-slate-900"></span>
                )}
            </div>

            <div 
            className="bg-slate-800 px-3 py-1.5 rounded-full text-xs font-bold flex items-center text-slate-300 border border-slate-700 cursor-pointer shadow-sm" 
            onClick={user ? undefined : onRequireAuth}
            >
                {user ? <Crown size={12} className="mr-1 text-yellow-500" /> : <UserIcon size={12} className="mr-1" />}
                {user ? currentVip.name : "Guest"}
            </div>
        </div>
      </div>

      {/* Slider */}
      <div className="relative w-full h-40 bg-slate-900">
        <div className="absolute inset-0 flex overflow-x-auto snap-x snap-mandatory no-scrollbar">
          {sliderImages.map((img, idx) => (
            <img key={idx} src={img} alt="Promotion" className="w-full h-full object-cover flex-shrink-0 snap-center opacity-90" />
          ))}
        </div>
        <div className="absolute bottom-2 left-0 right-0 flex justify-center space-x-1">
          {sliderImages.map((_, idx) => (
            <div key={idx} className="w-1.5 h-1.5 rounded-full bg-white/60"></div>
          ))}
        </div>
      </div>

      {/* Marquee */}
      <div className="m-4 bg-slate-800 rounded-2xl p-4 shadow-lg border border-slate-700">
        <h2 className="text-center text-white font-bold text-lg mb-3">Membership Earning</h2>
        <div className="h-40 overflow-hidden relative">
          <div className="animate-scroll-y space-y-3">
             {[...EARNING_NOTIFICATIONS, ...EARNING_NOTIFICATIONS].map((item, idx) => (
               <div key={idx} className="bg-slate-900/50 p-3 rounded-xl flex items-center justify-between border border-slate-700/50">
                  <div className="flex items-center space-x-3">
                    <img src={item.img} alt="User" className="w-10 h-10 rounded-full border-2 border-slate-600" />
                    <div>
                      <p className="text-sm font-bold text-white">Congrats {item.user}</p>
                      <p className="text-xs text-slate-400">{item.label}</p>
                    </div>
                  </div>
                  <p className="font-bold text-blue-400">{item.amount} BDT</p>
               </div>
             ))}
          </div>
        </div>
      </div>

      {/* VIP & Stats Area */}
      {user && (
        <>
          {/* VIP Card */}
          <div className="mx-4 mb-4 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 text-center shadow-lg border border-slate-700 relative overflow-hidden">
             <div className="absolute -top-10 -right-10 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl"></div>
             <h2 className="text-4xl font-bold text-blue-400 mb-2 drop-shadow-sm tracking-tight">{currentVip.name}</h2>
             <p className="text-slate-400 text-sm font-medium bg-slate-950/30 inline-block px-3 py-1 rounded-full">
                {user.vipExpiryDate ? `Expires on ${new Date(user.vipExpiryDate).toLocaleDateString()}` : `Validity: ${currentVip.validityDays} Days`}
             </p>
             {user.vipExpiryDate && <CountdownTimer targetDate={user.vipExpiryDate} />}
          </div>

          {/* Combined Balance & Team Earn Card */}
          <div className="mx-4 mb-4 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-5 shadow-xl border border-blue-500/30 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full blur-2xl transform translate-x-8 -translate-y-8"></div>
              <div className="flex justify-between items-center relative z-10">
                 <div className="flex-1">
                    <p className="text-xs text-blue-100 uppercase font-bold tracking-wider mb-1 flex items-center"><Wallet size={12} className="mr-1"/> Total Balance</p>
                    <h3 className="text-3xl font-extrabold tracking-tight">৳{(user.balance || 0).toFixed(2)}</h3>
                 </div>
                 <div className="w-[1px] h-10 bg-white/20 mx-4"></div>
                 <div className="text-right flex-1">
                    <p className="text-xs text-blue-100 uppercase font-bold tracking-wider mb-1 flex items-center justify-end">Team Earn (Today) <Users size={12} className="ml-1"/></p>
                    <h3 className="text-xl font-bold">৳{(user.todayReferralBonus || 0).toFixed(2)}</h3>
                 </div>
              </div>
          </div>

          {/* STATISTICS GRID */}
          <div className="grid grid-cols-2 gap-3 mx-4 mb-20">
             <EarningCard 
                label="Today Referrals" 
                value={todayRef.toString()} 
                icon={UserPlus} 
                color="text-orange-400"
             />
             <EarningCard 
                label="Today Task" 
                value={`${user.tasksCompletedToday || 0}/${currentVip.dailyTasks}`} 
                icon={CheckSquare} 
                color="text-pink-400"
             />
             <EarningCard 
                label="Yesterday Earn" 
                value={(user.yesterdayEarnings || 0).toFixed(2)} 
                icon={History} 
                color="text-blue-400"
                isMoney
             />
             <EarningCard 
                label="Weekly Earn" 
                value={(user.weeklyEarnings || 0).toFixed(2)} 
                icon={Calendar} 
                color="text-purple-400"
                isMoney
             />
             <EarningCard 
                label="Monthly Earn" 
                value={(user.monthlyEarnings || 0).toFixed(2)} 
                icon={Calendar} 
                color="text-yellow-400"
                isMoney
             />
             <EarningCard 
                label="Total Revenue" 
                value={(user.totalEarnings || 0).toFixed(2)} 
                icon={DollarSign} 
                color="text-green-400"
                isMoney
             />
          </div>
        </>
      )}

      {!user && (
        <div className="mx-4 mb-8 p-6 border-2 border-dashed border-blue-500/30 rounded-2xl bg-blue-500/5 text-center relative">
           <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-slate-950 px-3 text-blue-400 text-xs font-bold uppercase tracking-widest">Limited Offer</div>
           <h3 className="text-blue-400 font-bold text-xl mb-2">Intern Trial</h3>
           <p className="text-slate-400 text-sm">Upgrade to a VIP level to unlock full features!</p>
        </div>
      )}

      {/* Notifications Modal */}
      {showNotifications && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in p-4">
           <div className="bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-700 flex flex-col max-h-[70vh]">
              <div className="p-4 border-b border-slate-800 flex justify-between items-center">
                 <h3 className="font-bold text-lg">Notifications</h3>
                 <button onClick={() => setShowNotifications(false)}><X size={20} className="text-slate-400" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                 {allNotifications.length > 0 ? (
                    allNotifications.map((notif) => (
                        <div key={notif.id} className={`p-3 rounded-xl border flex items-start space-x-3 ${notif.read ? 'bg-slate-800 border-slate-700 opacity-70' : 'bg-slate-800/50 border-blue-500/50 shadow-md'} ${(notif as any).isBroadcast ? 'border-yellow-500/30' : ''}`}>
                             <div className={`mt-1 p-2 rounded-full ${(notif as any).isBroadcast ? 'bg-yellow-500/20 text-yellow-500' : notif.type === 'REFERRAL' ? 'bg-green-500/20 text-green-500' : 'bg-blue-500/20 text-blue-500'}`}>
                                 {notif.type === 'REFERRAL' ? <Users size={16} /> : (notif as any).isBroadcast ? <Bell size={16} /> : <MessageSquare size={16} />}
                             </div>
                             <div className="flex-1">
                                 <div className="flex justify-between items-start">
                                     <h4 className="font-bold text-sm text-white">{(notif as any).isBroadcast ? "[Admin] " : ""}{notif.title}</h4>
                                     <button 
                                        onClick={() => handleDeleteNotification(notif.id, (notif as any).isBroadcast)}
                                        className="text-slate-500 hover:text-red-400 p-1 -mt-1 -mr-2"
                                        title="Delete Message"
                                     >
                                         <Trash2 size={14} />
                                     </button>
                                 </div>
                                 <p className="text-xs text-slate-400 mt-1">{notif.message}</p>
                                 <p className="text-[10px] text-slate-500 mt-2 text-right">{new Date(notif.date).toLocaleDateString()} {new Date(notif.date).toLocaleTimeString()}</p>
                             </div>
                        </div>
                    ))
                 ) : (
                    <div className="text-center text-slate-500 py-10">No notifications</div>
                 )}
              </div>
           </div>
        </div>
      )}

      <style>{`
        @keyframes scrollY {
          0% { transform: translateY(0); }
          100% { transform: translateY(-50%); }
        }
        .animate-scroll-y {
          animation: scrollY 15s linear infinite;
        }
      `}</style>
    </div>
  );
};

const EarningCard: React.FC<{ label: string; value: string; icon: any; color?: string; isMoney?: boolean }> = ({ label, value, icon: Icon, color = 'text-white', isMoney = false }) => (
    <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl border border-slate-700/50 shadow-sm p-4 flex flex-col justify-between h-full relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-3 opacity-5 group-hover:opacity-10 transition-opacity">
            <Icon size={40} />
        </div>
        <div className="flex items-center space-x-2 mb-2 relative z-10">
            <div className="p-1.5 bg-slate-950 rounded-lg border border-slate-800">
                <Icon size={14} className={color} />
            </div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{label}</p>
        </div>
        <p className={`text-lg font-bold relative z-10 ${color === 'text-white' ? 'text-white' : color}`}>
            {isMoney ? `৳${value}` : value}
        </p>
    </div>
);

const CountdownTimer = ({ targetDate }: { targetDate: string }) => {
    const [timeLeft, setTimeLeft] = useState<{days: number, hours: number, minutes: number, seconds: number} | null>(null);

    useEffect(() => {
        const calculateTimeLeft = () => {
            const difference = new Date(targetDate).getTime() - new Date().getTime();
            if (isNaN(difference) || difference <= 0) return null;
            return {
                days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60)
            };
        };
        setTimeLeft(calculateTimeLeft());
        const timer = setInterval(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);
        return () => clearInterval(timer);
    }, [targetDate]);

    if (!timeLeft) {
        return (
            <div className="mt-4 inline-block px-4 py-2 bg-red-500/20 text-red-400 rounded-lg text-sm font-bold border border-red-500/50">
                Plan Expired
            </div>
        );
    }
    
    return (
        <div className="mt-4 flex justify-center space-x-2 text-slate-200">
            <TimeUnit val={timeLeft.days.toString().padStart(2, '0')} label="d" />
            <span className="text-xl font-bold self-center">:</span>
            <TimeUnit val={timeLeft.hours.toString().padStart(2, '0')} label="h" />
            <span className="text-xl font-bold self-center">:</span>
            <TimeUnit val={timeLeft.minutes.toString().padStart(2, '0')} label="m" />
            <span className="text-xl font-bold self-center">:</span>
            <TimeUnit val={timeLeft.seconds.toString().padStart(2, '0')} label="s" />
        </div>
    );
}

const TimeUnit = ({ val, label }: { val: string, label: string }) => (
    <div className="text-center">
        <span className="text-xl font-mono font-bold">{val}</span>
        <span className="text-xs text-slate-500 ml-0.5">{label}</span>
    </div>
)

export default Home;
