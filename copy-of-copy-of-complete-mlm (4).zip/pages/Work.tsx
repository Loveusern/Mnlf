
import React, { useMemo, useState, useEffect, useRef } from 'react';
import { User, Task, VipTier, SystemSettings } from '../types';
import { VIP_TIERS } from '../constants';
import { api } from '../services/api';
import { Play, Facebook, Youtube, Coins, Tag, Timer as TimerIcon, Lock, CheckCircle, Crown, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PageLoadingOverlay from '../components/PageLoadingOverlay';

interface WorkProps {
  user: User | null;
  onTaskComplete: (reward: number) => void;
  onRequireAuth: () => void;
}

const ShimmerStyles = () => (
  <style>{`
    @keyframes shimmer {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(100%); }
    }
    .animate-shimmer {
      animation: shimmer 1.5s infinite linear;
    }
  `}</style>
);

const TaskSkeleton = () => (
  <div className="rounded-xl p-4 flex items-center border border-slate-800 bg-slate-800 relative overflow-hidden shadow-sm">
      {/* Shimmer Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-slate-600/20 to-transparent animate-shimmer z-10 pointer-events-none"></div>
      
      {/* Icon */}
      <div className="w-14 h-14 rounded-full bg-slate-700/50 mr-4 flex-shrink-0 border border-slate-600/30"></div>
      
      {/* Content */}
      <div className="flex-1 min-w-0 space-y-3">
          <div className="h-4 bg-slate-700/50 rounded w-3/4"></div>
          <div className="flex items-center space-x-3">
               <div className="h-3 bg-slate-700/50 rounded w-16"></div>
               <div className="h-3 bg-slate-700/50 rounded w-12"></div>
          </div>
          <div className="h-4 bg-slate-700/50 rounded w-1/3"></div>
      </div>
      
      {/* Button */}
      <div className="ml-3 w-20 h-9 bg-slate-700/50 rounded-full"></div>
  </div>
);

const Work: React.FC<WorkProps> = ({ user, onTaskComplete, onRequireAuth }) => {
  const navigate = useNavigate();
  const [timeUntilReset, setTimeUntilReset] = useState('');
  const [availableTasks, setAvailableTasks] = useState<Task[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(true);
  const [vipLevels, setVipLevels] = useState<VipTier[]>(VIP_TIERS);
  
  // Infinite Scroll State
  const [visibleCount, setVisibleCount] = useState(20);
  const [loadingMore, setLoadingMore] = useState(false);
  const loaderRef = useRef<HTMLDivElement>(null);
  
  // Fetch VIP Settings & Tasks
  useEffect(() => {
    const initData = async () => {
        setLoadingTasks(true);
        // Try load from cache first for instant UI
        const cachedTasks = api.getFromCache<Task[]>('mnlife_tasks_data');
        const cachedSettings = api.getFromCache<SystemSettings>('mnlife_settings_data');
        
        if (cachedTasks && cachedTasks.length > 0) {
            setAvailableTasks(cachedTasks);
            if (cachedSettings?.vipTiers) {
                setVipLevels(cachedSettings.vipTiers);
            }
            setLoadingTasks(false); // Instant load
        }

        try {
            // Parallel fetch network
            const [tasks, settings] = await Promise.all([
                api.getTasks(),
                api.getSettings()
            ]);
            
            setAvailableTasks(tasks);
            if (settings.vipTiers && settings.vipTiers.length > 0) {
                setVipLevels(settings.vipTiers);
            }
        } catch (error) {
            console.error("Failed to fetch data", error);
        } finally {
            setLoadingTasks(false);
        }
    };
    initData();
  }, []);

  const currentVip = user ? (vipLevels.find(v => v.level === user.vipLevel) || vipLevels[0]) : vipLevels[0];
  const tasksCompleted = user ? user.tasksCompletedToday : 0;
  
  // Logic: Allow access only if completed < daily limit
  const remainingTasks = Math.max(0, currentVip.dailyTasks - tasksCompleted);
  const isDailyLimitReached = remainingTasks === 0;

  // Generate Full Task List (Simulating Unlimited/Admin Managed Pool)
  const fullTaskList = useMemo(() => {
    if (availableTasks.length === 0) return [];
    
    // We generate a large number (e.g., 200) to represent "Unlimited" tasks available on the platform
    const SYSTEM_TASK_POOL_SIZE = 200; 

    return Array.from({ length: SYSTEM_TASK_POOL_SIZE }).map((_, index) => {
        const template = availableTasks[index % availableTasks.length];
        return {
            ...template,
            id: `task_${index}`, // ID is now index based
            title: `${template.title} ${index + 1}`,
            reward: currentVip.taskRate // Reward is determined by User's VIP level
        };
    });
  }, [currentVip, availableTasks]);

  // Infinite Scroll Logic
  useEffect(() => {
      const observer = new IntersectionObserver((entries) => {
          const target = entries[0];
          // Check against the FILTERED list length, not full list
          const effectiveListLength = fullTaskList.length - tasksCompleted;
          
          if (target.isIntersecting && !loadingMore && visibleCount < effectiveListLength) {
              setLoadingMore(true);
              // Simulate network load for effect
              setTimeout(() => {
                  setVisibleCount(prev => Math.min(prev + 20, effectiveListLength));
                  setLoadingMore(false);
              }, 1500);
          }
      }, {
          root: null,
          rootMargin: '100px',
          threshold: 0.1
      });

      if (loaderRef.current) {
          observer.observe(loaderRef.current);
      }

      return () => {
          if (loaderRef.current) observer.unobserve(loaderRef.current);
      }
  }, [loadingMore, visibleCount, fullTaskList.length, tasksCompleted]);

  // HIDE COMPLETED TASKS LOGIC:
  const activeTaskList = useMemo(() => {
      return fullTaskList.slice(tasksCompleted);
  }, [fullTaskList, tasksCompleted]);

  const visibleTasks = activeTaskList.slice(0, visibleCount);

  useEffect(() => {
    const updateCountdown = () => {
        const now = new Date();
        const midnight = new Date();
        midnight.setHours(24, 0, 0, 0); 
        const diff = midnight.getTime() - now.getTime();
        
        if (diff < 0) {
            setTimeUntilReset("00h 00m 00s");
            return;
        }
        const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const m = Math.floor((diff / (1000 * 60)) % 60);
        const s = Math.floor((diff / 1000) % 60);
        setTimeUntilReset(
            `${h.toString().padStart(2, '0')}h ${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`
        );
    };
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  const startTask = (task: Task) => {
    if (!user) {
        onRequireAuth();
        return;
    }
    // STRICT CHECK: VIP Limit
    if (remainingTasks <= 0) {
        alert(`Daily limit of ${currentVip.dailyTasks} tasks reached! Upgrade VIP for more.`);
        return;
    }
    navigate('/task/view', { state: { task } });
  };

  const getPlatformIcon = (platform: string) => {
      switch(platform) {
          case 'FACEBOOK': return <Facebook className="text-blue-500" size={32} fill="currentColor" />;
          case 'YOUTUBE': return <div className="bg-red-600 rounded-lg px-2 py-1"><Play className="text-white" size={20} fill="currentColor" /></div>;
          case 'WIKIPEDIA': return <div className="text-3xl font-serif text-slate-200 font-bold bg-slate-700 w-10 h-10 flex items-center justify-center rounded">W</div>;
          default: return <Tag className="text-slate-400" size={32} />;
      }
  };

  return (
    <div className="pb-24 px-4 pt-4 min-h-screen bg-slate-950 text-white relative">
      {loadingTasks && <PageLoadingOverlay />}
      <ShimmerStyles />
      {/* Header Info Card */}
      <div className="bg-gradient-to-r from-blue-900 via-slate-800 to-purple-900 rounded-xl p-[1px] shadow-lg mb-4">
          <div className="bg-slate-900/90 backdrop-blur-sm rounded-xl p-6 relative overflow-hidden">
            <div className="flex justify-between items-start mb-4">
                 <div>
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">Current Position</p>
                    <div className="flex items-center space-x-2">
                        <h2 className={`text-2xl font-bold ${isDailyLimitReached ? 'text-green-400' : 'text-blue-400'}`}>
                            {user ? currentVip.name : "Guest Mode"}
                        </h2>
                        {!user && <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">Guest</span>}
                    </div>
                 </div>
                 <div className="text-right">
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">Rate / Task</p>
                    {user ? (
                        <h2 className="text-2xl font-bold text-yellow-400">৳{currentVip.taskRate}</h2>
                    ) : (
                        <h2 className="text-2xl font-bold text-slate-500 flex items-center justify-end">
                            <Lock size={20} className="mr-1" /> --
                        </h2>
                    )}
                 </div>
            </div>
            <div className="flex items-center space-x-2 bg-slate-800/50 p-2 rounded-lg border border-slate-700/50">
                 <Coins size={16} className="text-green-400" />
                 <span className="text-xs text-slate-300">Today's Potential: <span className="text-white font-bold">{user ? `৳${currentVip.dailyIncome}` : '--'}</span></span>
            </div>
          </div>
      </div>

      {/* Stats Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center text-center text-xs sm:text-sm mb-6 shadow-md">
            <div className="flex-1">
                <p className="text-slate-400 mb-1">Tasks Done</p>
                {user ? (
                   <p className="font-bold text-lg text-white">{tasksCompleted} <span className="text-slate-500 text-xs">/ {currentVip.dailyTasks}</span></p>
                ) : (
                   <p className="font-bold text-lg text-slate-600">-- <span className="text-slate-700 text-xs">/ --</span></p>
                )}
            </div>
            <div className="w-[1px] h-8 bg-slate-800"></div>
            <div className="flex-1">
                <p className="text-slate-400 mb-1">Remain</p>
                {user ? (
                   <p className={`font-bold text-lg ${remainingTasks === 0 ? 'text-green-500' : 'text-blue-400'}`}>{remainingTasks}</p>
                ) : (
                   <p className="font-bold text-lg text-slate-600">--</p>
                )}
            </div>
            <div className="w-[1px] h-8 bg-slate-800"></div>
            <div className="flex-1">
                <p className="text-slate-400 mb-1">Reset In</p>
                {user ? (
                    <div className="flex items-center justify-center space-x-1 text-yellow-500 font-mono font-bold text-lg">
                        <TimerIcon size={14} />
                        <span>{timeUntilReset}</span>
                    </div>
                ) : (
                    <div className="flex items-center justify-center space-x-1 text-slate-600 font-mono font-bold text-lg">
                        <span>--:--:--</span>
                    </div>
                )}
            </div>
      </div>

      {/* Dynamic Task List */}
      <div className="space-y-4">
        {loadingTasks && visibleTasks.length === 0 ? (
            // Initial Skeleton Loading - now mostly covered by overlay, but kept for fallback
            <div className="space-y-4 animate-fade-in opacity-50">
                {Array.from({ length: 4 }).map((_, i) => (
                    <TaskSkeleton key={i} />
                ))}
            </div>
        ) : visibleTasks.length === 0 ? (
             <div className="py-10 text-center text-slate-500">
                {isDailyLimitReached ? (
                   <p className="text-green-400 font-bold">All daily tasks completed!</p>
                ) : (
                   <p>No tasks available.</p>
                )}
             </div>
        ) : (
            <>
                {visibleTasks.map((task) => {
                    const isLockedDueToLimit = isDailyLimitReached;

                    return (
                        <div key={task.id} className={`rounded-xl p-4 flex items-center border transition-all ${isLockedDueToLimit ? 'bg-slate-800 border-slate-700 opacity-70' : 'bg-slate-800 border-slate-700 shadow-md'}`}>
                            <div className="w-14 h-14 flex items-center justify-center mr-4 flex-shrink-0 bg-slate-900 rounded-full border border-slate-700">
                                {getPlatformIcon(task.platform)}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                                <h3 className="font-bold text-sm sm:text-base mb-1 truncate text-white">{task.title}</h3>
                                <div className="flex items-center space-x-3 text-xs text-slate-400">
                                    <span className="flex items-center bg-slate-900 px-2 py-0.5 rounded"><Tag size={10} className="mr-1" /> {task.tag}</span>
                                    <span className="flex items-center"><TimerIcon size={10} className="mr-1" /> {task.description}</span>
                                </div>
                                <div className="mt-2 flex items-center text-slate-300 font-medium text-sm">
                                    <Coins size={14} className="mr-1 text-yellow-500" />
                                    {user ? (
                                        <span className="text-white">{task.reward} BDT</span>
                                    ) : (
                                        <span className="text-slate-500 flex items-center"><Lock size={12} className="mr-1"/> --</span>
                                    )}
                                </div>
                            </div>

                            <button 
                                onClick={() => startTask(task)}
                                disabled={isLockedDueToLimit}
                                className={`ml-3 px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm transition-all min-w-[80px] flex justify-center items-center ${
                                    isLockedDueToLimit 
                                        ? 'bg-slate-700 text-slate-400 border border-slate-600 cursor-not-allowed'
                                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/40 active:scale-95'
                                }`}
                            >
                                {isLockedDueToLimit ? <Lock size={14} /> : (user ? 'Start' : <Lock size={14} />)}
                            </button>
                        </div>
                    );
                })}
            </>
        )}
        
        {/* Loader Trigger / Infinite Scroll Bottom */}
        {!loadingTasks && visibleTasks.length < activeTaskList.length && (
             <div ref={loaderRef} className="py-4">
                {loadingMore ? (
                    <div className="space-y-4 animate-fade-in">
                        <TaskSkeleton />
                        <TaskSkeleton />
                    </div>
                ) : (
                    <div className="text-center text-slate-600 text-xs py-2 opacity-50">Scroll for more</div>
                )}
             </div>
        )}

        {/* Finished / Upgrade State (Show when daily limit reached) */}
        {isDailyLimitReached && (
            <div className="fixed bottom-20 left-4 right-4 z-30 animate-fade-in-up">
                <div className="p-4 bg-gradient-to-r from-indigo-900/90 to-slate-900/90 backdrop-blur-md rounded-2xl border border-indigo-500/50 shadow-2xl flex items-center justify-between">
                    <div>
                        <h3 className="font-bold text-white text-sm">Daily Limit Reached</h3>
                        <p className="text-xs text-slate-300">Upgrade VIP to unlock more tasks.</p>
                    </div>
                    {user && user.vipLevel < 4 && (
                        <button 
                            onClick={() => navigate('/vip')}
                            className="px-4 py-2 bg-yellow-500 text-slate-900 font-bold rounded-lg text-xs shadow-lg hover:scale-105 transition-transform flex items-center"
                        >
                            <Crown size={14} className="mr-1" /> Upgrade
                        </button>
                    )}
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default Work;
