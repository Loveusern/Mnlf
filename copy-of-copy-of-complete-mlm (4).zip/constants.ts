
import { VipTier, Task, TeamActivity, ReferralMember } from './types';

// Helper for dynamic dates
const NOW = Date.now();
const HOUR = 3600 * 1000;
const DAY = 24 * HOUR;

export const AVATAR_LIST = [
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Felix",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Aneka",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Bob",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Cale",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Daisy",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Easton",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Ginger",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Harley",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Jack",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Katie"
];

// Rewards for Day 1 to Day 7
export const DAILY_LOGIN_REWARDS = [10, 10, 20, 20, 30, 50, 100];

// 500/0/10/0/50/0/1000/100/0/
export const LOTTERY_SEGMENTS = [
    { value: 500, label: '500', color: '#ef4444' }, // Red
    { value: 0, label: '0', color: '#334155' },   // Slate
    { value: 10, label: '10', color: '#f59e0b' },   // Amber
    { value: 0, label: '0', color: '#334155' },   // Slate
    { value: 50, label: '50', color: '#3b82f6' },   // Blue
    { value: 0, label: '0', color: '#334155' },   // Slate
    { value: 1000, label: '1K', color: '#8b5cf6' },  // Purple
    { value: 100, label: '100', color: '#10b981' },  // Green
    { value: 0, label: '0', color: '#334155' },   // Slate
];

export const VIP_TIERS: VipTier[] = [
  { 
    level: 0, 
    name: 'Intern', 
    price: 0, 
    dailyIncome: 50, 
    dailyTasks: 5, 
    taskRate: 10.0, 
    validityDays: 3, 
    color: 'bg-gradient-to-br from-slate-700 to-slate-800' 
  },
  { 
    level: 1, 
    name: 'Staff', 
    price: 1500, 
    dailyIncome: 60, 
    dailyTasks: 6, 
    taskRate: 10.0, 
    validityDays: 365, 
    color: 'bg-gradient-to-br from-orange-800 to-amber-900' 
  },
  { 
    level: 2, 
    name: 'Manager', 
    price: 5000, 
    dailyIncome: 200, 
    dailyTasks: 10, 
    taskRate: 20.0, 
    validityDays: 365, 
    color: 'bg-gradient-to-br from-slate-500 to-slate-700' 
  },
  { 
    level: 3, 
    name: 'Director', 
    price: 15000, 
    dailyIncome: 600, 
    dailyTasks: 20, 
    taskRate: 30.0, 
    validityDays: 365, 
    color: 'bg-gradient-to-br from-yellow-700 to-yellow-900' 
  },
  { 
    level: 4, 
    name: 'CEO', 
    price: 50000, 
    dailyIncome: 2000, 
    dailyTasks: 20, 
    taskRate: 100.0, 
    validityDays: 365, 
    color: 'bg-gradient-to-br from-purple-800 to-indigo-900' 
  },
  { 
    level: 5, 
    name: 'Chairman', 
    price: 150000, 
    dailyIncome: 6000, 
    dailyTasks: 30, 
    taskRate: 200.0, 
    validityDays: 365, 
    color: 'bg-gradient-to-br from-red-800 to-rose-900' 
  }
];

export const MOCK_TASKS: Task[] = [
  { 
    id: '1', 
    title: 'Wikipedia Visit', 
    description: '30s', 
    platform: 'WIKIPEDIA',
    durationSeconds: 30, 
    reward: 10, 
    url: 'https://wikipedia.org',
    tag: 'Staff'
  },
  { 
    id: '2', 
    title: 'Watch Video', 
    description: '45s', 
    platform: 'YOUTUBE',
    durationSeconds: 45, 
    reward: 10, 
    url: 'https://youtube.com',
    tag: 'Staff'
  },
  { 
    id: '3', 
    title: 'Like Page', 
    description: '15s', 
    platform: 'FACEBOOK',
    durationSeconds: 15, 
    reward: 10, 
    url: 'https://facebook.com',
    tag: 'Staff'
  },
  { 
    id: '4', 
    title: 'Watch Ad', 
    description: '30s', 
    platform: 'GENERIC',
    durationSeconds: 30, 
    reward: 10, 
    url: 'https://google.com',
    tag: 'Ad'
  }
];

export const SLIDER_IMAGES = [
  "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=2832&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=2565&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2670&auto=format&fit=crop"
];

export const TICKER_MESSAGES = [
  "User 017****829 just earned 500৳!",
  "User 019****112 upgraded to VIP 3!",
  "New payment gateway added for faster withdrawals.",
  "User 018****990 withdrew 2000৳ successfully.",
  "Referral bonus increased for this week only!"
];

export const EARNING_NOTIFICATIONS = [
  { user: "****9431", amount: "10,000", label: "Task Income", img: "https://api.dicebear.com/7.x/adventurer/svg?seed=Felix" },
  { user: "****2245", amount: "1,500", label: "Task Income", img: "https://api.dicebear.com/7.x/adventurer/svg?seed=Aneka" },
  { user: "****1190", amount: "6,000", label: "Task Income", img: "https://api.dicebear.com/7.x/adventurer/svg?seed=Bob" },
  { user: "****8125", amount: "2,000", label: "Task Income", img: "https://api.dicebear.com/7.x/adventurer/svg?seed=Daisy" },
  { user: "****3301", amount: "5,000", label: "Task Income", img: "https://api.dicebear.com/7.x/adventurer/svg?seed=Jack" },
];

export const MOCK_TEAM_MEMBERS: ReferralMember[] = [
    { id: '101', phoneNumber: '017****889', username: 'user_889', level: 1, joinDate: '2023-10-15T10:00:00Z', vipLevel: 2, totalDeposited: 5000, totalWithdrawn: 1000, tasksCompletedToday: 4, tasksFailedToday: 0, commissionEarned: 150, memberTodayEarnings: 80 },
    { id: '102', phoneNumber: '018****221', username: 'dragon_fire', level: 1, joinDate: '2023-11-01T14:30:00Z', vipLevel: 1, totalDeposited: 1000, totalWithdrawn: 0, tasksCompletedToday: 2, tasksFailedToday: 0, commissionEarned: 25, memberTodayEarnings: 20 },
    { id: '103', phoneNumber: '019****555', username: 'sky_walker', level: 2, joinDate: '2023-11-05T09:15:00Z', vipLevel: 0, totalDeposited: 0, totalWithdrawn: 0, tasksCompletedToday: 0, tasksFailedToday: 0, commissionEarned: 0, memberTodayEarnings: 0 },
    { id: '104', phoneNumber: '016****777', username: 'taka_maker', level: 2, joinDate: '2023-11-10T11:20:00Z', vipLevel: 3, totalDeposited: 8000, totalWithdrawn: 2000, tasksCompletedToday: 6, tasksFailedToday: 0, commissionEarned: 450, memberTodayEarnings: 180 },
    { id: '105', phoneNumber: '015****333', username: 'newbie_01', level: 3, joinDate: '2023-11-20T16:45:00Z', vipLevel: 1, totalDeposited: 1000, totalWithdrawn: 0, tasksCompletedToday: 1, tasksFailedToday: 0, commissionEarned: 10, memberTodayEarnings: 10 },
    { id: '106', phoneNumber: '013****999', username: 'pro_earner', level: 1, joinDate: '2024-01-10T08:00:00Z', vipLevel: 4, totalDeposited: 20000, totalWithdrawn: 5000, tasksCompletedToday: 10, tasksFailedToday: 0, commissionEarned: 1200, memberTodayEarnings: 1000 },
];

export const MOCK_TEAM_ACTIVITIES: TeamActivity[] = [
    { id: 'a1', memberId: '101', memberPhone: '017****889', memberLevel: 1, type: 'VIP_UPGRADE', amount: 3000, commission: 300, date: new Date(NOW - 2 * HOUR).toISOString() }, 
    { id: 'a2', memberId: '101', memberPhone: '017****889', memberLevel: 1, type: 'TASK_COMMISSION', amount: 40, commission: 4, date: new Date(NOW - 5 * HOUR).toISOString() },
    { id: 'a3', memberId: '102', memberPhone: '018****221', memberLevel: 1, type: 'JOIN', amount: 0, commission: 0, date: new Date(NOW - 2 * DAY).toISOString() },
    { id: 'a4', memberId: '104', memberPhone: '016****777', memberLevel: 2, type: 'DEPOSIT', amount: 5000, commission: 150, date: new Date(NOW - 5 * DAY).toISOString() }, 
    { id: 'a5', memberId: '106', memberPhone: '013****999', memberLevel: 1, type: 'WITHDRAW', amount: 2000, commission: 0, date: new Date(NOW - 12 * DAY).toISOString() }, 
    { id: 'a6', memberId: '101', memberPhone: '017****889', memberLevel: 1, type: 'TASK_COMMISSION', amount: 10, commission: 1, date: new Date(NOW - 25 * DAY).toISOString() }, 
    { id: 'a7', memberId: '105', memberPhone: '015****333', memberLevel: 3, type: 'JOIN', amount: 0, commission: 0, date: new Date(NOW - 40 * DAY).toISOString() },
];
