
import React from 'react';
import { Loader2 } from 'lucide-react';

const PageLoadingOverlay: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-slate-950/60 backdrop-blur-xl animate-fade-in transition-all duration-500">
       <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-700/50 shadow-2xl flex flex-col items-center backdrop-blur-md transform scale-100">
          <div className="relative mb-3">
            <div className="absolute inset-0 bg-blue-500 blur-xl opacity-20 rounded-full animate-pulse"></div>
            <Loader2 className="w-10 h-10 text-blue-500 animate-spin relative z-10" />
          </div>
          <p className="text-[10px] text-slate-300 font-bold uppercase tracking-[0.2em] animate-pulse">Syncing Data</p>
       </div>
    </div>
  );
};

export default PageLoadingOverlay;
