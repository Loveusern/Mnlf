
import React from 'react';
import { Gem } from 'lucide-react';

const SplashScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white animate-fade-in">
      
      {/* App Logo Animation */}
      <div className="relative mb-6 animate-bounce-slow">
        <div className="w-32 h-32 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2.5rem] border-4 border-slate-700 flex items-center justify-center shadow-[0_0_40px_rgba(59,130,246,0.5)]">
            <Gem size={64} className="text-white drop-shadow-xl" />
        </div>
        {/* Glow effect behind */}
        <div className="absolute inset-0 bg-blue-500 blur-3xl opacity-20 -z-10 rounded-full"></div>
      </div>

      {/* Brand Name */}
      <h1 className="text-4xl font-extrabold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-2 drop-shadow-sm">
        MNLife
      </h1>

      {/* Slogan */}
      <p className="text-slate-400 text-sm font-medium tracking-wide uppercase opacity-80 animate-pulse">
        Empower Your Future
      </p>

      {/* Loading Indicator */}
      <div className="absolute bottom-10 w-48 h-1 bg-slate-800 rounded-full overflow-hidden">
        <div className="h-full bg-blue-500 animate-loading-bar rounded-full"></div>
      </div>

      {/* Styles for custom animations */}
      <style>{`
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        .animate-bounce-slow {
          animation: bounce-slow 3s infinite ease-in-out;
        }
        @keyframes loading-bar {
          0% { width: 0%; transform: translateX(-100%); }
          50% { width: 50%; }
          100% { width: 100%; transform: translateX(100%); }
        }
        .animate-loading-bar {
          animation: loading-bar 2s infinite linear;
        }
      `}</style>
    </div>
  );
};

export default SplashScreen;
