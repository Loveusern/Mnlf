
import React, { useState, useEffect } from 'react';
import { X, Users, Gift, Percent, Crown, Briefcase, Loader2 } from 'lucide-react';
import { api } from '../services/api';
import { DEFAULT_SETTINGS, SystemSettings } from '../types';

interface CommissionInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CommissionInfoModal: React.FC<CommissionInfoModalProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
        const fetchSettings = async () => {
            try {
                const s = await api.getSettings();
                setSettings(s);
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };
        fetchSettings();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in p-4">
      <div className="bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-700 flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-gradient-to-r from-slate-900 to-slate-800">
          <div className="flex items-center space-x-2">
             <Users className="text-blue-500" size={24} />
             <h3 className="font-bold text-lg text-white">Commission Plan</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-700 rounded-full transition-colors">
            <X size={20} className="text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          
          {loading ? (
              <div className="flex justify-center py-10">
                  <Loader2 className="animate-spin text-blue-500" />
              </div>
          ) : (
            <>
              {/* Section 1: Referral Commission (VIP) */}
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-yellow-400 uppercase tracking-wider flex items-center">
                    <Crown size={16} className="mr-2" />
                    Referral Commission (VIP)
                </h4>
                <p className="text-xs text-slate-400 -mt-2 mb-2">Earned when your team member buys a VIP plan.</p>
                
                <div className="grid grid-cols-3 gap-2">
                    <div className="bg-slate-800 p-3 rounded-xl border border-yellow-500/20 text-center">
                        <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Level 1</div>
                        <div className="text-xl font-bold text-white">{settings.commissions.vip[0] || 0}%</div>
                    </div>
                    <div className="bg-slate-800 p-3 rounded-xl border border-yellow-500/20 text-center">
                        <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Level 2</div>
                        <div className="text-xl font-bold text-white">{settings.commissions.vip[1] || 0}%</div>
                    </div>
                    <div className="bg-slate-800 p-3 rounded-xl border border-yellow-500/20 text-center">
                        <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Level 3</div>
                        <div className="text-xl font-bold text-white">{settings.commissions.vip[2] || 0}%</div>
                    </div>
                </div>
              </div>

              <div className="w-full h-[1px] bg-slate-800"></div>

              {/* Section 2: Task Earning Commission */}
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-blue-400 uppercase tracking-wider flex items-center">
                    <Briefcase size={16} className="mr-2" />
                    Task Earning Commission
                </h4>
                <p className="text-xs text-slate-400 -mt-2 mb-2">Earned daily from your team's task income.</p>
                
                <div className="grid grid-cols-3 gap-2">
                    <div className="bg-slate-800 p-3 rounded-xl border border-blue-500/20 text-center">
                        <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Level 1</div>
                        <div className="text-xl font-bold text-white">{settings.commissions.task[0] || 0}%</div>
                    </div>
                    <div className="bg-slate-800 p-3 rounded-xl border border-blue-500/20 text-center">
                        <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Level 2</div>
                        <div className="text-xl font-bold text-white">{settings.commissions.task[1] || 0}%</div>
                    </div>
                    <div className="bg-slate-800 p-3 rounded-xl border border-blue-500/20 text-center">
                        <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Level 3</div>
                        <div className="text-xl font-bold text-white">{settings.commissions.task[2] || 0}%</div>
                    </div>
                </div>
                
                {/* Important Note about Free Users */}
                <div className="bg-red-900/10 p-3 rounded-lg border border-red-500/20 flex items-start space-x-2">
                    <div className="mt-0.5"><Percent size={14} className="text-red-400"/></div>
                    <p className="text-[10px] text-red-200 leading-relaxed">
                        <span className="font-bold text-red-400">Important:</span> You do not earn commission from <span className="font-bold">Free (Intern)</span> users. Commission is only generated when your team members are VIPs.
                    </p>
                </div>
              </div>

              <div className="w-full h-[1px] bg-slate-800"></div>

              {/* Section 3: Spin Rewards */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-pink-400 uppercase tracking-wider flex items-center">
                    <Gift size={16} className="mr-2" />
                    Lucky Spin Bonus
                </h4>
                
                <div className="bg-gradient-to-br from-pink-900/20 to-purple-900/20 p-4 rounded-xl border border-pink-500/30 flex items-start space-x-4">
                    <div className="p-3 bg-pink-600/20 rounded-full text-pink-500">
                        <Gift size={24} />
                    </div>
                    <div>
                        <h5 className="font-bold text-white text-sm">Unlock Free Spins</h5>
                        <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                            You get <span className="text-green-400 font-bold">+1 Free Spin</span> only when your invited friend purchases a VIP Membership.
                        </p>
                    </div>
                </div>
              </div>
            </>
          )}

        </div>
        
        <div className="p-4 border-t border-slate-800 bg-slate-900">
            <button 
                onClick={onClose}
                className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-colors border border-slate-700"
            >
                Close
            </button>
        </div>
      </div>
    </div>
  );
};

export default CommissionInfoModal;
