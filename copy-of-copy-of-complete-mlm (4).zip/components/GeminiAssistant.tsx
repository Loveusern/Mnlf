
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { MessageCircle, X, Send, Loader2, Headset } from 'lucide-react';

const GeminiAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([
    { role: 'model', text: 'Welcome to MNLife Service! How can we help you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setIsLoading(true);

    try {
      // Safe access to API Key
      const apiKey = (typeof process !== 'undefined' && process.env) ? process.env.API_KEY : undefined;
      
      if (!apiKey) {
          throw new Error("API Key missing");
      }

      const ai = new GoogleGenAI({ apiKey: apiKey });
      const model = 'gemini-3-flash-preview';
      
      const systemInstruction = `You are a helpful customer support agent for "MNLife", an earning app. 
      Currency is BDT (Taka).
      Features: 
      - Daily tasks (website visits) which reset at 12:00 AM (Midnight).
      - VIP levels (Bronze to Platinum) with higher daily income.
      - 3-Level Referral Commission (Level 1: 10%, Level 2: 5%, Level 3: 2%).
      - Withdrawals via bKash and Nagad with 15% VAT deduction.
      - Withdrawal PIN is required.
      Encourage users to upgrade to VIP for higher earnings. Keep answers short, friendly and professional.`;

      const chat = ai.chats.create({
        model: model,
        config: { systemInstruction }
      });

      const result = await chat.sendMessage({ message: userMessage });
      const responseText = result.text;

      setMessages(prev => [...prev, { role: 'model', text: responseText || "I couldn't understand that, sorry." }]);
    } catch (error) {
      console.error("Gemini Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, connection issue. Please try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-20 right-4 w-14 h-14 bg-gradient-to-tr from-blue-600 to-cyan-600 rounded-full shadow-xl flex items-center justify-center text-white z-40 hover:scale-110 transition-transform"
        >
          <Headset size={28} />
        </button>
      )}

      {isOpen && (
        <div className="fixed bottom-20 right-4 w-80 sm:w-96 bg-slate-900 rounded-2xl shadow-2xl border border-slate-700 z-50 flex flex-col overflow-hidden animate-fade-in-up" style={{ maxHeight: '60vh' }}>
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-cyan-600 p-4 flex justify-between items-center text-white">
            <div className="flex items-center space-x-2">
              <Headset size={20} />
              <h3 className="font-semibold">MNLife Service</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 rounded-full p-1">
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-800 h-80">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl p-3 text-sm ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-br-none' 
                    : 'bg-slate-700 text-slate-200 rounded-bl-none shadow-sm'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-700 rounded-2xl p-3 rounded-bl-none shadow-sm flex items-center space-x-2 text-slate-300">
                  <Loader2 size={16} className="animate-spin text-blue-500" />
                  <span className="text-xs">Typing...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 bg-slate-900 border-t border-slate-700 flex items-center space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type your issue..."
              className="flex-1 bg-slate-800 border border-slate-700 rounded-full px-4 py-2 text-sm text-white focus:border-blue-500 outline-none placeholder-slate-500"
            />
            <button 
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default GeminiAssistant;
