
import React, { useState, useEffect } from 'react';
import { X, Phone, Lock, Gift, Shield, Loader2, CheckSquare, Square, Eye, EyeOff, LogIn, UserPlus } from 'lucide-react';
import Captcha from './Captcha';
import { api } from '../services/api';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: User) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [isCaptchaValid, setIsCaptchaValid] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Feature states
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setError('');
      setInviteCode('');
      setVerifyCode('');
      setIsCaptchaValid(false);
      setIsLogin(true);
      setShowPassword(false);
      
      const savedCreds = localStorage.getItem('mnlife_remember_creds');
      if (savedCreds) {
          try {
              const { p, pwd } = JSON.parse(savedCreds);
              if (p && pwd) {
                  setPhone(p);
                  setPassword(pwd);
                  setRememberMe(true);
              }
          } catch (e) {
              localStorage.removeItem('mnlife_remember_creds');
          }
      } else {
          setPhone('');
          setPassword('');
          setRememberMe(false);
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (phone.length < 11) {
        setError('Invalid phone number format');
        return;
    }
    if (password.length < 6) {
        setError('Password must be at least 6 characters');
        return;
    }

    if (!isLogin) {
        if (!inviteCode.trim()) {
            setError('Referral Code is required');
            return;
        }
        if (!isCaptchaValid) {
            setError('Please enter the correct captcha code');
            return;
        }
    }

    setIsLoading(true);

    try {
      let response;
      if (isLogin) {
        response = await api.login(phone, password);
        
        if (rememberMe) {
            localStorage.setItem('mnlife_remember_creds', JSON.stringify({ p: phone, pwd: password }));
        } else {
            localStorage.removeItem('mnlife_remember_creds');
        }

      } else {
        response = await api.register(phone, password, inviteCode);
      }
      onLogin(response.user);
      onClose();
    } catch (err: any) {
      console.error(err);
      
      if (err.message === 'MISSING_FUNCTIONS' || err.message.includes('Security update required')) {
          setError('System update required. Please contact Admin.');
      } else {
          setError(err.message || 'Authentication failed. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
      try {
          const settings = await api.getSettings();
          // Priority: Telegram for Password Reset
          if (settings.externalLinks?.telegram) {
              window.open(settings.externalLinks.telegram, '_blank');
          } else if (settings.externalLinks?.whatsapp) {
              window.open(settings.externalLinks.whatsapp, '_blank');
          } else {
              setError("Support link not configured. Contact Admin.");
          }
      } catch (e) {
          setError("Unable to connect to support. Try again later.");
      }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 backdrop-blur-sm p-4 animate-fade-in">
      
      {/* Modal Container - Centered */}
      <div className="bg-slate-900 w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden animate-zoom-in relative border border-slate-700/50 backdrop-blur-md">
        
        {/* Background Effects */}
        <div className="absolute top-[-50px] left-[-50px] w-32 h-32 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-[-50px] right-[-50px] w-32 h-32 bg-purple-600/20 rounded-full blur-3xl pointer-events-none"></div>

        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 p-2 bg-slate-800/50 hover:bg-slate-700 rounded-full text-slate-400 hover:text-white transition-colors z-20 border border-slate-700/50"
        >
          <X size={20} />
        </button>

        <div className="p-8 pb-6 relative z-10">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-1 tracking-wide">MNLife</h1>
            <p className="text-slate-400 text-sm">Welcome Back</p>
          </div>

          <div className="flex bg-slate-950/50 p-1 rounded-xl mb-6 border border-slate-800/50">
            <button
              className={`flex-1 py-2.5 text-center font-bold text-sm rounded-lg transition-all duration-300 flex items-center justify-center space-x-2 ${isLogin ? 'bg-slate-800 text-white shadow-lg shadow-slate-900/50 border border-slate-700' : 'text-slate-500 hover:text-slate-300'}`}
              onClick={() => setIsLogin(true)}
            >
              <LogIn size={16} className={isLogin ? "text-blue-400" : ""} />
              <span>Login</span>
            </button>
            <button
              className={`flex-1 py-2.5 text-center font-bold text-sm rounded-lg transition-all duration-300 flex items-center justify-center space-x-2 ${!isLogin ? 'bg-slate-800 text-white shadow-lg shadow-slate-900/50 border border-slate-700' : 'text-slate-500 hover:text-slate-300'}`}
              onClick={() => setIsLogin(false)}
            >
              <UserPlus size={16} className={!isLogin ? "text-purple-400" : ""} />
              <span>Register</span>
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-500/10 text-red-400 rounded-xl text-xs border border-red-500/20 flex items-start backdrop-blur-sm">
              <Shield size={14} className="mr-2 mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5 ml-1">Phone Number</label>
              <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone size={18} className="text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-slate-950/50 border border-slate-800 rounded-xl focus:ring-1 focus:ring-blue-500/50 focus:border-blue-500/50 outline-none text-white placeholder-slate-600 transition-all text-sm"
                    placeholder="01XXXXXXXXX"
                    required
                  />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5 ml-1">Password</label>
              <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock size={18} className="text-slate-500 group-focus-within:text-purple-400 transition-colors" />
                  </div>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-3 bg-slate-950/50 border border-slate-800 rounded-xl focus:ring-1 focus:ring-purple-500/50 focus:border-purple-500/50 outline-none text-white placeholder-slate-600 transition-all text-sm"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
              </div>
            </div>

            {isLogin && (
                <div className="flex justify-between items-center text-xs mt-2 px-1">
                    <button 
                        type="button" 
                        onClick={() => setRememberMe(!rememberMe)} 
                        className="flex items-center text-slate-400 hover:text-blue-400 transition-colors"
                    >
                        {rememberMe ? (
                            <CheckSquare size={16} className="mr-1.5 text-blue-500" />
                        ) : (
                            <Square size={16} className="mr-1.5" />
                        )}
                        Remember Me
                    </button>
                    <button 
                        type="button" 
                        onClick={handleForgotPassword}
                        className="text-slate-400 hover:text-purple-400 font-bold transition-colors"
                    >
                        Forgot Password?
                    </button>
                </div>
            )}

            {!isLogin && (
              <div className="space-y-4 animate-fade-in">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5 ml-1">Referral Code <span className="text-red-500">*</span></label>
                  <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Gift size={18} className="text-slate-500 group-focus-within:text-green-400 transition-colors" />
                      </div>
                      <input
                        type="text"
                        value={inviteCode}
                        onChange={(e) => setInviteCode(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-950/50 border border-slate-800 rounded-xl focus:ring-1 focus:ring-green-500/50 focus:border-green-500/50 outline-none text-white placeholder-slate-600 transition-all text-sm"
                        placeholder="Required"
                        required
                      />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5 ml-1">Captcha</label>
                  <div className="flex gap-2">
                      <div className="relative flex-1 group">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                             <Shield size={18} className="text-slate-500 group-focus-within:text-yellow-400 transition-colors" />
                          </div>
                          <input
                            type="text"
                            value={verifyCode}
                            onChange={(e) => setVerifyCode(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 bg-slate-950/50 border border-slate-800 rounded-xl focus:ring-1 focus:ring-yellow-500/50 focus:border-yellow-500/50 outline-none text-white placeholder-slate-600 transition-all text-sm"
                            placeholder="Code"
                          />
                      </div>
                      <div className="w-28 rounded-xl overflow-hidden border border-slate-700 bg-slate-800 opacity-90">
                          <Captcha onValidate={setIsCaptchaValid} userInput={verifyCode} />
                      </div>
                  </div>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3.5 rounded-xl font-bold hover:from-blue-500 hover:to-purple-500 transition-all shadow-lg shadow-blue-900/30 mt-6 flex items-center justify-center disabled:opacity-70 disabled:cursor-not-allowed active:scale-95 border border-white/10"
            >
              {isLoading ? <Loader2 size={20} className="animate-spin" /> : (isLogin ? 'Login Now' : 'Create Account')}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
