
import React from 'react';
import { Home, Briefcase, Crown, Users, UserCircle } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { User } from '../types';

interface BottomNavProps {
    user: User | null;
    onRequireAuth: () => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ user, onRequireAuth }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Briefcase, label: 'Work', path: '/work' },
    { icon: Crown, label: 'VIP', path: '/vip' },
    { icon: Users, label: 'Refer', path: '/team', requiresAuth: true },
    { icon: UserCircle, label: 'Profile', path: '/profile', requiresAuth: true },
  ];

  const handleNavClick = (path: string, requiresAuth?: boolean) => {
      if (requiresAuth && !user) {
          onRequireAuth();
          return;
      }
      navigate(path);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 shadow-2xl z-40 pb-safe">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        {navItems.map((item) => (
          <button
            key={item.label}
            onClick={() => handleNavClick(item.path, item.requiresAuth)}
            className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${
              isActive(item.path) ? 'text-blue-500' : 'text-slate-500 hover:text-slate-400'
            }`}
          >
            <item.icon size={22} strokeWidth={isActive(item.path) ? 2.5 : 2} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default BottomNav;
