
import React, { useState, useEffect } from 'react';

interface CaptchaProps {
  onValidate: (isValid: boolean) => void;
  userInput?: string;
}

const Captcha: React.FC<CaptchaProps> = ({ onValidate, userInput }) => {
  const [code, setCode] = useState('');

  const generateCaptcha = () => {
    const random = Math.floor(1000 + Math.random() * 9000).toString();
    setCode(random);
    // If input is controlled (userInput is passed), validation starts as false until match
    // If input is uncontrolled (legacy), we default to true to not break other views
    if (userInput !== undefined) {
        onValidate(false);
    } else {
        onValidate(true);
    }
  };

  useEffect(() => {
    generateCaptcha();
  }, []);

  // Validate whenever input or code changes
  useEffect(() => {
    if (userInput !== undefined && code) {
        onValidate(userInput === code);
    }
  }, [userInput, code, onValidate]);

  return (
    <div 
        className="bg-slate-800/80 w-full h-full flex items-center justify-center relative cursor-pointer select-none backdrop-blur-sm"
        onClick={generateCaptcha}
        title="Tap to refresh code"
    >
        <span className="font-mono text-xl font-bold tracking-widest text-slate-300 line-through decoration-slate-500/50 drop-shadow-md">
            {code}
        </span>
    </div>
  );
};

export default Captcha;
