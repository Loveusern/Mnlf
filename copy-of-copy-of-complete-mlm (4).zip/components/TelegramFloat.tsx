
import React, { useEffect, useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { api } from '../services/api';
import { DEFAULT_SETTINGS } from '../types';

const TelegramFloat: React.FC = () => {
  const [link, setLink] = useState(DEFAULT_SETTINGS.externalLinks.telegram);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const s = await api.getSettings();
        // Priority: Telegram (original behavior), then WhatsApp
        if (s.externalLinks?.telegram) {
            setLink(s.externalLinks.telegram);
        } else if (s.externalLinks?.whatsapp) {
            setLink(s.externalLinks.whatsapp);
        }
      } catch (e) {
        console.error(e);
      }
    };
    fetchSettings();
  }, []);

  const handleClick = () => {
    window.open(link, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-20 right-4 w-14 h-14 bg-gradient-to-tr from-green-500 to-emerald-600 rounded-full shadow-xl flex items-center justify-center text-white z-40 hover:scale-110 transition-transform animate-bounce-slow border-2 border-white/20"
      title="Contact Support"
    >
      <MessageCircle size={28} />
      <span className="absolute -top-1 -right-1 flex h-3 w-3">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500 border border-white"></span>
      </span>
    </button>
  );
};

export default TelegramFloat;
