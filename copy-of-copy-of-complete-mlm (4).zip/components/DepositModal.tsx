
import React, { useState, useEffect } from 'react';
import { X, Copy, CheckCircle2, ArrowRight, ShieldCheck, AlertCircle, Wallet } from 'lucide-react';
import { useToast } from './ToastContext';
import { api } from '../services/api';
import { DEFAULT_SETTINGS } from '../types';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: (amount: number, method: string, trxId: string, sender: string) => void;
  initialAmount?: number;
}

const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose, onDeposit, initialAmount }) => {
  const { showToast } = useToast();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'bKash' | 'Nagad' | null>(null);
  const [sender, setSender] = useState('');
  const [trxId, setTrxId] = useState('');
  
  const [targetNumber, setTargetNumber] = useState('');
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
        // Reset or set initial amount
        setAmount(initialAmount ? Math.max(settings.depositLimits.min, initialAmount).toString() : '');
        setMethod(null);
        setSender('');
        setTrxId('');
        
        // Fetch Admin Settings for numbers
        const loadSettings = async () => {
            setLoading(true);
            try {
                const s = await api.getSettings();
                setSettings(s);
            } catch (e) {
                console.error("Failed to load settings", e);
            } finally {
                setLoading(false);
            }
        };
        loadSettings();
    }
  }, [isOpen, initialAmount]);

  const handleMethodSelect = (m: 'bKash' | 'Nagad') => {
      setMethod(m);
      // Pick Random Number
      const numbers = m === 'bKash' ? settings.paymentNumbers.bKash : settings.paymentNumbers.nagad;
      if (numbers && numbers.length > 0) {
          const randomNum = numbers[Math.floor(Math.random() * numbers.length)];
          setTargetNumber(randomNum);
      } else {
          setTargetNumber("No Number Available");
      }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!method) return showToast("Select a payment method", 'error');
    
    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount < settings.depositLimits.min) return showToast(`Minimum deposit is ${settings.depositLimits.min} BDT`, 'error');
    if (depositAmount > settings.depositLimits.max) return showToast(`Maximum deposit is ${settings.depositLimits.max} BDT`, 'error');
    
    if (sender.length < 11) return showToast("Invalid Sender Number", 'error');
    if (trxId.length < 4) return showToast("Invalid TrxID", 'error');

    onDeposit(depositAmount, method, trxId, sender);
    onClose();
    showToast("Deposit Request Submitted!", 'success');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast("Number copied to clipboard!", 'success');
  };

  // Dynamic Theme Colors based on Method
  const bgGradient = method === 'bKash' 
    ? 'from-pink-900/40 to-slate-900' 
    : method === 'Nagad' 
        ? 'from-orange-900/40 to-slate-900' 
        : 'from-slate-800 to-slate-900';

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/90 backdrop-blur-md animate-fade-in p-0 sm:p-4">
        <div className={`bg-gradient-to-b ${bgGradient} w-full max-w-sm sm:max-w-md rounded-t-3xl sm:rounded-3xl border-t sm:border border-slate-700/50 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-slide-up`}>
            
            {/* Header */}
            <div className="px-5 pt-5 pb-2 flex justify-between items-center bg-transparent">
                <div>
                    <h3 className="text-xl font-bold text-white tracking-tight">Deposit Funds</h3>
                    <p className="text-xs text-slate-400">Add balance to your wallet</p>
                </div>
                <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors backdrop-blur-sm bg-slate-800/50 border border-slate-700">
                    <X size={18} className="text-slate-300" />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 pb-5 space-y-5">
                
                {/* 1. Method Selection */}
                <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">1. Select Method</label>
                    <div className="grid grid-cols-2 gap-3">
                        <button
                            type="button"
                            onClick={() => handleMethodSelect('bKash')}
                            className={`relative overflow-hidden p-3 rounded-xl border transition-all group flex items-center justify-center space-x-2 ${
                                method === 'bKash' 
                                ? 'bg-pink-600/20 border-pink-500 shadow-lg shadow-pink-900/20' 
                                : 'bg-slate-800 border-slate-700 hover:border-pink-500/30'
                            }`}
                        >
                            {settings.paymentLogos?.bKash ? (
                                <img src={settings.paymentLogos.bKash} alt="bKash" className="h-6 object-contain bg-white rounded p-0.5" />
                            ) : (
                                <span className={`font-bold text-sm ${method === 'bKash' ? 'text-pink-400' : 'text-slate-400'}`}>bKash</span>
                            )}
                            {method === 'bKash' && <div className="absolute top-1 right-1 text-pink-500"><CheckCircle2 size={12} fill="currentColor" className="text-white"/></div>}
                        </button>

                        <button
                            type="button"
                            onClick={() => handleMethodSelect('Nagad')}
                            className={`relative overflow-hidden p-3 rounded-xl border transition-all group flex items-center justify-center space-x-2 ${
                                method === 'Nagad' 
                                ? 'bg-orange-600/20 border-orange-500 shadow-lg shadow-orange-900/20' 
                                : 'bg-slate-800 border-slate-700 hover:border-orange-500/30'
                            }`}
                        >
                            {settings.paymentLogos?.nagad ? (
                                <img src={settings.paymentLogos.nagad} alt="Nagad" className="h-6 object-contain bg-white rounded p-0.5" />
                            ) : (
                                <span className={`font-bold text-sm ${method === 'Nagad' ? 'text-orange-400' : 'text-slate-400'}`}>Nagad</span>
                            )}
                            {method === 'Nagad' && <div className="absolute top-1 right-1 text-orange-500"><CheckCircle2 size={12} fill="currentColor" className="text-white"/></div>}
                        </button>
                    </div>
                </div>

                {/* 2. Copy Number (Conditional) */}
                {method && (
                    <div className="space-y-2 animate-fade-in">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">2. Send Money To</label>
                        <div className={`p-0.5 rounded-xl bg-gradient-to-r ${method === 'bKash' ? 'from-pink-500 to-rose-500' : 'from-orange-500 to-amber-500'}`}>
                            <div className="bg-slate-900 rounded-[10px] p-3 flex items-center justify-between">
                                <div>
                                    <p className={`text-[10px] font-bold mb-0.5 ${method === 'bKash' ? 'text-pink-400' : 'text-orange-400'}`}>
                                        {method} Personal Number
                                    </p>
                                    <p className="text-lg font-mono font-bold text-white tracking-widest">
                                        {loading ? '...' : targetNumber}
                                    </p>
                                </div>
                                <button 
                                    onClick={() => copyToClipboard(targetNumber)}
                                    className={`p-2 rounded-lg transition-all active:scale-95 shadow-lg ${
                                        method === 'bKash' ? 'bg-pink-600 hover:bg-pink-500 text-white' : 'bg-orange-600 hover:bg-orange-500 text-white'
                                    }`}
                                >
                                    <Copy size={16} />
                                </button>
                            </div>
                        </div>
                        <div className="flex items-start space-x-2 p-2 bg-blue-900/10 rounded-lg border border-blue-500/10">
                            <AlertCircle size={14} className="text-blue-400 mt-0.5 shrink-0" />
                            <p className="text-[10px] text-blue-200/80 leading-tight">
                                Go to {method} App, use <b>"Send Money"</b>. Copy <b>TrxID</b>.
                            </p>
                        </div>
                    </div>
                )}

                {/* 3. Form Input */}
                <div className={`space-y-3 transition-all duration-500 ${method ? 'opacity-100 translate-y-0' : 'opacity-50 translate-y-4 grayscale pointer-events-none'}`}>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">3. Verification</label>
                    <form id="deposit-form" onSubmit={handleSubmit} className="space-y-3">
                        
                        {/* Amount */}
                        <div className="bg-slate-800 px-3 py-2 rounded-xl border border-slate-700 focus-within:border-white/50 transition-colors">
                            <label className="block text-[10px] font-bold text-slate-400">Amount Sent</label>
                            <div className="flex items-center">
                                <span className="text-lg font-bold text-slate-500 mr-2">৳</span>
                                <input 
                                    type="number" 
                                    value={amount}
                                    onChange={(e) => setAmount(e.target.value)}
                                    className="w-full bg-transparent text-white text-lg font-bold outline-none placeholder-slate-600"
                                    placeholder="500"
                                    min={settings.depositLimits.min}
                                    required
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {/* Sender Number */}
                            <div className="bg-slate-800 px-3 py-2 rounded-xl border border-slate-700 focus-within:border-white/50 transition-colors">
                                <label className="block text-[10px] font-bold text-slate-400">Sender Number</label>
                                <input 
                                    type="tel" 
                                    value={sender}
                                    onChange={(e) => setSender(e.target.value)}
                                    className="w-full bg-transparent text-white font-mono font-medium text-sm outline-none placeholder-slate-600"
                                    placeholder="01XXXXXXXXX"
                                    required
                                />
                            </div>

                            {/* TrxID */}
                            <div className="bg-slate-800 px-3 py-2 rounded-xl border border-slate-700 focus-within:border-white/50 transition-colors">
                                <label className="block text-[10px] font-bold text-slate-400">TrxID</label>
                                <input 
                                    type="text" 
                                    value={trxId}
                                    onChange={(e) => setTrxId(e.target.value)}
                                    className="w-full bg-transparent text-white font-mono font-bold text-sm outline-none placeholder-slate-600 uppercase"
                                    placeholder="8J7H6G5F"
                                    required
                                />
                            </div>
                        </div>
                    </form>
                </div>

            </div>

            {/* Footer Action */}
            <div className="p-5 bg-slate-900 border-t border-slate-800">
                <button 
                    type="submit"
                    form="deposit-form"
                    disabled={!method}
                    className={`w-full py-3 rounded-xl font-bold text-base flex items-center justify-center space-x-2 transition-all shadow-lg ${
                        method 
                        ? (method === 'bKash' 
                            ? 'bg-pink-600 hover:bg-pink-500 text-white shadow-pink-900/30' 
                            : 'bg-orange-600 hover:bg-orange-500 text-white shadow-orange-900/30')
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                >
                    <ShieldCheck size={18} />
                    <span>Verify Deposit</span>
                </button>
            </div>

        </div>
    </div>
  );
};

export default DepositModal;
