
import { User, AuthResponse, Transaction, ReferralMember, Task, SystemSettings, DEFAULT_SETTINGS, AppNotification } from '../types';
import { VIP_TIERS, LOTTERY_SEGMENTS, SLIDER_IMAGES } from '../constants';
import { createClient } from '@supabase/supabase-js';

// ==========================================
// SUPABASE CONFIGURATION
// ==========================================
const supabaseUrl = 'https://jbdmtscedlpnwfbgqnqp.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpiZG10c2NlZGxwbndmYmdxbnFwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg4NjU0MzksImV4cCI6MjA4NDQ0MTQzOX0.fh9IFoYU6gD9VDnNKNi58wKd2PwgAgILttjHadS1GQE';

const supabase = createClient(supabaseUrl, supabaseKey);

const STORAGE_KEY_TOKEN = 'earnMate_auth_token';
const CACHE_KEY_USER = 'mnlife_user_data';
const CACHE_KEY_TASKS = 'mnlife_tasks_data';
const CACHE_KEY_SETTINGS = 'mnlife_settings_data';
const MASTER_REFERRAL_CODE = 'saifan01959675377'; 

// ==========================================
// HELPERS
// ==========================================
const handleSupabaseError = (error: any, context: string) => {
    if (!error) return;
    console.error(`Error in ${context}:`, error);
    
    if (error.message && (
        error.message.includes('does not exist') || 
        error.message.includes('Could not find the table') || 
        error.code === '42P01' ||
        error.code === '42883'
    )) {
        throw new Error("MISSING_TABLES");
    }
    
    throw new Error(error.message || "An unexpected error occurred");
};

const safeArray = (val: any) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    return Object.values(val); 
};

const getMyId = (): string => {
    const token = localStorage.getItem(STORAGE_KEY_TOKEN);
    if (!token) throw new Error("Not logged in");
    try {
        return atob(token).split(':')[0];
    } catch (e) {
        throw new Error("Invalid Token");
    }
};

const processUserOnLogin = async (user: User): Promise<User> => {
    const now = new Date();
    let lastActive = new Date(0);
    if (user.lastActiveDate && !isNaN(new Date(user.lastActiveDate).getTime())) {
        lastActive = new Date(user.lastActiveDate);
    }
    
    let isUpdated = false;
    const updates: Partial<User> = {};

    if (now.toDateString() !== lastActive.toDateString()) {
        user.yesterdayEarnings = user.todayEarnings || 0;
        user.todayEarnings = 0;
        user.tasksCompletedToday = 0;
        user.tasksFailedToday = 0;
        user.todayReferralBonus = 0;
        
        updates.yesterdayEarnings = user.yesterdayEarnings;
        updates.todayEarnings = 0;
        updates.tasksCompletedToday = 0;
        updates.tasksFailedToday = 0;
        updates.todayReferralBonus = 0;
        isUpdated = true;
    }
    
    if (!user.vipExpiryDate) {
        const days = (user.vipLevel || 0) === 0 ? 3 : 365;
        const d = new Date();
        d.setDate(d.getDate() + days);
        user.vipExpiryDate = d.toISOString();
        updates.vipExpiryDate = user.vipExpiryDate;
        isUpdated = true;
    }

    if (now.getTime() - lastActive.getTime() > 60000) { 
        user.lastActiveDate = now.toISOString();
        updates.lastActiveDate = user.lastActiveDate;
        isUpdated = true;
    }

    if (isUpdated && user.id) {
        // Fire and forget update to not block UI
        supabase.from('users').update(updates).eq('id', user.id).then();
    }
    
    user.notifications = safeArray(user.notifications);
    user.hiddenBroadcasts = safeArray(user.hiddenBroadcasts);
    user.earningHistory = safeArray(user.earningHistory);
    user.depositHistory = safeArray(user.depositHistory);
    user.withdrawHistory = safeArray(user.withdrawHistory);
    user.referrals = safeArray(user.referrals);
    user.savedPaymentMethods = safeArray(user.savedPaymentMethods);

    return user;
};

// ==========================================
// API EXPORT
// ==========================================

export const api = {
  
  // CACHE HELPERS
  saveToCache: (key: string, data: any) => {
      try {
          localStorage.setItem(key, JSON.stringify(data));
      } catch (e) { console.error("Cache save failed", e); }
  },

  getFromCache: <T>(key: string): T | null => {
      try {
          const item = localStorage.getItem(key);
          return item ? JSON.parse(item) : null;
      } catch (e) { return null; }
  },

  checkSystem: async () => {
      const { error } = await supabase.from('system_settings').select('id').limit(1);
      if (error) {
          handleSupabaseError(error, 'checkSystem');
      }
      return true;
  },

  // LOGIN - SECURED VIA RPC
  login: async (phoneNumber: string, password: string): Promise<AuthResponse> => {
    // Calling the secure function on the database
    const { data: user, error } = await supabase.rpc('login_user_secure', {
        p_phone: phoneNumber,
        p_password: password
    });
    
    if (error) {
        // Fallback for clearer error messages or if function doesn't exist yet
        if (error.message.includes('function') && error.message.includes('not found')) {
             throw new Error("Security update required. Admin must run SQL in Settings.");
        }
        throw new Error(error.message);
    }
    
    if (!user) throw new Error('User not found.');

    const processedUser = await processUserOnLogin(user as User);

    const token = btoa(`${processedUser.id}:${Date.now()}`);
    localStorage.setItem(STORAGE_KEY_TOKEN, token);
    localStorage.setItem(CACHE_KEY_USER, JSON.stringify(processedUser)); // Cache immediately
    
    return { user: processedUser, token };
  },

  // REGISTER - SECURED VIA RPC
  register: async (phoneNumber: string, password: string, referralCode?: string): Promise<AuthResponse> => {
    const { count, error: countError } = await supabase.from('users').select('*', { count: 'exact', head: true });
    if (countError) handleSupabaseError(countError, 'countUsers');
    
    const isFirstUser = count === 0;
    const cleanCode = (referralCode || '').trim();
    const userId = crypto.randomUUID();
    const myCode = isFirstUser ? 'ADMIN1' : Math.random().toString(36).substring(2, 8).toUpperCase();
    const validityMs = isFirstUser ? 3650 * 24 * 60 * 60 * 1000 : 3 * 24 * 60 * 60 * 1000;
    const expiryDate = new Date(Date.now() + validityMs).toISOString();
    const joinDate = new Date().toISOString();
    const userName = isFirstUser ? 'Super Admin' : `User_${phoneNumber.slice(-4)}`;

    // Call Secure RPC
    const { error: rpcError } = await supabase.rpc('register_user_secure', {
        p_id: userId,
        p_phone: phoneNumber,
        p_password: password,
        p_name: userName,
        p_ref_code_input: cleanCode,
        p_my_code: myCode,
        p_join_date: joinDate,
        p_vip_expiry: expiryDate,
        p_is_first_user: isFirstUser,
        p_master_code: MASTER_REFERRAL_CODE
    });

    if (rpcError) {
        if (rpcError.message.includes('function') && rpcError.message.includes('not found')) {
             throw new Error("Security update required. Admin must run SQL in Settings.");
        }
        throw new Error(rpcError.message);
    }

    // Since RPC returns void, we construct the user object for immediate login
    // Note: We don't get the upline ID back immediately, but that's fine for the session
    const newUser: User = {
        id: userId,
        phoneNumber,
        password,
        referralCode: myCode,
        name: userName,
        avatarId: 0,
        isAdmin: isFirstUser,
        isBanned: false,
        balance: isFirstUser ? 1000 : 20,
        spinsAvailable: isFirstUser ? 100 : 1,
        vipLevel: isFirstUser ? 5 : 0,
        vipExpiryDate: expiryDate,
        todayEarnings: 0,
        yesterdayEarnings: 0,
        totalEarnings: 0,
        weeklyEarnings: 0,
        monthlyEarnings: 0,
        lastMonthEarnings: 0,
        todayReferralBonus: 0,
        totalReferralBonus: 0,
        tasksCompletedToday: 0,
        tasksFailedToday: 0,
        referrals: [],
        depositHistory: [],
        withdrawHistory: [],
        earningHistory: [],
        notifications: [],
        hiddenBroadcasts: [],
        joinDate: joinDate,
        withdrawalPin: '1234',
        nameChangeCount: 0,
        passwordChangeCount: 0,
        pinChangeCount: 0,
        bKashChangeCount: 0,
        nagadChangeCount: 0,
        loginStreak: 1
    };

    const token = btoa(`${userId}:${Date.now()}`);
    localStorage.setItem(STORAGE_KEY_TOKEN, token);
    localStorage.setItem(CACHE_KEY_USER, JSON.stringify(newUser));

    return { user: newUser, token };
  },

  // GET ME - Optimized for Speed
  getMe: async (forceNetwork = false): Promise<User> => {
      if (!forceNetwork) {
          const cachedUser = api.getFromCache<User>(CACHE_KEY_USER);
          if (cachedUser) {
              // Return cached if allowed, but usually we just let it return and sync later
          }
      }

      const token = localStorage.getItem(STORAGE_KEY_TOKEN);
      if (!token) throw new Error('No token');
      
      const userId = atob(token).split(':')[0];
      const { data: user, error } = await supabase.from('users').select('*').eq('id', userId).single();
      
      if (error) handleSupabaseError(error, 'getMe');
      if (!user) throw new Error('User not found');
      if (user.isBanned) throw new Error('Account Banned');
      
      const processed = await processUserOnLogin(user);
      localStorage.setItem(CACHE_KEY_USER, JSON.stringify(processed)); // Update Cache
      return processed;
  },

  getToken: () => localStorage.getItem(STORAGE_KEY_TOKEN),
  removeToken: () => {
      localStorage.removeItem(STORAGE_KEY_TOKEN);
      localStorage.removeItem(CACHE_KEY_USER);
      localStorage.removeItem(CACHE_KEY_TASKS);
      localStorage.removeItem(CACHE_KEY_SETTINGS);
  },

  subscribeToUser: (userId: string, callback: (user: User) => void) => {
      const channel = supabase.channel(`public:users:id=eq.${userId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'users', filter: `id=eq.${userId}` },
        (payload) => {
          const u = payload.new as User;
          u.earningHistory = safeArray(u.earningHistory);
          u.depositHistory = safeArray(u.depositHistory);
          u.withdrawHistory = safeArray(u.withdrawHistory);
          u.referrals = safeArray(u.referrals);
          u.notifications = safeArray(u.notifications);
          u.hiddenBroadcasts = safeArray(u.hiddenBroadcasts);
          u.savedPaymentMethods = safeArray(u.savedPaymentMethods);
          
          localStorage.setItem(CACHE_KEY_USER, JSON.stringify(u));
          callback(u);
        }
      )
      .subscribe();

      return () => { supabase.removeChannel(channel); };
  },

  // PROFILE SYNC - This is what fixes the Name/Password update issue
  syncUser: async (user: User) => {
      localStorage.setItem(CACHE_KEY_USER, JSON.stringify(user));
      
      const { error } = await supabase.from('users').update({
          name: user.name,
          avatarId: user.avatarId,
          password: user.password,
          withdrawalPin: user.withdrawalPin,
          savedPaymentMethods: user.savedPaymentMethods,
          notifications: user.notifications, 
          hiddenBroadcasts: user.hiddenBroadcasts, // Persist hidden messages
          // Update Counters
          nameChangeCount: user.nameChangeCount,
          passwordChangeCount: user.passwordChangeCount,
          pinChangeCount: user.pinChangeCount,
          bKashChangeCount: user.bKashChangeCount,
          nagadChangeCount: user.nagadChangeCount,
          lastPasswordChangeDate: user.lastPasswordChangeDate,
          lastPinChangeDate: user.lastPinChangeDate
      }).eq('id', user.id);
      
      if (error) console.error("Sync User Error", error);
  },

  getSettings: async (): Promise<SystemSettings> => {
      const cached = api.getFromCache<SystemSettings>(CACHE_KEY_SETTINGS);
      
      try {
          let { data: settingRow, error } = await supabase.from('system_settings').select('settings').eq('id', 'global').single();
          
          if (error) {
              console.warn("Using cached settings due to network/permission error", error);
              if (cached) return cached;
              if (error.code !== 'PGRST116') handleSupabaseError(error, 'getSettings');
          }

          let fetchedSettings: any = {};
          let needsUpdate = false;

          if (settingRow && settingRow.settings) {
              fetchedSettings = settingRow.settings;
          } else {
              needsUpdate = true;
              fetchedSettings = {}; 
          }

          if (!fetchedSettings.areDefaultsSeeded) {
               if (!fetchedSettings.vipTiers) fetchedSettings.vipTiers = VIP_TIERS;
               if (!fetchedSettings.sliderImages) fetchedSettings.sliderImages = SLIDER_IMAGES;
               if (!fetchedSettings.lotterySegments) fetchedSettings.lotterySegments = LOTTERY_SEGMENTS;
               fetchedSettings.areDefaultsSeeded = true;
               needsUpdate = true;
          }

          const finalSettings = { 
              ...DEFAULT_SETTINGS, 
              ...fetchedSettings,
              paymentNumbers: {
                  bKash: fetchedSettings.paymentNumbers?.bKash || [],
                  nagad: fetchedSettings.paymentNumbers?.nagad || []
              },
              // Ensure paymentLogos exists with defaults if missing in fetch
              paymentLogos: {
                  bKash: fetchedSettings.paymentLogos?.bKash || DEFAULT_SETTINGS.paymentLogos.bKash,
                  nagad: fetchedSettings.paymentLogos?.nagad || DEFAULT_SETTINGS.paymentLogos.nagad,
              },
              schedule: {
                  startHour: fetchedSettings.schedule?.startHour ?? DEFAULT_SETTINGS.schedule.startHour,
                  endHour: fetchedSettings.schedule?.endHour ?? DEFAULT_SETTINGS.schedule.endHour,
                  offDays: fetchedSettings.schedule?.offDays || []
              },
              commissions: {
                  vip: fetchedSettings.commissions?.vip || DEFAULT_SETTINGS.commissions.vip,
                  task: fetchedSettings.commissions?.task || DEFAULT_SETTINGS.commissions.task
              },
              broadcasts: safeArray(fetchedSettings.broadcasts)
          };

          localStorage.setItem(CACHE_KEY_SETTINGS, JSON.stringify(finalSettings));
          return finalSettings;

      } catch (e) {
          console.error("Settings fetch failed", e);
          return cached || DEFAULT_SETTINGS;
      }
  },

  updateSettings: async (settings: SystemSettings) => {
      localStorage.setItem(CACHE_KEY_SETTINGS, JSON.stringify(settings));
      // Use RPC for Secure Admin Update
      const adminId = getMyId();
      const { error } = await supabase.rpc('admin_update_settings', {
          p_settings: settings,
          p_admin_id: adminId
      });
      
      if (error) {
          if (error.message.includes('function') && error.message.includes('not found')) {
              throw new Error("Update Required: Please run the Security SQL from Settings!");
          }
          throw new Error(error.message);
      }
  },

  getTasks: async (): Promise<Task[]> => {
      const cached = api.getFromCache<Task[]>(CACHE_KEY_TASKS);
      
      const fetchPromise = supabase.from('tasks').select('*').then(({ data, error }) => {
          if (error) handleSupabaseError(error, 'getTasks');
          const tasks = data || [];
          localStorage.setItem(CACHE_KEY_TASKS, JSON.stringify(tasks));
          return tasks;
      });

      return cached || (await fetchPromise);
  },

  getTeam: async (userId: string): Promise<ReferralMember[]> => {
      const cacheKey = `mnlife_team_${userId}`;
      const cached = api.getFromCache<ReferralMember[]>(cacheKey);

      const fetchPromise = (async () => {
          const mapUserToMember = (u: any): Omit<ReferralMember, 'level'> => ({
            id: u.id,
            phoneNumber: u.phoneNumber,
            username: u.name || 'User',
            joinDate: u.joinDate || new Date().toISOString(),
            vipLevel: u.vipLevel || 0,
            totalDeposited: u.totalDeposited || 0,
            totalWithdrawn: u.totalWithdrawn || 0,
            tasksCompletedToday: u.tasksCompletedToday || 0,
            memberTodayEarnings: u.todayEarnings || 0,
            tasksFailedToday: u.tasksFailedToday || 0,
            commissionEarned: 0, 
            lastActiveDate: u.lastActiveDate
        });

          // Level 1
          const { data: l1, error: e1 } = await supabase.from('users').select('*').eq('referredBy', userId);
          if (e1) return []; 
          if (!l1 || l1.length === 0) return [];

          const l1Members = l1.map(u => ({ ...mapUserToMember(u), level: 1 as 1|2|3 }));
          const l1Ids = l1.map(u => u.id);

          // Level 2
          const { data: l2 } = await supabase.from('users').select('*').in('referredBy', l1Ids);
          const l2Members = (l2 || []).map(u => ({ ...mapUserToMember(u), level: 2 as 1|2|3 }));
          const l2Ids = (l2 || []).map(u => u.id);

          // Level 3
          let l3Members: ReferralMember[] = [];
          if (l2Ids.length > 0) {
              const { data: l3 } = await supabase.from('users').select('*').in('referredBy', l2Ids);
              l3Members = (l3 || []).map(u => ({ ...mapUserToMember(u), level: 3 as 1|2|3 }));
          }

          const allMembers = [...l1Members, ...l2Members, ...l3Members];
          localStorage.setItem(cacheKey, JSON.stringify(allMembers));
          return allMembers;
      })();

      return cached || (await fetchPromise);
  },

  // =========================================================================
  // EDGE FUNCTIONS (RESTORED)
  // =========================================================================

  claimTaskReward: async (userId: string, amount: number) => {
      // Using Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('complete-task', { body: { userId, amount } });
      if (error) throw new Error(error.message || "Server Error: Task not verified");
      return data;
  },

  purchaseVip: async (userId: string, level: number, price: number) => {
      const { data, error } = await supabase.functions.invoke('purchase-vip', { body: { userId, level, price } });
      if (error) throw new Error(error.message || "Server Error: VIP Upgrade failed");
      return data;
  },

  requestWithdrawal: async (userId: string, amount: number, method: string, number: string, pin: string) => {
      const { data, error } = await supabase.functions.invoke('request-withdrawal', { body: { userId, amount, method, number, pin } });
      if (error) throw new Error(error.message || "Server Error: Withdrawal request failed");
      return data;
  },

  spinWheel: async (userId: string) => {
      const { data, error } = await supabase.functions.invoke('spin-wheel', { body: { userId } });
      if (error) throw new Error(error.message || "Server Error: Spin failed");
      return data; 
  },

  // Fallback for simple penalty logic (can be client-side update as it REDUCES balance)
  recordTaskFail: async (userId: string, amount: number) => {
      const { data: user } = await supabase.from('users').select('*').eq('id', userId).single();
      if (!user) return;

      const newTx: Transaction = {
          id: Math.random().toString(36).substr(2, 9),
          type: 'PENALTY', amount: amount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Task Failed Penalty'
      };

      const updates = {
          balance: Number(user.balance || 0) - amount,
          tasksFailedToday: Number(user.tasksFailedToday || 0) + 1,
          earningHistory: [newTx, ...safeArray(user.earningHistory)]
      };
      
      const cached = api.getFromCache<User>(CACHE_KEY_USER);
      if(cached) {
          localStorage.setItem(CACHE_KEY_USER, JSON.stringify({...cached, ...updates}));
      }

      await supabase.from('users').update(updates).eq('id', userId);
  },

  getAllUsers: async (): Promise<User[]> => {
      const { data: users } = await supabase.from('users').select('*');
      return users ? users.map(u => ({
          ...u,
          referrals: safeArray(u.referrals),
          depositHistory: safeArray(u.depositHistory),
          withdrawHistory: safeArray(u.withdrawHistory),
          earningHistory: safeArray(u.earningHistory),
          notifications: safeArray(u.notifications),
          savedPaymentMethods: safeArray(u.savedPaymentMethods)
      })) : [];
  },

  deleteUser: async (userId: string): Promise<void> => {
      await supabase.from('users').delete().eq('id', userId);
  },

  sendNotification: async (title: string, message: string, targetUserId?: string): Promise<void> => {
      const newNotif: AppNotification = {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 5),
          title, message, date: new Date().toISOString(), read: false, type: 'SYSTEM'
      };

      if (targetUserId) {
          const { data: user } = await supabase.from('users').select('notifications').eq('id', targetUserId).single();
          if (user) {
              await supabase.from('users').update({ notifications: [newNotif, ...safeArray(user.notifications)] }).eq('id', targetUserId);
          }
      } else {
          // Broadcast via RPC
          const { data: settingRow } = await supabase.from('system_settings').select('settings').eq('id', 'global').single();
          if (settingRow) {
              const currentSettings = settingRow.settings;
              const currentBroadcasts = safeArray(currentSettings.broadcasts);
              const updatedBroadcasts = [newNotif, ...currentBroadcasts];
              
              const adminId = getMyId();
              await supabase.rpc('admin_update_settings', {
                  p_settings: { ...currentSettings, broadcasts: updatedBroadcasts },
                  p_admin_id: adminId
              });
          }
      }
  },

  deleteBroadcast: async (notifId: string) => {
      const { data: settingRow } = await supabase.from('system_settings').select('settings').eq('id', 'global').single();
      if (settingRow && settingRow.settings) {
          const currentSettings = settingRow.settings;
          const currentBroadcasts = safeArray(currentSettings.broadcasts);
          
          // STRICT FILTER
          const updatedBroadcasts = currentBroadcasts.filter((n: AppNotification) => n.id !== notifId);
          
          const adminId = getMyId();
          
          // Update via RPC to ensure it sticks
          const { error } = await supabase.rpc('admin_update_settings', {
              p_settings: { ...currentSettings, broadcasts: updatedBroadcasts },
              p_admin_id: adminId
          });

          if (error) {
              console.error("RPC Error in deleteBroadcast:", error);
              throw new Error(error.message);
          }
      } else {
          throw new Error("Settings not found");
      }
  },

  getAllPendingDeposits: async (): Promise<{user: User, tx: Transaction}[]> => {
      const users = await api.getAllUsers();
      const results: {user: User, tx: Transaction}[] = [];
      users.forEach(u => {
          safeArray(u.depositHistory).forEach((tx: Transaction) => {
              if (tx.status === 'PENDING') {
                  results.push({ user: u, tx });
              }
          });
      });
      return results;
  },

  getAllPendingWithdrawals: async (): Promise<{user: User, tx: Transaction}[]> => {
      const users = await api.getAllUsers();
      const results: {user: User, tx: Transaction}[] = [];
      users.forEach(u => {
          safeArray(u.withdrawHistory).forEach((tx: Transaction) => {
              if (tx.status === 'PENDING') {
                  results.push({ user: u, tx });
              }
          });
      });
      return results;
  },

  approveDeposit: async (userId: string, txId: string, amount: number) => {
      const { data: user } = await supabase.from('users').select('*').eq('id', userId).single();
      if (!user) return;
      
      const updatedHistory = safeArray(user.depositHistory).map((tx: Transaction) => {
          if (tx.id === txId) return { ...tx, status: 'COMPLETED' };
          return tx;
      });
      
      const newBalance = Number(user.balance || 0) + amount;
      const updatedUser = {
          balance: newBalance,
          depositHistory: updatedHistory,
          notifications: [
              { id: Date.now().toString(), title: 'Deposit Approved', message: `Your deposit of ${amount} BDT has been approved.`, date: new Date().toISOString(), read: false, type: 'SYSTEM' },
              ...safeArray(user.notifications)
          ],
          totalDeposited: Number(user.totalDeposited || 0) + amount
      };

      await supabase.from('users').update(updatedUser).eq('id', userId);
  },

  rejectDeposit: async (userId: string, txId: string) => {
      const { data: user } = await supabase.from('users').select('*').eq('id', userId).single();
      if (!user) return;
      
      const updatedHistory = safeArray(user.depositHistory).map((tx: Transaction) => {
          if (tx.id === txId) return { ...tx, status: 'FAILED' };
          return tx;
      });

      const notif = { id: Date.now().toString(), title: 'Deposit Rejected', message: `Your deposit request was rejected. Check details.`, date: new Date().toISOString(), read: false, type: 'SYSTEM' };

      await supabase.from('users').update({
          depositHistory: updatedHistory,
          notifications: [notif, ...safeArray(user.notifications)]
      }).eq('id', userId);
  },

  approveWithdrawal: async (userId: string, txId: string) => {
      const { data: user } = await supabase.from('users').select('*').eq('id', userId).single();
      if (!user) return;

      const updatedHistory = safeArray(user.withdrawHistory).map((tx: Transaction) => {
          if (tx.id === txId) return { ...tx, status: 'COMPLETED' };
          return tx;
      });

       const notif = { id: Date.now().toString(), title: 'Withdrawal Sent', message: `Your withdrawal request has been processed.`, date: new Date().toISOString(), read: false, type: 'SYSTEM' };
      
      const tx = safeArray(user.withdrawHistory).find((t: Transaction) => t.id === txId);
      const amount = tx ? tx.amount : 0;
      const newTotalWithdrawn = Number(user.totalWithdrawn || 0) + amount;

      await supabase.from('users').update({
          withdrawHistory: updatedHistory,
          notifications: [notif, ...safeArray(user.notifications)],
          totalWithdrawn: newTotalWithdrawn
      }).eq('id', userId);
  },

  rejectWithdrawal: async (userId: string, txId: string, amount: number) => {
      const { data: user } = await supabase.from('users').select('*').eq('id', userId).single();
      if (!user) return;

      const updatedHistory = safeArray(user.withdrawHistory).map((tx: Transaction) => {
          if (tx.id === txId) return { ...tx, status: 'FAILED' };
          return tx;
      });

      const newBalance = Number(user.balance || 0) + amount;
      const notif = { id: Date.now().toString(), title: 'Withdrawal Returned', message: `Withdrawal rejected. ${amount} BDT refunded to balance.`, date: new Date().toISOString(), read: false, type: 'SYSTEM' };

      await supabase.from('users').update({
          balance: newBalance,
          withdrawHistory: updatedHistory,
          notifications: [notif, ...safeArray(user.notifications)]
      }).eq('id', userId);
  },

  adminUpdateUser: async (userId: string, updates: Partial<User>) => {
      const adminId = getMyId();
      const { error } = await supabase.rpc('admin_update_user', {
          p_target_user_id: userId,
          p_updates: updates,
          p_admin_id: adminId
      });
      
      if (error) {
          if (error.message.includes('function') && error.message.includes('not found')) {
              throw new Error("Update Required: Please run the Security SQL from Settings!");
          }
          throw new Error(error.message);
      }
  },

  // --- ADMIN TASK MANAGEMENT (RPC) ---
  
  createTask: async (task: Task) => {
      const adminId = getMyId();
      const { error } = await supabase.rpc('admin_create_task', {
          p_title: task.title || 'Untitled',
          p_description: task.description || `${task.durationSeconds || 30}s`,
          p_platform: task.platform || 'GENERIC',
          p_duration: task.durationSeconds || 30,
          p_reward: task.reward || 0,
          p_url: task.url || '#',
          p_tag: task.tag || 'General',
          p_admin_id: adminId
      });
      
      if (error) {
          if (error.message.includes('function') && error.message.includes('not found')) {
              throw new Error("Update Required: Please run the Security SQL from Settings!");
          }
          throw new Error(error.message);
      }
  },

  deleteTask: async (taskId: string) => {
      const adminId = getMyId();
      const { error } = await supabase.rpc('admin_delete_task', {
          p_task_id: taskId,
          p_admin_id: adminId
      });
      
      if (error) {
          if (error.message.includes('function') && error.message.includes('not found')) {
              throw new Error("Update Required: Please run the Security SQL from Settings!");
          }
          throw new Error(error.message);
      }
  },

  adminCreateUser: async (phone: string, pass: string, name: string): Promise<void> => {
      const userId = crypto.randomUUID();
      const myCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const newUser = {
        id: userId, phoneNumber: phone, password: pass, referralCode: myCode, name: name, balance: 0, vipLevel: 0, joinDate: new Date().toISOString(),
      };
      await supabase.from('users').insert(newUser);
  }
};
