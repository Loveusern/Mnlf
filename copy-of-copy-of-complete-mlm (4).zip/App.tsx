
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import Work from './pages/Work';
import Vip from './pages/Vip';
import Team from './pages/Team';
import Profile from './pages/Profile';
import Lottery from './pages/Lottery';
import TaskView from './pages/TaskView';
import BottomNav from './components/BottomNav';
import AuthModal from './components/AuthModal';
import { User, Transaction } from './types';
import { api } from './services/api';
import { Loader2, Database, Save, AlertTriangle, Copy, Check, WifiOff, RefreshCw } from 'lucide-react';
import { ToastProvider } from './components/ToastContext';

// Admin Imports
import AdminLayout from './pages/admin/AdminLayout';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminDeposits from './pages/admin/AdminDeposits';
import AdminWithdrawals from './pages/admin/AdminWithdrawals';
import AdminUsers from './pages/admin/AdminUsers';
import AdminTasks from './pages/admin/AdminTasks';
import AdminSettings from './pages/admin/AdminSettings';
import AdminVip from './pages/admin/AdminVip';

const GUEST_USER: User = {
    id: 'guest',
    phoneNumber: '',
    referralCode: '',
    balance: 0,
    vipLevel: 0,
    vipExpiryDate: '',
    todayEarnings: 0,
    yesterdayEarnings: 0,
    totalEarnings: 0,
    weeklyEarnings: 0,
    monthlyEarnings: 0,
    lastMonthEarnings: 0,
    todayReferralBonus: 0,
    totalReferralBonus: 0,
    tasksCompletedToday: 0,
    tasksFailedToday: 0,
    referrals: [],
    depositHistory: [],
    withdrawHistory: [],
    earningHistory: [],
    notifications: [],
    hiddenBroadcasts: [],
    joinDate: new Date().toISOString(),
    withdrawalPin: '',
    nameChangeCount: 0,
    passwordChangeCount: 0,
    pinChangeCount: 0,
    bKashChangeCount: 0,
    nagadChangeCount: 0,
    avatarId: 0,
    loginStreak: 0,
    spinsAvailable: 0
};

const DatabaseSetupModal = () => {
    const [copied, setCopied] = useState(false);
    const sqlScript = `-- COPY AND RUN THIS ENTIRE SCRIPT IN SUPABASE SQL EDITOR

-- 1. Create Tables
create table if not exists public.users (
  id text primary key,
  "phoneNumber" text,
  password text,
  "referralCode" text,
  "referredBy" text,
  name text,
  "avatarId" int4,
  "isAdmin" boolean default false,
  "isBanned" boolean default false,
  balance float8 default 0,
  "spinsAvailable" int4 default 0,
  "vipLevel" int4 default 0,
  "vipExpiryDate" text,
  "lastActiveDate" text,
  "lastTaskCompletionTime" int8,
  "todayEarnings" float8 default 0,
  "yesterdayEarnings" float8 default 0,
  "totalEarnings" float8 default 0,
  "weeklyEarnings" float8 default 0,
  "monthlyEarnings" float8 default 0,
  "lastMonthEarnings" float8 default 0,
  "todayReferralBonus" float8 default 0,
  "totalReferralBonus" float8 default 0,
  "totalDeposited" float8 default 0,
  "totalWithdrawn" float8 default 0,
  "tasksCompletedToday" int4 default 0,
  "tasksFailedToday" int4 default 0,
  "loginStreak" int4 default 0,
  "lastDailyRewardDate" text,
  "joinDate" text,
  "withdrawalPin" text,
  "nameChangeCount" int4 default 0,
  "passwordChangeCount" int4 default 0,
  "lastPasswordChangeDate" text,
  "pinChangeCount" int4 default 0,
  "lastPinChangeDate" text,
  "bKashChangeCount" int4 default 0,
  "nagadChangeCount" int4 default 0,
  "savedPaymentMethods" jsonb default '[]',
  referrals jsonb default '[]',
  "depositHistory" jsonb default '[]',
  "withdrawHistory" jsonb default '[]',
  "earningHistory" jsonb default '[]',
  notifications jsonb default '[]',
  "hiddenBroadcasts" jsonb default '[]'
);

create table if not exists public.system_settings (
  id text primary key,
  "masterCodeUsage" int4 default 0,
  settings jsonb
);

create table if not exists public.tasks (
  id text primary key,
  title text,
  description text,
  platform text,
  "durationSeconds" int4,
  reward float8,
  url text,
  tag text
);

-- 2. Realtime
alter publication supabase_realtime add table public.users;
alter publication supabase_realtime add table public.tasks;
alter publication supabase_realtime add table public.system_settings;

-- 3. RLS Policies
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable read for users based on id" ON public.users;
CREATE POLICY "Enable read for users based on id" ON public.users FOR SELECT USING (true);
DROP POLICY IF EXISTS "Enable insert for users" ON public.users;
CREATE POLICY "Enable insert for users" ON public.users FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Enable update for users based on id" ON public.users;
CREATE POLICY "Enable update for users based on id" ON public.users FOR UPDATE USING (true);

DROP POLICY IF EXISTS "Allow public read system settings" ON public.system_settings;
CREATE POLICY "Allow public read system settings" ON public.system_settings FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow public read tasks" ON public.tasks;
CREATE POLICY "Allow public read tasks" ON public.tasks FOR SELECT USING (true);

-- 4. Secure Auth RPCs
CREATE OR REPLACE FUNCTION public.login_user_secure(p_phone text, p_password text)
RETURNS jsonb AS $$
DECLARE
  v_user public.users;
BEGIN
  SELECT * INTO v_user FROM public.users WHERE "phoneNumber" = p_phone;
  IF NOT FOUND THEN RAISE EXCEPTION 'User not found'; END IF;
  IF v_user.password <> p_password THEN RAISE EXCEPTION 'Incorrect password'; END IF;
  IF v_user."isBanned" IS TRUE THEN RAISE EXCEPTION 'Account is banned'; END IF;
  RETURN to_jsonb(v_user);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.register_user_secure(
    p_id text, p_phone text, p_password text, p_name text,
    p_ref_code_input text, p_my_code text, p_join_date text,
    p_vip_expiry text, p_is_first_user boolean, p_master_code text
) RETURNS void AS $$
DECLARE
  v_upline_id text;
  v_master_usage int;
BEGIN
  PERFORM 1 FROM public.users WHERE "phoneNumber" = p_phone;
  IF FOUND THEN RAISE EXCEPTION 'Phone number already registered'; END IF;

  IF p_is_first_user = TRUE THEN
     v_upline_id := NULL;
  ELSE
     IF p_ref_code_input = p_master_code THEN
        SELECT "masterCodeUsage" INTO v_master_usage FROM public.system_settings WHERE id = 'global';
        IF v_master_usage >= 1 THEN RAISE EXCEPTION 'Master code expired'; END IF;
        UPDATE public.system_settings SET "masterCodeUsage" = "masterCodeUsage" + 1 WHERE id = 'global';
        SELECT id INTO v_upline_id FROM public.users WHERE "isAdmin" = true LIMIT 1;
     ELSE
        SELECT id INTO v_upline_id FROM public.users WHERE "referralCode" = p_ref_code_input;
        IF NOT FOUND THEN RAISE EXCEPTION 'Invalid Referral Code'; END IF;
     END IF;
  END IF;

  INSERT INTO public.users (
    id, "phoneNumber", password, name, "referralCode", "referredBy",
    "isAdmin", "isBanned", balance, "vipLevel", "vipExpiryDate",
    "todayEarnings", "totalEarnings", "joinDate", "withdrawalPin", "spinsAvailable"
  ) VALUES (
    p_id, p_phone, p_password, p_name, p_my_code, v_upline_id,
    p_is_first_user, false, 
    CASE WHEN p_is_first_user THEN 1000 ELSE 20 END,
    CASE WHEN p_is_first_user THEN 5 ELSE 0 END,
    p_vip_expiry, 0, 0, p_join_date, '1234',
    CASE WHEN p_is_first_user THEN 100 ELSE 1 END
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Security Triggers
CREATE OR REPLACE FUNCTION public.prevent_balance_hacking()
RETURNS TRIGGER AS $$
DECLARE current_role text;
BEGIN
  SELECT current_setting('role') INTO current_role;
  IF current_role = 'service_role' THEN RETURN NEW; END IF;
  IF (NEW.balance IS DISTINCT FROM OLD.balance) THEN NEW.balance := OLD.balance; END IF;
  IF (NEW."vipLevel" IS DISTINCT FROM OLD."vipLevel") THEN NEW."vipLevel" := OLD."vipLevel"; END IF;
  IF (NEW."isAdmin" IS DISTINCT FROM OLD."isAdmin") THEN NEW."isAdmin" := OLD."isAdmin"; END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS secure_user_update ON public.users;
CREATE TRIGGER secure_user_update BEFORE UPDATE ON public.users
FOR EACH ROW EXECUTE FUNCTION public.prevent_balance_hacking();

-- 6. Admin RPCs
CREATE OR REPLACE FUNCTION public.admin_update_settings(p_settings jsonb, p_admin_id text) RETURNS void AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT "isAdmin" INTO v_is_admin FROM public.users WHERE id = p_admin_id;
  IF v_is_admin IS TRUE THEN
    UPDATE public.system_settings SET settings = p_settings WHERE id = 'global';
    IF NOT FOUND THEN INSERT INTO public.system_settings (id, settings) VALUES ('global', p_settings); END IF;
  ELSE RAISE EXCEPTION 'Unauthorized'; END IF;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_update_user(p_target_user_id text, p_updates jsonb, p_admin_id text) RETURNS void AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT "isAdmin" INTO v_is_admin FROM public.users WHERE id = p_admin_id;
  IF v_is_admin IS TRUE THEN
    UPDATE public.users SET
      name = COALESCE((p_updates->>'name'), name),
      "vipLevel" = COALESCE((p_updates->>'vipLevel')::int, "vipLevel"),
      "isBanned" = COALESCE((p_updates->>'isBanned')::boolean, "isBanned"),
      password = COALESCE((p_updates->>'password'), password)
    WHERE id = p_target_user_id;
  ELSE RAISE EXCEPTION 'Unauthorized'; END IF;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_create_task(p_title text, p_description text, p_platform text, p_duration int, p_reward float8, p_url text, p_tag text, p_admin_id text) RETURNS void AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT "isAdmin" INTO v_is_admin FROM public.users WHERE id = p_admin_id;
  IF v_is_admin IS TRUE THEN
    INSERT INTO public.tasks (id, title, description, platform, "durationSeconds", reward, url, tag) VALUES (gen_random_uuid()::text, p_title, p_description, p_platform, p_duration, p_reward, p_url, p_tag);
  ELSE RAISE EXCEPTION 'Unauthorized'; END IF;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_delete_task(p_task_id text, p_admin_id text) RETURNS void AS $$
DECLARE v_is_admin boolean;
BEGIN
  SELECT "isAdmin" INTO v_is_admin FROM public.users WHERE id = p_admin_id;
  IF v_is_admin IS TRUE THEN
    DELETE FROM public.tasks WHERE id = p_task_id;
  ELSE RAISE EXCEPTION 'Unauthorized'; END IF;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;
`;

    const copySql = () => {
        navigator.clipboard.writeText(sqlScript);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/95 p-4 overflow-y-auto">
            <div className="bg-slate-900 w-full max-w-lg rounded-2xl border border-slate-700 shadow-2xl overflow-hidden my-8">
                <div className="p-6 border-b border-slate-800 bg-gradient-to-r from-slate-900 to-indigo-950">
                    <h2 className="text-xl font-bold text-white flex items-center"><Database className="mr-2 text-red-500" /> Database Security Setup</h2>
                    <p className="text-slate-400 text-sm mt-1">Run this SQL in Supabase to fix errors.</p>
                </div>
                <div className="p-6 space-y-6">
                    <div className="bg-yellow-900/20 border border-yellow-500/20 p-3 rounded-lg flex items-start space-x-2">
                        <AlertTriangle size={16} className="text-yellow-500 shrink-0 mt-0.5" />
                        <p className="text-xs text-yellow-200">You MUST run this SQL in your Supabase <b>SQL Editor</b> to enable Security Policies & Auth.</p>
                    </div>
                    <div className="relative group">
                        <div className="absolute top-2 right-2">
                            <button onClick={copySql} className={`text-xs px-3 py-1.5 rounded-md font-bold flex items-center transition-all ${copied ? 'bg-green-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`}>{copied ? <Check size={14} className="mr-1" /> : <Copy size={14} className="mr-1" />}{copied ? 'Copied' : 'Copy SQL'}</button>
                        </div>
                        <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[10px] text-slate-400 font-mono h-48 overflow-y-auto no-scrollbar">{sqlScript}</pre>
                    </div>
                </div>
                <div className="p-6 border-t border-slate-800 bg-slate-900/50">
                    <button onClick={() => window.location.reload()} className="w-full bg-green-600 hover:bg-green-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-green-900/20 flex items-center justify-center transition-all"><Save size={18} className="mr-2" /> I've Run the SQL, Refresh App</button>
                </div>
            </div>
        </div>
    );
};

const NetworkErrorScreen = ({ onRetry }: { onRetry: () => void }) => {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 p-6 text-center animate-fade-in">
            <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mb-6 border-4 border-slate-800 shadow-xl"><WifiOff size={40} className="text-red-500" /></div>
            <h2 className="text-2xl font-bold text-white mb-2">Connection Lost</h2>
            <p className="text-slate-400 text-sm mb-8 max-w-xs">Unable to connect to the server.</p>
            <button onClick={onRetry} className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-lg shadow-blue-900/30 flex items-center transition-all active:scale-95"><RefreshCw size={20} className="mr-2" /> Retry Connection</button>
        </div>
    );
};

const AdminRoute = ({ user }: { user: User | null }) => {
    if (!user || !user.isAdmin) {
        return <Navigate to="/" replace />;
    }
    return <Outlet />;
};

// USER LAYOUT - Constrained Mobile View
const UserLayout: React.FC<{ user: User | null; onRequireAuth: () => void }> = ({ user, onRequireAuth }) => {
    return (
        <div className="bg-slate-950 min-h-screen text-slate-100 font-sans antialiased max-w-md mx-auto shadow-2xl overflow-hidden relative border-x border-slate-800">
            <div className="h-full overflow-y-auto no-scrollbar pb-20">
                <Outlet />
            </div>
            <BottomNav user={user} onRequireAuth={onRequireAuth} />
        </div>
    );
};

const AppContent: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => api.getFromCache<User>('mnlife_user_data'));
  
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [missingTables, setMissingTables] = useState(false);
  const [isNetworkError, setIsNetworkError] = useState(false);

  useEffect(() => {
    const initApp = async () => {
      try {
          await api.checkSystem();
      } catch (e: any) {
          if (e.message === "MISSING_TABLES") { setMissingTables(true); setIsInitializing(false); return; }
          if (e.message === "NETWORK_ERROR") { setIsNetworkError(true); setIsInitializing(false); return; }
      }

      const token = api.getToken();
      let fetchPromise = Promise.resolve();
      
      if (token) {
        fetchPromise = api.getMe(true)
          .then(fetchedUser => setUser(fetchedUser))
          .catch(error => { 
             console.log("Session invalid or offline, keeping cache if exists or logout");
             if(!user) {
                 api.removeToken(); 
                 setUser(null); 
             }
          });
      }

      await fetchPromise;
      if (!missingTables && !isNetworkError) { 
          setIsInitializing(false); 
          if (!api.getToken()) {
              setShowAuthModal(true);
          }
      }
    };
    initApp();
  }, [missingTables, isNetworkError]);

  useEffect(() => {
    let unsubscribe: () => void;
    if (user && user.id && user.id !== 'guest') {
        unsubscribe = api.subscribeToUser(user.id, (updatedUser) => {
            setUser(prev => { if (JSON.stringify(prev) !== JSON.stringify(updatedUser)) return updatedUser; return prev; });
        });
    }
    return () => { if (unsubscribe) unsubscribe(); };
  }, [user?.id]); 

  const handleLogin = (newUser: User) => { setUser(newUser); setShowAuthModal(false); if (newUser.isAdmin) window.location.hash = '#/admin/dashboard'; };
  const handleLogout = () => { api.removeToken(); setUser(null); };
  const requireAuth = () => { setShowAuthModal(true); };
  const handleUpdateUser = (updatedUser: User) => { setUser(updatedUser); api.syncUser(updatedUser); };

  const handleRefreshUser = async () => {
      if (!user) return;
      try {
          const refreshedUser = await api.getMe(true);
          setUser(refreshedUser);
      } catch (e) {
          console.error("Failed to refresh user", e);
      }
  };

  const handleTaskComplete = async (amount: number) => {
    if (!user || user.id === 'guest') return;
    const previousState = { ...user };
    const newTx: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'EARNING', amount: amount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Task Reward' };
    const updatedUser = { ...user, balance: (user.balance || 0) + amount, todayEarnings: (user.todayEarnings || 0) + amount, totalEarnings: (user.totalEarnings || 0) + amount, tasksCompletedToday: (user.tasksCompletedToday || 0) + 1, earningHistory: [newTx, ...(user.earningHistory || [])] };
    setUser(updatedUser);
    try { await api.claimTaskReward(user.id, amount); } catch (e: any) { setUser(previousState); alert(`Error: ${e.message}`); }
  };

  const handleTaskFail = async (penaltyAmount: number) => {
    if (!user || user.id === 'guest') return;
    const newTx: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'PENALTY', amount: penaltyAmount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Task Failed Penalty' };
    const updatedUser = { ...user, balance: (user.balance || 0) - penaltyAmount, tasksFailedToday: (user.tasksFailedToday || 0) + 1, earningHistory: [newTx, ...(user.earningHistory || [])] };
    setUser(updatedUser);
    try { await api.recordTaskFail(user.id, penaltyAmount); } catch (e) { console.error("Task Fail Log Error", e); }
  };

  const handleDeposit = (amount: number, method: string, trxId: string, sender: string) => {
    if (!user) return;
    const newTransaction: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'DEPOSIT', amount: amount, status: 'PENDING', date: new Date().toISOString(), method: method, transactionId: trxId, senderNumber: sender };
    const updatedUser = { ...user, depositHistory: [newTransaction, ...(user.depositHistory || [])] };
    setUser(updatedUser);
    api.syncUser(updatedUser);
  };

  const handleWithdraw = async (amount: number, method: string, number: string, pin: string) => {
    if (!user) return;
    const newTransaction: Transaction = { id: 'temp-' + Math.random().toString(36).substr(2, 9), type: 'WITHDRAW', amount: amount, status: 'PENDING', date: new Date().toISOString(), method: method, senderNumber: number };
    const updatedUser = { ...user, balance: user.balance - amount, withdrawHistory: [newTransaction, ...(user.withdrawHistory || [])] };
    setUser(updatedUser);
    try { await api.requestWithdrawal(user.id, amount, method, number, pin); } catch (error: any) { alert(error.message); api.getMe().then(setUser); }
  };

  const handleUpgrade = async (level: number, cost: number) => {
    if (!user) return;
    if (user.balance < cost) { alert("Insufficient Balance"); return; }
    try { await api.purchaseVip(user.id, level, cost); } catch (e: any) { alert(e.message || "Upgrade failed"); }
  };

  const handleSpinResult = (amount: number) => {
      if (!user || user.spinsAvailable <= 0) return;
      let updatedUser = { ...user };
      updatedUser.spinsAvailable -= 1;
      if (amount > 0) {
          updatedUser.balance += amount;
          updatedUser.totalEarnings += amount;
          updatedUser.todayEarnings += amount;
          const newTx: Transaction = { id: Math.random().toString(36).substr(2, 9), type: 'LOTTERY', amount: amount, status: 'COMPLETED', date: new Date().toISOString(), method: 'Lucky Wheel' };
          updatedUser.earningHistory = [newTx, ...(updatedUser.earningHistory || [])];
      }
      setUser(updatedUser);
      api.syncUser(updatedUser);
  };

  if (isNetworkError) return <NetworkErrorScreen onRetry={() => window.location.reload()} />;
  if (missingTables) return <DatabaseSetupModal />;
  
  if (isInitializing) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="animate-spin text-blue-500" size={32} />
    </div>
  );

  return (
    <HashRouter>
      <Routes>
        {/* PUBLIC / USER ROUTES (Mobile Layout) */}
        <Route element={<UserLayout user={user} onRequireAuth={requireAuth} />}>
            <Route path="/" element={<Home user={user} onRequireAuth={requireAuth} onUpdateUser={handleUpdateUser} onRefresh={handleRefreshUser} />} />
            <Route path="/work" element={<Work user={user} onTaskComplete={handleTaskComplete} onRequireAuth={requireAuth} />} />
            <Route path="/task/view" element={<TaskView onComplete={handleTaskComplete} onFail={handleTaskFail} />} />
            <Route path="/vip" element={<Vip user={user || GUEST_USER} onUpgrade={user ? handleUpgrade : requireAuth} onDeposit={handleDeposit} />} />
            <Route path="/team" element={user ? <Team user={user} /> : <Navigate to="/" replace />} />
            <Route path="/lottery" element={user ? <Lottery user={user} onSpinEnd={handleSpinResult} /> : <Navigate to="/" replace />} />
            <Route path="/profile" element={user ? <Profile user={user} onLogout={handleLogout} onDeposit={handleDeposit} onWithdraw={handleWithdraw} onUpdateUser={handleUpdateUser} /> : <Home user={null} onRequireAuth={requireAuth} />} />
        </Route>

        {/* ADMIN ROUTES (Desktop Dashboard Layout) - Separated from UserLayout */}
        <Route path="/admin" element={<AdminRoute user={user} />}>
            <Route element={<AdminLayout />}>
                <Route path="dashboard" element={<AdminDashboard />} />
                <Route path="deposits" element={<AdminDeposits />} />
                <Route path="withdrawals" element={<AdminWithdrawals />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="tasks" element={<AdminTasks />} />
                <Route path="vip" element={<AdminVip />} />
                <Route path="settings" element={<AdminSettings />} />
            </Route>
        </Route>

        {/* Catch All */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
        onLogin={handleLogin} 
      />
    </HashRouter>
  );
};

const App: React.FC = () => {
    return (
        <ToastProvider>
            <AppContent />
        </ToastProvider>
    )
}

export default App;
